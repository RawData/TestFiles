# Contributing

Use Python 3.10 or later and keep changes focused. Do not add live market data,
personal portfolio details, credentials, generated evidence, or absolute local
paths to commits.

Before opening a pull request:

```bash
python -m unittest discover -s tests -q
python -m compileall -q .
ruff check .
```

Behavior changes need an offline regression test. Network tests must use
synthetic responses. Preserve these invariants: the project never places a
trade, uncertain data fails closed, writes remain atomic, and model output is
advisory rather than authoritative.