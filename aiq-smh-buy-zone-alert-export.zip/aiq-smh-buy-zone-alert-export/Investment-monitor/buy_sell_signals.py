"""Confirmed-candle buy/sell signals and their market-data delivery service.

The signal engine is deterministic and side-effect free. Market fetching,
caching, alert journaling, and rendering are added below that boundary so the
existing saved-zone and technical-analysis state remain independent.
"""

from __future__ import annotations

import copy
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import re
import tempfile
import threading
import urllib.error
import urllib.request
from zoneinfo import ZoneInfo

from market_clock import MARKETS, _calendar
from technical_data import DailyHistoryService, expected_completed_session


TIMEFRAMES = ("15m", "1h", "1d")
SIGNAL_STATUSES = ("BUY", "SELL", "PENDING_BUY", "PENDING_SELL", "NONE", "UNAVAILABLE")
UTC = timezone.utc
INTRADAY_GRACE = timedelta(minutes=2)
MAX_INTRADAY_LAG = timedelta(minutes=20)
INTRADAY_CACHE_VERSION = 1
ALERT_STATE_VERSION = 1
INTRADAY_SOURCE = "Yahoo Finance completed 15-minute regular-session OHLCV (unofficial; may be delayed)"
LOG = logging.getLogger("buy-sell-signals")

DEFAULT_SETTINGS = {
    "enabled": False,
    "timeframes": list(TIMEFRAMES),
    "immediate_email": True,
    "daily_digest": True,
    "break_mode": "Close",
    "alternate_signals": True,
    "use_daily_signal_limit": True,
    "max_signals_per_day": 1,
    "use_ema_cloud_filter": False,
    "ema_length": 50,
    "ema_slope_lookback": 5,
    "ema_sideways_threshold": 0.0,
    "use_htf_bias": False,
    "use_consolidation_filter": False,
    "block_break_setups_during_consolidation": False,
    "block_confirmations_during_consolidation": False,
    "consolidation_mode": "Range or ADX",
    "range_lookback": 12,
    "atr_length": 14,
    "range_atr_mult": 1.20,
    "adx_length": 14,
    "adx_smoothing": 14,
    "min_adx": 18.0,
}


def _integer(value, name, low, high):
    if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
        raise ValueError(f"{name} must be an integer from {low} to {high}")


def _number(value, name, low):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a finite number at least {low}")
    if not math.isfinite(value) or value < low:
        raise ValueError(f"{name} must be a finite number at least {low}")


def signal_settings(config):
    """Return validated settings without mutating the caller's configuration."""
    raw = config.get("buy_sell_signals", {})
    if not isinstance(raw, dict):
        raise ValueError("buy_sell_signals must be an object")
    unknown = set(raw) - set(DEFAULT_SETTINGS)
    if unknown:
        raise ValueError("Unknown buy_sell_signals configuration field: " + ", ".join(sorted(unknown)))
    result = {**DEFAULT_SETTINGS, **raw}
    for name in (
        "enabled", "immediate_email", "daily_digest", "alternate_signals",
        "use_daily_signal_limit", "use_ema_cloud_filter", "use_htf_bias",
        "use_consolidation_filter", "block_break_setups_during_consolidation",
        "block_confirmations_during_consolidation",
    ):
        if not isinstance(result[name], bool):
            raise ValueError(f"buy_sell_signals.{name} must be true or false")
    if (not isinstance(result["timeframes"], list)
            or not result["timeframes"]
            or any(value not in TIMEFRAMES for value in result["timeframes"])
            or len(set(result["timeframes"])) != len(result["timeframes"])):
        raise ValueError("buy_sell_signals.timeframes must contain unique 15m, 1h, or 1d values")
    if result["break_mode"] not in ("Close", "Wick"):
        raise ValueError("buy_sell_signals.break_mode must be Close or Wick")
    if result["consolidation_mode"] not in ("Range Only", "ADX Only", "Range or ADX", "Range and ADX"):
        raise ValueError("Invalid buy_sell_signals.consolidation_mode")
    for name, low, high in (
        ("max_signals_per_day", 1, 20), ("ema_length", 1, 1000),
        ("ema_slope_lookback", 1, 1000), ("range_lookback", 2, 1000),
        ("atr_length", 1, 1000), ("adx_length", 1, 1000),
        ("adx_smoothing", 1, 1000),
    ):
        _integer(result[name], f"buy_sell_signals.{name}", low, high)
    for name, low in (
        ("ema_sideways_threshold", 0.0), ("range_atr_mult", 0.1), ("min_adx", 1.0),
    ):
        _number(result[name], f"buy_sell_signals.{name}", low)
    return result


def validate_settings(config):
    signal_settings(config)


def _finite(value, name, *, allow_zero=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"Candle {name} must be numeric")
    result = float(value)
    if not math.isfinite(result) or result < 0 or (result == 0 and not allow_zero):
        raise ValueError(f"Candle {name} must be a positive finite number")
    return result


def _instant(value):
    raw = str(value)
    if len(raw) == 10:
        return datetime.fromisoformat(raw + "T23:59:59+00:00")
    result = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError("Candle timestamps must include a timezone")
    return result


def _normalize_bars(bars):
    if not isinstance(bars, list) or not bars:
        raise ValueError("No completed candles supplied")
    normalized = []
    previous = None
    for item in bars:
        if not isinstance(item, dict) or "date" not in item:
            raise ValueError("Each candle must be an object with a date")
        stamp = _instant(item.get("end", item["date"]))
        if previous is not None and stamp <= previous:
            raise ValueError("Candle timestamps must be strictly increasing")
        row = {"date": str(item["date"]), "end": stamp.isoformat()}
        for name in ("open", "high", "low", "close"):
            row[name] = _finite(item.get(name), name)
        if row["high"] < max(row["open"], row["close"], row["low"]):
            raise ValueError("Candle high is inconsistent with OHLC values")
        if row["low"] > min(row["open"], row["close"], row["high"]):
            raise ValueError("Candle low is inconsistent with OHLC values")
        if "volume" in item:
            row["volume"] = _finite(item["volume"], "volume", allow_zero=True)
        normalized.append(row)
        previous = stamp
    return normalized


def _sma(values, length):
    result = [None] * len(values)
    if len(values) < length:
        return result
    window = sum(values[:length])
    result[length - 1] = window / length
    for index in range(length, len(values)):
        window += values[index] - values[index - length]
        result[index] = window / length
    return result


def _ema(values, length):
    result = [None] * len(values)
    if len(values) < length:
        return result
    result[length - 1] = sum(values[:length]) / length
    alpha = 2.0 / (length + 1.0)
    for index in range(length, len(values)):
        result[index] = alpha * values[index] + (1.0 - alpha) * result[index - 1]
    return result


def _rma(values, length):
    result = [None] * len(values)
    if len(values) < length:
        return result
    result[length - 1] = sum(values[:length]) / length
    for index in range(length, len(values)):
        result[index] = (result[index - 1] * (length - 1) + values[index]) / length
    return result


def _rma_optional(values, length):
    result = [None] * len(values)
    window = []
    previous = None
    for index, value in enumerate(values):
        if value is None:
            window.clear()
            previous = None
            continue
        if previous is None:
            window.append(value)
            if len(window) == length:
                previous = sum(window) / length
                result[index] = previous
            continue
        previous = (previous * (length - 1) + value) / length
        result[index] = previous
    return result


def _atr(bars, length):
    ranges = []
    for index, bar in enumerate(bars):
        previous_close = bars[index - 1]["close"] if index else bar["close"]
        ranges.append(max(bar["high"] - bar["low"], abs(bar["high"] - previous_close),
                          abs(bar["low"] - previous_close)))
    return _rma(ranges, length)


def _adx(bars, length, smoothing):
    true_ranges = []
    plus_moves = []
    minus_moves = []
    for index, bar in enumerate(bars):
        if index == 0:
            true_ranges.append(bar["high"] - bar["low"])
            plus_moves.append(0.0)
            minus_moves.append(0.0)
            continue
        previous = bars[index - 1]
        true_ranges.append(max(bar["high"] - bar["low"], abs(bar["high"] - previous["close"]),
                               abs(bar["low"] - previous["close"])))
        up = bar["high"] - previous["high"]
        down = previous["low"] - bar["low"]
        plus_moves.append(up if up > down and up > 0 else 0.0)
        minus_moves.append(down if down > up and down > 0 else 0.0)
    smoothed_range = _rma(true_ranges, length)
    smoothed_plus = _rma(plus_moves, length)
    smoothed_minus = _rma(minus_moves, length)
    dx = [None] * len(bars)
    for index in range(len(bars)):
        if not smoothed_range[index]:
            continue
        plus = 100.0 * smoothed_plus[index] / smoothed_range[index]
        minus = 100.0 * smoothed_minus[index] / smoothed_range[index]
        dx[index] = 100.0 * abs(plus - minus) / (plus + minus if plus + minus else 1.0)
    return _rma_optional(dx, smoothing)


def _rolling_range(bars, length):
    result = [None] * len(bars)
    for index in range(length - 1, len(bars)):
        window = bars[index - length + 1:index + 1]
        result[index] = max(bar["high"] for bar in window) - min(bar["low"] for bar in window)
    return result


def _higher_biases(bars, higher_bars):
    result = [0] * len(bars)
    if not higher_bars:
        return result
    higher = _normalize_bars(higher_bars)
    completed = []
    cursor = 0
    bias = 0
    for index, bar in enumerate(bars):
        end = _instant(bar["end"])
        # Pine's request.security(..., close[1], lookahead_on) exposes the last
        # completed higher-timeframe candle throughout the current HTF period.
        while cursor < len(higher) and _instant(higher[cursor]["end"]) < end:
            completed.append(higher[cursor])
            cursor += 1
        if len(completed) >= 2:
            last_close = completed[-1]["close"]
            previous_mid = (completed[-2]["high"] + completed[-2]["low"]) / 2.0
            if last_close > previous_mid:
                bias = 1
            elif last_close < previous_mid:
                bias = -1
        result[index] = bias
    return result


def evaluate_bars(bars, *, options=None, timezone="UTC", higher_bars=None):
    """Replay the Pine state machine over confirmed candles for one timeframe."""
    bars = _normalize_bars(bars)
    config = signal_settings({"buy_sell_signals": options or {}})
    zone = ZoneInfo(timezone)
    closes = [bar["close"] for bar in bars]
    ema_values = _ema(closes, config["ema_length"])
    atr_values = _atr(bars, config["atr_length"])
    adx_values = _adx(bars, config["adx_length"], config["adx_smoothing"])
    range_values = _rolling_range(bars, config["range_lookback"])
    biases = (_higher_biases(bars, higher_bars)
              if config["use_htf_bias"] else [0] * len(bars))

    last_bull_low = None
    last_bull_index = None
    last_bear_high = None
    last_bear_index = None
    pending = None
    last_signal = 0
    signals_today = 0
    current_day = None
    events = []

    for index, bar in enumerate(bars):
        day = _instant(bar["end"]).astimezone(zone).date().isoformat()
        if day != current_day:
            signals_today = 0
            current_day = day
        daily_allowed = not config["use_daily_signal_limit"] or signals_today < config["max_signals_per_day"]
        bullish = bar["close"] > bar["open"]
        bearish = bar["close"] < bar["open"]

        ema_value = ema_values[index]
        slope_index = index - config["ema_slope_lookback"]
        ema_slope = (ema_value - ema_values[slope_index]
                     if ema_value is not None and slope_index >= 0 and ema_values[slope_index] is not None else None)
        ema_green = ema_slope is not None and ema_slope > config["ema_sideways_threshold"]
        ema_red = ema_slope is not None and ema_slope < -config["ema_sideways_threshold"]
        ema_buy_allowed = (not config["use_ema_cloud_filter"]
                           or (ema_green and bar["close"] > ema_value))
        ema_sell_allowed = (not config["use_ema_cloud_filter"]
                            or (ema_red and bar["close"] < ema_value))
        htf_buy_allowed = not config["use_htf_bias"] or biases[index] == 1
        htf_sell_allowed = not config["use_htf_bias"] or biases[index] == -1

        range_consolidating = (None if range_values[index] is None or atr_values[index] is None else
                               range_values[index] < atr_values[index] * config["range_atr_mult"])
        adx_consolidating = (None if adx_values[index] is None else
                             adx_values[index] < config["min_adx"])
        mode = config["consolidation_mode"]
        if mode == "Range Only":
            consolidating = range_consolidating
        elif mode == "ADX Only":
            consolidating = adx_consolidating
        elif mode == "Range or ADX":
            consolidating = (None if range_consolidating is None or adx_consolidating is None else
                             range_consolidating or adx_consolidating)
        else:
            consolidating = (None if range_consolidating is None or adx_consolidating is None else
                             range_consolidating and adx_consolidating)
        setup_consolidation_allowed = (not config["use_consolidation_filter"]
                                       or not config["block_break_setups_during_consolidation"]
                                       or consolidating is False)
        confirmation_consolidation_allowed = (not config["use_consolidation_filter"]
                                              or not config["block_confirmations_during_consolidation"]
                                              or consolidating is False)

        buy_price = bar["close"] if config["break_mode"] == "Close" else bar["high"]
        sell_price = bar["close"] if config["break_mode"] == "Close" else bar["low"]
        can_buy = not config["alternate_signals"] or last_signal != 1
        can_sell = not config["alternate_signals"] or last_signal != -1
        buy_break = (pending is None and daily_allowed and can_buy and htf_buy_allowed
                     and ema_buy_allowed and setup_consolidation_allowed and bullish
                     and last_bear_high is not None and index > last_bear_index
                     and buy_price > last_bear_high)
        sell_break = (pending is None and daily_allowed and can_sell and htf_sell_allowed
                      and ema_sell_allowed and setup_consolidation_allowed and bearish
                      and last_bull_low is not None and index > last_bull_index
                      and sell_price < last_bull_low)
        if buy_break or sell_break:
            pending = {
                "direction": "BUY" if buy_break else "SELL",
                "index": index,
                "setup_at": bar["end"],
                "break_high": bar["high"],
                "break_low": bar["low"],
                "break_mid": (bar["high"] + bar["low"]) / 2.0,
                "tracked_level": last_bear_high if buy_break else last_bull_low,
            }

        next_candle = pending is not None and index == pending["index"] + 1
        buy_signal = (daily_allowed and next_candle and pending["direction"] == "BUY"
                      and htf_buy_allowed and ema_buy_allowed and confirmation_consolidation_allowed
                      and bar["close"] > pending["break_mid"])
        sell_signal = (daily_allowed and next_candle and pending["direction"] == "SELL"
                       and htf_sell_allowed and ema_sell_allowed and confirmation_consolidation_allowed
                       and bar["close"] < pending["break_mid"])
        if buy_signal or sell_signal:
            direction = "BUY" if buy_signal else "SELL"
            last_signal = 1 if buy_signal else -1
            signals_today += 1
            events.append({
                "direction": direction,
                "confirmed_at": bar["end"],
                "confirmation_close": bar["close"],
                **{key: pending[key] for key in (
                    "setup_at", "break_high", "break_low", "break_mid", "tracked_level",
                )},
            })
        if pending is not None and index >= pending["index"] + 1:
            pending = None

        if bullish:
            last_bull_low = bar["low"]
            last_bull_index = index
        if bearish:
            last_bear_high = bar["high"]
            last_bear_index = index

    latest_event = events[-1] if events else None
    if latest_event and latest_event["confirmed_at"] == bars[-1]["end"]:
        status = latest_event["direction"]
    elif pending is not None:
        status = "PENDING_" + pending["direction"]
    else:
        status = "NONE"
    return {
        "status": status,
        "as_of": bars[-1]["end"],
        "bar_count": len(bars),
        "last_event": latest_event,
        "pending": ({key: value for key, value in pending.items() if key != "index"}
                    if pending is not None else None),
        "events": events,
        "tracked_levels": {"bull_low": last_bull_low, "bear_high": last_bear_high},
        "settings": {key: config[key] for key in DEFAULT_SETTINGS if key not in (
            "enabled", "timeframes", "immediate_email", "daily_digest",
        )},
    }


def _aware(now):
    if not isinstance(now, datetime) or now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be a timezone-aware datetime")
    return now.astimezone(UTC)


def _rule_identity(rule):
    symbol = rule.get("symbol")
    market = rule.get("market", "HK" if isinstance(symbol, str) and symbol.endswith(".HK") else "US")
    if not isinstance(symbol, str) or not symbol or market not in MARKETS:
        raise ValueError("Invalid signal symbol or market")
    pattern = r"[0-9]{4,5}\.HK" if market == "HK" else r"[A-Z][A-Z0-9.-]{0,9}"
    if not re.fullmatch(pattern, symbol) or (market == "US" and symbol.endswith(".HK")):
        raise ValueError("Invalid signal symbol for market")
    currency = rule.get("currency", MARKETS[market]["currency"])
    if currency != MARKETS[market]["currency"]:
        raise ValueError("Signal currency does not match market")
    return symbol, market, currency


def _session_dates(start, end, market):
    result = []
    for year in range(start.year, end.year + 1):
        calendar = _calendar(year, market)
        low = max(start, calendar.first_session.date())
        high = min(end, calendar.last_session.date())
        if low <= high:
            result.extend(stamp.date().isoformat()
                          for stamp in calendar.sessions_in_range(low.isoformat(), high.isoformat()))
    return result


@lru_cache(maxsize=1024)
def session_slots(day, market, minutes=15):
    """Return exchange-aligned regular-session candle boundaries in UTC."""
    calendar = _calendar(int(day[:4]), market)
    if not calendar.is_session(day):
        return ()
    opening = calendar.session_open(day).to_pydatetime().astimezone(UTC)
    closing = calendar.session_close(day).to_pydatetime().astimezone(UTC)
    segments = [(opening, closing)]
    if calendar.session_has_break(day):
        segments = [
            (opening, calendar.session_break_start(day).to_pydatetime().astimezone(UTC)),
            (calendar.session_break_end(day).to_pydatetime().astimezone(UTC), closing),
        ]
    result = []
    for start, stop in segments:
        while start < stop:
            end = min(start + timedelta(minutes=minutes), stop)
            result.append((start, end))
            start = end
    return tuple(result)


def _completed_slots(start, now, market, minutes):
    return [slot for day in _session_dates(start.date(), now.date(), market)
            for slot in session_slots(day, market, minutes)
            if slot[1] <= now - INTRADAY_GRACE]


def _latest_expected_end(now, market, minutes):
    slots = _completed_slots(now - timedelta(days=10), now, market, minutes)
    return slots[-1][1] if slots else None


def signal_market_due(now, market):
    """Keep polling briefly after a regular segment so its final bar is observed."""
    now = _aware(now)
    latest = _latest_expected_end(now, market, 15)
    return latest is not None and timedelta(0) <= now - latest <= timedelta(minutes=45)


def fetch_intraday_payload(symbol, now, recent=False):
    start = int((now - timedelta(days=5 if recent else 59)).timestamp())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?period1={start}"
           f"&period2={int(now.timestamp())}&interval=15m&includePrePost=false&events=splits")
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read(5_000_001)
        if len(raw) > 5_000_000:
            raise ValueError("Intraday provider response too large")
        return json.loads(raw)
    except urllib.error.HTTPError as exc:
        raise ValueError(f"Intraday provider HTTP {exc.code}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise ValueError("Intraday provider unavailable or timed out") from exc


def parse_intraday_payload(rule, payload, now):
    """Validate and retain only completed regular-session 15-minute candles."""
    now = _aware(now)
    symbol, market, currency = _rule_identity(rule)
    try:
        chart = payload["chart"]
        if chart.get("error"):
            raise ValueError("Intraday provider returned an error")
        result = chart["result"][0]
        meta = result["meta"]
        if (str(meta.get("symbol", "")).upper() != symbol.upper()
                or meta.get("currency") != currency
                or meta.get("exchangeTimezoneName") != MARKETS[market]["timezone"]
                or meta.get("dataGranularity") != "15m"):
            raise ValueError("Intraday symbol, currency, exchange, or interval mismatch")
        stamps = result.get("timestamp", [])
        quote = result["indicators"]["quote"][0]
        fields = ("open", "high", "low", "close", "volume")
        if not stamps or any(not isinstance(quote.get(name), list)
                             or len(quote[name]) != len(stamps) for name in fields):
            raise ValueError("Intraday OHLCV arrays are absent or mismatched")
        bars = []
        previous = None
        exchange_zone = ZoneInfo(MARKETS[market]["timezone"])
        for index, raw_stamp in enumerate(stamps):
            epoch = _finite(raw_stamp, "timestamp")
            if epoch != int(epoch):
                raise ValueError("Intraday timestamps must be whole seconds")
            start = datetime.fromtimestamp(epoch, UTC)
            if previous is not None and start <= previous:
                raise ValueError("Intraday timestamps are duplicate or unordered")
            if start > now + timedelta(minutes=5):
                raise ValueError("Intraday provider returned a future timestamp")
            previous = start
            day = start.astimezone(exchange_zone).date().isoformat()
            end = dict(session_slots(day, market)).get(start)
            if end is None or end > now - INTRADAY_GRACE:
                continue
            if any(quote[name][index] is None for name in fields):
                continue
            row = {name: _finite(quote[name][index], name, allow_zero=name == "volume") for name in fields}
            if (row["high"] < max(row["open"], row["close"], row["low"])
                    or row["low"] > min(row["open"], row["close"], row["high"])):
                raise ValueError("Intraday OHLC bounds are inconsistent")
            bars.append({"date": start.isoformat(), "end": end.isoformat(), **row})
        if not bars:
            raise ValueError("No completed regular-session 15-minute candles")
        return bars
    except (KeyError, TypeError, IndexError, OverflowError, OSError) as exc:
        raise ValueError("Intraday provider response lacks usable OHLCV data") from exc


def aggregate_hourly(bars, market, now):
    """Aggregate only complete, exchange-aligned groups of 15-minute candles."""
    now = _aware(now)
    bars = _normalize_bars(bars)
    by_start = {bar["date"]: bar for bar in bars}
    first = _instant(bars[0]["date"])
    result = []
    for opening, closing in _completed_slots(first, now, market, 60):
        required = []
        cursor = opening
        while cursor < closing:
            required.append(cursor.isoformat())
            cursor += timedelta(minutes=15)
        if any(stamp not in by_start for stamp in required):
            continue
        group = [by_start[stamp] for stamp in required]
        result.append({
            "date": opening.isoformat(), "end": closing.isoformat(),
            "open": group[0]["open"], "high": max(bar["high"] for bar in group),
            "low": min(bar["low"] for bar in group), "close": group[-1]["close"],
            "volume": sum(bar.get("volume", 0.0) for bar in group),
            "duration_minutes": int((closing - opening).total_seconds() / 60),
        })
    return result


def _daily_bars(history, market):
    bars = []
    for bar in history:
        day = bar["date"]
        close = _calendar(int(day[:4]), market).session_close(day).to_pydatetime().astimezone(UTC)
        bars.append({**bar, "end": close.isoformat()})
    return bars


def aggregate_weekly(bars, market):
    """Build completed exchange weeks for the optional daily higher-timeframe gate."""
    groups = {}
    for bar in bars:
        day = date.fromisoformat(bar["date"][:10])
        groups.setdefault(day.isocalendar()[:2], []).append(bar)
    result = []
    for group in groups.values():
        first_day = date.fromisoformat(group[0]["date"][:10])
        monday = first_day - timedelta(days=first_day.weekday())
        expected = _session_dates(monday, monday + timedelta(days=6), market)
        if not expected or [bar["date"][:10] for bar in group] != expected:
            continue
        result.append({
            "date": group[0]["date"], "end": group[-1]["end"],
            "open": group[0]["open"], "high": max(bar["high"] for bar in group),
            "low": min(bar["low"] for bar in group), "close": group[-1]["close"],
            "volume": sum(bar.get("volume", 0.0) for bar in group),
        })
    return result


def _bars_agree(left, right):
    return all(math.isclose(left[name], right[name], rel_tol=1e-6, abs_tol=1e-9)
               for name in ("open", "high", "low", "close", "volume"))


def _atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _unavailable(timeframe, now, reason):
    return {"timeframe": timeframe, "status": "UNAVAILABLE", "as_of": None,
            "checked_at": now.isoformat(), "reasons": [reason], "last_event": None,
            "pending": None, "tracked_levels": {}}


class BuySellSignalService:
    """Provide validated 15m/1h/1d signal snapshots without touching alert state."""

    def __init__(self, folder, config, *, read_only=False, intraday_fetcher=None,
                 daily_service=None, clock=None):
        self.folder = Path(folder)
        self.settings = signal_settings(config)
        self.read_only = read_only
        self.intraday_fetcher = intraday_fetcher or fetch_intraday_payload
        self.clock = clock or (lambda: datetime.now(UTC))
        self.daily_service = daily_service or DailyHistoryService(
            self.folder.parent / "daily-history", config, read_only=read_only)
        self._locks_guard = threading.Lock()
        self._locks = {}

    def _cache_path(self, market, symbol):
        return self.folder / "history" / f"{market}-{symbol}.json"

    def _read_cache(self, path):
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            return {}

    def _validated_cache_bars(self, entry, market, now):
        bars = _normalize_bars(entry["bars"])
        previous = None
        exchange_zone = ZoneInfo(MARKETS[market]["timezone"])
        for bar in bars:
            start = _instant(bar["date"])
            end = _instant(bar["end"])
            day = start.astimezone(exchange_zone).date().isoformat()
            if dict(session_slots(day, market)).get(start) != end or end > now - INTRADAY_GRACE:
                raise ValueError("Cached intraday candle has an invalid session boundary")
            if previous is not None and start <= previous:
                raise ValueError("Cached intraday candles are unordered")
            previous = start
        return bars

    def _intraday_bars(self, rule, now):
        symbol, market, currency = _rule_identity(rule)
        path = self._cache_path(market, symbol)
        with self._locks_guard:
            lock = self._locks.setdefault(symbol, threading.Lock())
        with lock:
            entry = self._read_cache(path)
            valid = (entry.get("version") == INTRADAY_CACHE_VERSION
                     and entry.get("symbol") == symbol and entry.get("market") == market
                     and entry.get("currency") == currency)
            bars = None
            fetched = None
            if valid and entry.get("bars"):
                try:
                    bars = self._validated_cache_bars(entry, market, now)
                    fetched = _aware(datetime.fromisoformat(entry["fetched_at"]))
                    if fetched > now:
                        raise ValueError("Intraday cache is dated in the future")
                except (KeyError, TypeError, ValueError):
                    valid = False
                    bars = None
                    fetched = None
            expected = _latest_expected_end(now, market, 15)
            if expected is None:
                raise ValueError("No recently completed regular-session candle")
            if bars and _instant(bars[-1]["end"]) >= expected:
                return bars
            retry_after = entry.get("retry_after") if valid else None
            if retry_after:
                try:
                    retry = _aware(datetime.fromisoformat(retry_after))
                except (TypeError, ValueError):
                    retry = None
                if retry is not None and now < retry:
                    if bars:
                        return bars
                    raise ValueError(entry.get("error", "Intraday provider retry is pending"))
            attempted = False
            try:
                attempted = True
                recent = bool(bars and fetched and fetched.date() == now.date())
                fresh = parse_intraday_payload(rule, self.intraday_fetcher(symbol, now, recent), self.clock())
                if recent:
                    old = {bar["date"]: bar for bar in bars}
                    overlap = [bar for bar in fresh if bar["date"] in old]
                    if len(overlap) < 3 or any(not _bars_agree(bar, old[bar["date"]]) for bar in overlap):
                        fresh = parse_intraday_payload(
                            rule, self.intraday_fetcher(symbol, now, False), self.clock())
                    else:
                        old.update({bar["date"]: bar for bar in fresh})
                        fresh = sorted(old.values(), key=lambda bar: bar["date"])
                cutoff = now - timedelta(days=60)
                bars = [bar for bar in fresh if _instant(bar["date"]) >= cutoff]
                entry = {"version": INTRADAY_CACHE_VERSION, "symbol": symbol, "market": market,
                         "currency": currency, "fetched_at": now.isoformat(), "bars": bars}
                if not self.read_only:
                    _atomic_json(path, entry)
                return bars
            except Exception as exc:
                reason = f"Intraday evidence unavailable ({type(exc).__name__}): {str(exc)[:160]}"
                if attempted and not self.read_only:
                    failure = {**entry, "version": INTRADAY_CACHE_VERSION, "symbol": symbol,
                               "market": market, "currency": currency, "error": reason,
                               "retry_after": (now + timedelta(minutes=5)).isoformat()}
                    try:
                        _atomic_json(path, failure)
                    except OSError:
                        pass
                raise ValueError(reason) from exc

    def _evaluate_timeframe(self, timeframe, bars, higher, market, now):
        if not bars:
            return _unavailable(timeframe, now, "No completed candles available")
        if timeframe in ("15m", "1h"):
            minutes = 15 if timeframe == "15m" else 60
            expected = _latest_expected_end(now, market, minutes)
            last_end = _instant(bars[-1]["end"])
            if expected is None or last_end > expected or expected - last_end > MAX_INTRADAY_LAG:
                return _unavailable(timeframe, now, "Latest completed candle is unavailable or delayed beyond 20 minutes")
            delay_seconds = int((expected - last_end).total_seconds())
        else:
            delay_seconds = 0
        try:
            result = evaluate_bars(bars, options=self.settings,
                                   timezone=MARKETS[market]["timezone"], higher_bars=higher)
            result.pop("events", None)
            result.pop("settings", None)
            result.update(timeframe=timeframe, checked_at=now.isoformat(),
                          source=INTRADAY_SOURCE if timeframe != "1d" else "Validated completed daily OHLCV",
                          delay_seconds=delay_seconds, reasons=[])
            return result
        except Exception as exc:
            return _unavailable(timeframe, now, f"Signal evaluation failed ({type(exc).__name__})")

    def evaluate(self, rule, now):
        now = _aware(now)
        symbol, market, _ = _rule_identity(rule)
        unavailable_reason = None
        try:
            intraday = self._intraday_bars(rule, now)
            hourly = aggregate_hourly(intraday, market, now)
        except Exception as exc:
            intraday = hourly = []
            unavailable_reason = str(exc)[:240]
        daily_reason = None
        try:
            history = self.daily_service.get_history(rule, now)
            expected = expected_completed_session(
                now, market, self.daily_service.grace)
            if history.get("status") != "AVAILABLE" or history.get("as_of") != expected:
                raise ValueError("Latest completed daily session is unavailable")
            daily = _daily_bars(history["bars"], market)
            weekly = aggregate_weekly(daily, market) if self.settings["use_htf_bias"] else []
        except Exception as exc:
            daily = weekly = []
            daily_reason = str(exc)[:240]
        data = {"15m": (intraday, hourly), "1h": (hourly, daily), "1d": (daily, weekly)}
        results = {}
        for timeframe in TIMEFRAMES:
            if timeframe not in self.settings["timeframes"]:
                continue
            bars, higher = data[timeframe]
            if not bars:
                reason = daily_reason if timeframe == "1d" else unavailable_reason
                results[timeframe] = _unavailable(timeframe, now, reason or "Signal evidence unavailable")
            else:
                results[timeframe] = self._evaluate_timeframe(timeframe, bars, higher, market, now)
        actionable = [value["status"] for value in results.values()
                      if value["status"] in ("BUY", "SELL")]
        if "BUY" in actionable and "SELL" in actionable:
            summary = "MIXED"
        elif actionable:
            summary = actionable[0]
        elif any(value["status"].startswith("PENDING_") for value in results.values()):
            summary = "PENDING"
        elif results and all(value["status"] == "UNAVAILABLE" for value in results.values()):
            summary = "UNAVAILABLE"
        else:
            summary = "NONE"
        return {"symbol": symbol, "status": summary, "checked_at": now.isoformat(),
                "timeframes": results,
                "scope": "Completed regular-session candles; signals are mechanical research alerts, not orders."}

    def evaluate_many(self, rules, now):
        results = {}
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = {pool.submit(self.evaluate, rule, now): rule["symbol"] for rule in rules}
            for future in as_completed(futures):
                symbol = futures[future]
                try:
                    results[symbol] = future.result()
                except Exception as exc:
                    results[symbol] = {"symbol": symbol, "status": "UNAVAILABLE",
                                       "checked_at": _aware(now).isoformat(), "timeframes": {},
                                       "scope": f"Signal service unavailable ({type(exc).__name__})."}
        return results

    __call__ = evaluate


def load_alert_state(path):
    path = Path(path)
    if not path.exists():
        return {"version": ALERT_STATE_VERSION, "symbols": {}, "pending": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if (not isinstance(value, dict) or value.get("version") != ALERT_STATE_VERSION
            or not isinstance(value.get("symbols"), dict)
            or not isinstance(value.get("pending"), dict)):
        raise ValueError("Buy/sell signal state is invalid; refusing to risk duplicate delivery")
    for event_id, event in value["pending"].items():
        if (not isinstance(event_id, str) or not isinstance(event, dict)
                or not isinstance(event.get("recipients"), list)
                or not isinstance(event.get("ack"), list)):
            raise ValueError("Buy/sell pending delivery state is invalid")
    return value


def _event_id(symbol, timeframe, event):
    identity = f"{symbol}:{timeframe}:{event['direction']}:{event['confirmed_at']}"
    return hashlib.sha256(identity.encode()).hexdigest()[:32]


def signal_alert_text(events):
    event_labels = [f"{event['symbol']} {event['timeframe']} {event['direction']}" for event in events]
    labels = ", ".join(event_labels[:6])
    if len(event_labels) > 6:
        labels += f" +{len(event_labels) - 6} more"
    title = "Confirmed candle signal: " + labels
    lines = [
        "CONFIRMED BUY/SELL CANDLE SIGNAL",
        "Mechanical research alert only; this is not an order or investment recommendation.",
        "Signals use completed regular-session candles and the configured filters.",
    ]
    for event in events:
        lines.extend([
            "",
            f"{event['symbol']} | {event['timeframe']} | {event['direction']}",
            f"Confirmation candle closed: {event['confirmed_at']}",
            f"Confirmation close: {event['confirmation_close']}",
            f"Break candle closed: {event['setup_at']}",
            f"Break candle high / low / 50%: {event['break_high']} / {event['break_low']} / {event['break_mid']}",
            f"Broken tracked level: {event['tracked_level']}",
            f"Event: {event['id']}",
        ])
    lines.extend(["", "Confirm current price, liquidity, fundamentals, valuation, portfolio fit, and risk before acting."])
    return title, "\n".join(lines)


def run_alert_cycle(config, rules, now, service, state_path, sender, *, dry_run=False):
    """Evaluate current candles and journal each new event before email delivery."""
    options = signal_settings(config)
    if not options["enabled"] or not options["immediate_email"]:
        return 0
    email = config.get("alerts", {}).get("email", {})
    if not email.get("enabled"):
        return 0
    recipients = list(dict.fromkeys(f"email:{address}" for address in email.get("to", [])))
    state = load_alert_state(state_path)
    if dry_run:
        state = copy.deepcopy(state)
    enabled_rules = [rule for rule in rules if rule.get("enabled", True)]
    snapshots = service.evaluate_many(enabled_rules, now)
    for rule in enabled_rules:
        symbol = rule["symbol"]
        snapshot = snapshots[symbol]
        state.setdefault("latest", {})[symbol] = snapshot
        trackers = state["symbols"].setdefault(symbol, {})
        for timeframe, assessment in snapshot.get("timeframes", {}).items():
            as_of = assessment.get("as_of")
            if not as_of:
                continue
            previous = trackers.get(timeframe)
            if previous is not None and _instant(as_of) <= _instant(previous):
                continue
            trackers[timeframe] = as_of
            event = assessment.get("last_event")
            if (previous is None or assessment.get("status") not in ("BUY", "SELL")
                    or not isinstance(event, dict) or event.get("confirmed_at") != as_of):
                continue
            event_id = _event_id(symbol, timeframe, event)
            state["pending"].setdefault(event_id, {
                "id": event_id, "symbol": symbol, "timeframe": timeframe,
                **{key: event[key] for key in (
                    "direction", "confirmed_at", "confirmation_close", "setup_at",
                    "break_high", "break_low", "break_mid", "tracked_level",
                )},
                "created_at": _aware(now).isoformat(), "recipients": recipients, "ack": [],
            })
    state["checked_at"] = _aware(now).isoformat()
    persist = lambda: _atomic_json(state_path, state)
    if not dry_run:
        persist()
    errors = 0
    for channel in recipients:
        events = [event for event in state["pending"].values()
                  if channel in event["recipients"] and channel not in event["ack"]]
        if not events:
            continue
        title, body = signal_alert_text(events)
        if dry_run:
            continue
        try:
            sender(channel, title, body)
        except Exception as exc:
            LOG.error("Buy/sell signal delivery failed for %s (%s)", channel, type(exc).__name__)
            errors += 1
        else:
            for event in events:
                event["ack"].append(channel)
            persist()
            LOG.info("Buy/sell signal delivery accepted for %s: %s", channel, title)
    active = set(recipients)
    completed = [event_id for event_id, event in state["pending"].items()
                 if all(recipient in event["ack"] or recipient not in active
                        for recipient in event["recipients"])]
    for event_id in completed:
        del state["pending"][event_id]
    if not dry_run:
        persist()
    return 1 if errors else 0