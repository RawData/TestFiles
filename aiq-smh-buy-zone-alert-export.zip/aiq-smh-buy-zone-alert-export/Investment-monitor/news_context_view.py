"""Safe, local rendering of persisted news analysis.

This module deliberately does not fetch URLs or call a model.  The JSON is an
untrusted boundary: model prose is escaped and links come only from the
validated source table.
"""
from datetime import datetime, timezone
import html
import json
from pathlib import Path
from urllib.parse import urlparse

STATUSES = {"CURRENT", "UNAVAILABLE", "INSUFFICIENT_EVIDENCE", "DISABLED"}


def _stamp(value):
    if not isinstance(value, str):
        raise ValueError("timestamp must be a string")
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError("timestamps require a timezone")
    return result.astimezone(timezone.utc)


def _safe_url(value):
    if not isinstance(value, str):
        return None
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    if parsed.username or parsed.password:
        return None
    return value


def _validated_for_view(data, now):
    """Validate the fields needed by a direct (already loaded) render call."""
    if not isinstance(data, dict) or data.get("version") != 1 or data.get("status") not in STATUSES:
        return None, "Invalid news analysis"
    sources=data.get("sources",[])
    if not isinstance(sources,list) or any(not isinstance(s,dict) for s in sources):
        return None,"Invalid source table"
    ids=[s.get("id") for s in sources]
    if any(not isinstance(i,str) for i in ids) or len(ids)!=len(set(ids)):
        return None,"Invalid or duplicate source IDs"
    if data.get("status")=="CURRENT" and not isinstance(data.get("analysis"),dict):
        return None,"Current analysis content missing"
    analysis=data.get("analysis",{})
    if isinstance(analysis,dict):
        if any(key in analysis and not isinstance(analysis[key],list) for key in ("drivers","scenarios","watch_items","limitations")):
            return None,"Invalid analysis arrays"
    if data.get("status")=="UNAVAILABLE" and not data.get("analysis") and not data.get("generated_at"):
        return {**data,"_expired":False},None
    try:
        generated, expires = _stamp(data["generated_at"]), _stamp(data["expires_at"])
        current = _stamp(now) if isinstance(now, str) else now
        if current.tzinfo is None or generated > current or expires <= generated:
            return None, "Invalid analysis dates"
    except (KeyError, TypeError, ValueError):
        return None, "Invalid analysis dates"
    return {**data, "_expired": current >= expires}, None


def load_news_analysis(path, now):
    """Read persisted analysis and return an explicit unavailable result on failure."""
    unavailable = lambda reason: {"version": 1, "status": "UNAVAILABLE", "reason": reason[:200]}
    if not path:
        return unavailable("No news analysis supplied.")
    try:
        data = json.loads(Path(path).read_text())
        if not isinstance(data, dict) or data.get("version") != 1:
            raise ValueError("Invalid news analysis version")
        status = data.get("status")
        if status not in STATUSES:
            raise ValueError("Invalid news analysis status")
        generated, expires = _stamp(data["generated_at"]), _stamp(data["expires_at"])
        current = _stamp(now) if isinstance(now, str) else now
        if current.tzinfo is None:
            raise ValueError("now requires a timezone")
        if generated > current or expires <= generated:
            raise ValueError("Invalid analysis dates")
        sources = data.get("sources", [])
        if not isinstance(sources, list):
            raise ValueError("Invalid sources")
        for source in sources:
            if not isinstance(source, dict) or not source.get("id") or not _safe_url(source.get("url")):
                raise ValueError("Invalid source URL")
        checked,error=_validated_for_view(data,current)
        if error:raise ValueError(error)
        if current >= expires:
            # Keep the record for historical rendering while preventing callers
            # from treating its bias as a current signal.
            return {**data, "status": "UNAVAILABLE", "reason": "News analysis expired; historical context only."}
        return data
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        return unavailable(str(exc))


def _parts(data, now):
    """Return plain text fragments and source links for shared rendering."""
    data, validation_error = _validated_for_view(data, now)
    if validation_error:
        return ["News analysis unavailable: " + validation_error], []
    status = data.get("status", "UNAVAILABLE")
    reason = data.get("reason", "Not supplied")
    try:
        expired = data.get("_expired", False)
    except (TypeError, ValueError):
        expired = False
    historical = expired or reason == "News analysis expired; historical context only."
    lines = []
    if status == "UNAVAILABLE" and not historical:
        return ["News analysis unavailable: " + str(reason)], []
    if historical:
        lines.append("HISTORICAL NEWS ANALYSIS — expired; do not use its bias as current.")
    else:
        lines.append("Local model interpretation, not a verified recommendation.")
    if not historical:
        lines.append("Model: %s | Generated: %s | Expires: %s | Evidence count: %s" %
                     (data.get("model", "unknown"), data.get("generated_at", "unknown"),
                      data.get("expires_at", "unknown"), data.get("evidence_count", 0)))
        coverage=data.get("coverage",{})
        if isinstance(coverage,dict):
            lines.append("Evidence coverage: %s article texts; %s headline/snippet records; %s publishers. Source availability may be incomplete." %
                         (coverage.get("article_texts",0),coverage.get("headline_or_snippet",0),coverage.get("publishers",0)))
            excluded = coverage.get("excluded_irrelevant", 0) + coverage.get("excluded_low_quality", 0)
            if excluded or coverage.get("topics"):
                topics = coverage.get("topics", {})
                topic_text = ", ".join(sorted(map(str, topics))) if isinstance(topics, dict) and topics else "none"
                lines.append("Deterministic relevance curation: %s excluded; selected topics: %s." % (excluded, topic_text))
            unavailable=coverage.get("unavailable_sources")
            if unavailable is None:
                statuses=coverage.get("feed_statuses",{})
                unavailable=sorted(source_id for source_id, status in statuses.items()
                                   if status != "AVAILABLE") if isinstance(statuses,dict) else []
            if coverage.get("source_coverage")=="DEGRADED" or unavailable:
                lines.append("Source coverage: DEGRADED. Unavailable sources: " + ", ".join(map(str,unavailable)) + ". Directional bias is suppressed.")
    if status in {"INSUFFICIENT_EVIDENCE", "DISABLED"}:
        lines.append(str(reason or status.replace("_", " ").title()))
    analysis = data.get("analysis") if isinstance(data.get("analysis"), dict) else {}
    if analysis and not historical:
        bias = analysis.get("market_bias", "unclear")
        lines.append("Possible market pressure from selected news: " + str(bias))
        lines.append(str(analysis.get("summary", "")))
        if data.get("reason") in {"No analysis-quality portfolio or macro evidence; no model call made.",
                                  "Local model response rejected by grounding checks; no model commentary was retained."}:
            lines.append("Limited neutral digest: no local-model interpretation was generated.")
    links = []
    sources = {str(s.get("id")): s for s in data.get("sources", [])
               if isinstance(s, dict) and s.get("id") and _safe_url(s.get("url"))}
    labels = {"headline": "Source headline", "reported_fact": "Verified source quote", "interpretation": "Conditional interpretation",
              "evidence_quote": "Evidence quote", "confidence": "Confidence", "scope": "Scope",
              "name": "Name", "conditions": "Conditions", "implication": "Implication",
              "condition": "Condition", "why_it_matters": "Why it matters", "relevance_labels": "Relevance"}
    def add_item(prefix, item, fields, extra=()):
        if not isinstance(item, dict): return
        values = [labels.get(f, f) + ": " + str(item.get(f, "")) for f in fields if item.get(f)]
        values += [labels.get(f, f) + ": " + str(item.get(f, "")) for f in extra if item.get(f)]
        source_ids=item.get("source_ids",[])
        ids = [str(x) for x in source_ids if str(x) in sources] if isinstance(source_ids,list) else []
        links.extend((x, sources[x]) for x in ids)
        lines.append(prefix + " | ".join(values) + (" [" + ", ".join(ids) + "]" if ids else ""))
    if analysis and not historical:
        for item in analysis.get("drivers", []) or []:
            add_item("Driver: ", item, ("headline", "reported_fact", "interpretation"),
                     ("evidence_quote", "confidence", "scope"))
        for item in analysis.get("scenarios", []) or []:
            add_item("Scenario: ", item, ("name", "conditions", "implication"))
        for item in analysis.get("watch_items", []) or []:
            add_item("Watch: ", item, ("condition", "why_it_matters"))
        for item in analysis.get("limitations", []) or []:
            lines.append("Limitation: " + str(item))
    return lines, links


def news_analysis_text(data, now):
    lines, links = _parts(data, now)
    citations = ", ".join(f"{i} ({s['url']})" for i, s in links)
    return "\n".join(lines) + ("\nSources: " + citations if citations else "")


def render_news_analysis(data, now):
    """Render safe HTML; source URLs are selected from the source table only."""
    esc = lambda value: html.escape(str(value), quote=True)
    lines, links = _parts(data, now)
    out = ["<section class='news-analysis'>"]
    for index, line in enumerate(lines):
        tag = "h3" if index == 0 else "p"
        out.append(f"<{tag}>{esc(line)}</{tag}>")
    if links:
        out.append("<h4>Sources</h4><ul>")
        seen = set()
        for source_id, source in links:
            if source_id in seen: continue
            seen.add(source_id)
            url = _safe_url(source.get("url"))
            if not url:
                continue
            out.append(f"<li><a href='{esc(url)}'>{esc(source_id)}: {esc(source.get('title', source.get('publisher', 'Source')))}</a> · {esc(source.get('publisher',''))} · Published: {esc(source.get('published_at','unknown'))} · {esc(source.get('scope','scope unknown'))}</li>")
        out.append("</ul>")
    return "".join(out) + "</section>"
