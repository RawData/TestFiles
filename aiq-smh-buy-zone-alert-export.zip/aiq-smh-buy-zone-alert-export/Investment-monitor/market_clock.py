"""Independent NYSE and Hong Kong exchange sessions, expressed in UTC.

Every eligible session uses five-minute observation slots. HK skips lunch and waits until the end of
the closing auction (continuous close + ten minutes) for its closing check.
The provider's final quote must still pass freshness validation in monitor.py.
"""

from datetime import datetime, timedelta, timezone
from functools import lru_cache
from typing import TypedDict
from zoneinfo import ZoneInfo

import exchange_calendars as xcals


NEW_YORK = ZoneInfo("America/New_York")
MARKETS = {
    "US": {"calendar": "XNYS", "timezone": "America/New_York", "currency": "USD"},
    "HK": {"calendar": "XHKG", "timezone": "Asia/Hong_Kong", "currency": "HKD"},
}
OPEN_GRACE = timedelta(minutes=5)
CLOSE_GRACE = timedelta(minutes=20)
CHECK_INTERVAL = timedelta(minutes=5)


def observation_slot_start(now: datetime, segment_open: datetime) -> datetime:
    """Group wake-ups into five-minute checks without changing alert event identity."""
    elapsed = int((now - segment_open).total_seconds() // CHECK_INTERVAL.total_seconds())
    return segment_open + elapsed * CHECK_INTERVAL


class MarketSession(TypedDict):
    session_date: str
    open: datetime
    close: datetime
    slot: str
    market: str
    currency: str
    exchange_timezone: str
    break_start: datetime | None
    break_end: datetime | None
    closing_quote_min: datetime


@lru_cache(maxsize=8)
def _calendar(year: int, market: str = "US"):
    # Explicit bounds allow deterministic tests and avoid the package's
    # default end date becoming stale in a long-running process.
    return xcals.get_calendar(
        MARKETS[market]["calendar"], start=f"{year}-01-01", end=f"{year}-12-31"
    )


def market_session(now: datetime, market: str = "US") -> MarketSession | None:
    """Return the eligible session/slot; reject naive datetimes explicitly."""
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be a timezone-aware datetime")
    if market not in MARKETS:
        raise ValueError(f"Unsupported market: {market}")
    now_utc = now.astimezone(timezone.utc)
    exchange_zone = ZoneInfo(MARKETS[market]["timezone"])
    local_now = now_utc.astimezone(exchange_zone)
    session_date = local_now.date().isoformat()
    calendar = _calendar(local_now.year, market)
    if not calendar.is_session(session_date):
        return None

    market_open = calendar.session_open(session_date).to_pydatetime()
    continuous_close = calendar.session_close(session_date).to_pydatetime()
    # XHKG describes continuous trading; HKEX CAS can continue for ten minutes.
    market_close = continuous_close + (timedelta(minutes=10) if market == "HK" else timedelta())
    break_start = break_end = None
    segment_open = market_open
    if calendar.session_has_break(session_date):
        break_start = calendar.session_break_start(session_date).to_pydatetime()
        break_end = calendar.session_break_end(session_date).to_pydatetime()
        if break_start <= now_utc < break_end + OPEN_GRACE:
            return None
        if now_utc >= break_end:
            segment_open = break_end
    if not market_open + OPEN_GRACE <= now_utc <= market_close + CLOSE_GRACE:
        return None
    if market == "HK" and continuous_close <= now_utc < market_close:
        return None  # Wait for the auction instead of consuming the closing slot early.

    prefix = "" if market == "US" else f"{market}:"
    if now_utc >= market_close:
        slot_start = observation_slot_start(now_utc, market_close)
        slot = f"{prefix}{session_date}:{slot_start.astimezone(exchange_zone):%H:%M}:close"
    else:
        slot_start = observation_slot_start(now_utc, segment_open)
        slot = f"{prefix}{session_date}:{slot_start.astimezone(exchange_zone):%H:%M}"
    return {
        "session_date": session_date,
        "open": market_open.astimezone(timezone.utc),
        "close": market_close.astimezone(timezone.utc),
        "slot": slot,
        "market": market,
        "currency": MARKETS[market]["currency"],
        "exchange_timezone": MARKETS[market]["timezone"],
        "break_start": break_start,
        "break_end": break_end,
        "closing_quote_min": continuous_close - timedelta(minutes=1),
    }


def extended_market_session(now: datetime, market: str = "US") -> dict | None:
    """Return a separate US pre/post-market slot on an XNYS session day.

    This clock does not change regular-market eligibility. Pre-market ends
    strictly at the regular open; post-market has its own final-quote window.
    """
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be a timezone-aware datetime")
    if market not in MARKETS:
        raise ValueError(f"Unsupported market: {market}")
    if market != "US":
        return None

    now_utc = now.astimezone(timezone.utc)
    local_now = now_utc.astimezone(NEW_YORK)
    session_date = local_now.date().isoformat()
    calendar = _calendar(local_now.year, "US")
    if not calendar.is_session(session_date):
        return None

    regular_open = calendar.session_open(session_date).to_pydatetime()
    regular_close = calendar.session_close(session_date).to_pydatetime()
    pre_open = local_now.replace(hour=4, minute=0, second=0, microsecond=0).astimezone(timezone.utc)
    normal_close = local_now.replace(hour=16, minute=0, second=0, microsecond=0).astimezone(timezone.utc)
    post_end_hour = 17 if regular_close < normal_close else 20
    post_close = local_now.replace(hour=post_end_hour, minute=0, second=0, microsecond=0).astimezone(timezone.utc)

    if pre_open + OPEN_GRACE <= now_utc < regular_open:
        phase = "pre"
        phase_open, phase_close = pre_open, regular_open
        slot_start = observation_slot_start(now_utc, phase_open)
        slot_suffix = f"{slot_start.astimezone(NEW_YORK):%H:%M}"
    elif regular_close + OPEN_GRACE <= now_utc <= post_close + CLOSE_GRACE:
        phase = "post"
        phase_open, phase_close = regular_close, post_close
        if now_utc >= phase_close:
            slot_start = observation_slot_start(now_utc, phase_close)
            slot_suffix = f"{slot_start.astimezone(NEW_YORK):%H:%M}:close"
        else:
            slot_start = observation_slot_start(now_utc, phase_open)
            slot_suffix = f"{slot_start.astimezone(NEW_YORK):%H:%M}"
    else:
        return None

    return {
        "session_date": session_date,
        "open": phase_open.astimezone(timezone.utc),
        "close": phase_close.astimezone(timezone.utc),
        "slot": f"US:{phase}:{session_date}:{slot_suffix}",
        "market": "US",
        "currency": "USD",
        "exchange_timezone": "America/New_York",
        "break_start": None,
        "break_end": None,
        "closing_quote_min": phase_close - timedelta(minutes=1),
        "phase": phase,
    }
