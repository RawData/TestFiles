"""User-maintained holdings exposure with dated prices and ECB reference FX.

This is an exposure calculation, not a suitability approval. No arbitrary
position limits, automatic holdings expiry, ETF look-through, or buying-power
estimate. Treasury ETFs remain securities rather than spendable cash.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta
import hashlib
import json
import math
from pathlib import Path
import re
import threading
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

from technical_data import _atomic_json, _calendar, _utc, expected_completed_session
from market_clock import MARKETS

FX_SOURCE = "https://api.frankfurter.dev/v2/rates?base=USD&quotes={quotes}&providers=ECB&expand=providers"
CACHE_VERSION = 2
# Provider closing prints can be timestamped shortly after the bell. This
# tolerance applies only to portfolio reference marks, never entry alerts.
CLOSING_PRINT_GRACE_SECONDS = 60


def _number(value, *, positive=False):
    if isinstance(value, bool):
        raise ValueError("Portfolio numeric value cannot be boolean")
    value = float(value)
    if not math.isfinite(value) or value < 0 or (positive and value == 0):
        raise ValueError("Portfolio values must be finite and nonnegative")
    return value


def parse_fx(payload, currencies, now):
    """Require dated ECB observations; rates are local currency units per USD."""
    now = _utc(now)
    if not isinstance(payload, list):
        raise ValueError("Reference FX response is not an array")
    rates, dates = {"USD": 1.0}, set()
    for row in payload:
        if not isinstance(row, dict) or row.get("base") != "USD" or row.get("quote") not in currencies:
            raise ValueError("FX base or quote currency mismatch")
        currency = row["quote"]
        if currency in rates:
            raise ValueError("Duplicate FX currency")
        day = date.fromisoformat(row["date"])
        age = (now.date() - day).days
        if not 0 <= age <= 7:
            raise ValueError("Reference FX date is future or older than 7 calendar days")
        rate = _number(row["rate"], positive=True)
        providers = row.get("providers")
        if not isinstance(providers, list) or len(providers) != 1 or not isinstance(providers[0], dict):
            raise ValueError("FX lacks unambiguous ECB reference attribution; peg assumptions are not accepted")
        provider = providers[0]
        if provider.get("key") != "ECB" or provider.get("date") != row["date"] or not math.isclose(_number(provider.get("rate"), positive=True), rate, rel_tol=1e-9):
            raise ValueError("FX attribution/date/rate disagrees with ECB reference")
        rates[currency] = rate
        dates.add(day.isoformat())
    if set(rates) - {"USD"} != set(currencies):
        raise ValueError("Reference FX response is missing required currencies")
    if len(dates) != 1:
        raise ValueError("Reference FX currencies have different dates")
    return {"rates_per_usd": rates, "as_of": next(iter(dates)), "max_age_calendar_days": 7,
            "provider": "ECB", "basis": "Daily reference FX; not executable conversion prices"}


def fetch_fx(currencies):
    url = FX_SOURCE.format(quotes=",".join(sorted(currencies)))
    with urlopen(Request(url, headers={"Accept": "application/json", "User-Agent": "AroraPriceMonitor/1.0"}), timeout=12) as response:
        raw = response.read(100001)
    if len(raw) > 100000:
        raise ValueError("FX response exceeds size limit")
    return json.loads(raw)


def validate_reference_quote(symbol, quote, rule, now):
    """Reference marks may be the latest completed session or today's session.

    They are not executable entry quotes. In particular a cached prior close is
    permitted during a live session, and every returned mark keeps its time.
    """
    now = _utc(now)
    if hasattr(quote, "as_dict"):
        quote = quote.as_dict()
    if not isinstance(quote, dict):
        raise ValueError("Reference quote missing")
    market = rule.get("market", "HK" if symbol.endswith(".HK") else "US")
    if market not in MARKETS:
        raise ValueError("Reference quote market unsupported")
    currency = rule.get("currency", MARKETS[market]["currency"])
    if quote.get("symbol") != symbol or quote.get("currency") != currency or currency != MARKETS[market]["currency"]:
        raise ValueError("Reference quote identity/currency mismatch")
    stamp = _utc(datetime.fromisoformat(quote["timestamp"]))
    if stamp > now:
        raise ValueError("Reference quote timestamp is in the future")
    zone = ZoneInfo(MARKETS[market]["timezone"])
    local = stamp.astimezone(zone)
    day = local.date().isoformat()
    expected = expected_completed_session(now, market)
    if day < expected or day > now.astimezone(zone).date().isoformat():
        raise ValueError(f"Reference quote is stale: {day}; latest completed session {expected}")
    cal = _calendar(local.year, market)
    if day not in cal.sessions:
        raise ValueError("Reference quote date is not a trading session")
    opens = cal.session_open(day).to_pydatetime()
    closes = cal.session_close(day).to_pydatetime()
    phase = quote.get("phase", "regular")
    if phase == "regular":
        allowed = opens <= stamp <= closes + timedelta(minutes=10 if market == "HK" else 0, seconds=CLOSING_PRINT_GRACE_SECONDS)
    elif market == "US" and phase in ("pre", "pre-market"):
        # Supplied monitor chart-bar quotes retain their phase. A completed
        # extended-hours bar is a reference mark, never a daily close.
        allowed = local.hour >= 4 and stamp < opens
    elif market == "US" and phase in ("post", "post-market"):
        allowed = closes <= stamp < closes + timedelta(hours=4)
    else:
        allowed = False
    if not allowed:
        raise ValueError("Reference quote timestamp/phase is outside exchange hours")
    return {"symbol": symbol, "price": _number(quote["price"], positive=True), "currency": currency,
            "timestamp": stamp.isoformat(), "session": day, "phase": phase,
            "source": quote.get("source", "Supplied monitor quote"),
            "closing_print_grace_used": phase == "regular" and stamp > closes + timedelta(minutes=10 if market == "HK" else 0),
            "use": "Portfolio valuation reference; not an entry quote"}


class PortfolioService:
    def __init__(self, cache_dir, portfolio_path, rules, read_only=False, fetcher=None, fx_fetcher=None, *, allow_fallback=True):
        self.cache_dir, self.portfolio_path = Path(cache_dir), Path(portfolio_path)
        self.rules = {r["symbol"]: r for r in rules} if isinstance(rules, list) else dict(rules)
        self.read_only, self.fetcher, self.fx_fetcher = read_only, fetcher, fx_fetcher or fetch_fx
        self.allow_fallback = allow_fallback
        self._memory, self._lock = {}, threading.Lock()
        self._summary, self._positions = None, {}

    def _cached(self, key, now, loader, *, daily=False, force=False):
        path = self.cache_dir / (key + ".json")
        with self._lock:
            cached = self._memory.get(key)
            if cached is None:
                try:
                    cached = json.loads(path.read_text())
                except (OSError, ValueError):
                    cached = {}
        try:
            stamp = _utc(datetime.fromisoformat(cached["fetched_at"]))
            elapsed = (now-stamp).total_seconds()
            valid = cached["version"] == CACHE_VERSION and cached["key"] == key and elapsed >= 0
            valid = valid and (stamp.date() == now.date() if daily else elapsed < 3600)
            if cached.get("error"):
                valid = valid and elapsed < 300
        except (KeyError, TypeError, ValueError):
            valid = False
        if force or not valid:
            cached = {"version": CACHE_VERSION, "key": key, "fetched_at": now.isoformat()}
            try:
                cached["data"] = loader()
            except Exception as exc:
                cached["error"] = str(exc)[:200]
            with self._lock:
                self._memory[key] = cached
            if not self.read_only:
                _atomic_json(path, cached)
        if cached.get("error"):
            raise ValueError(cached["error"])
        return cached["data"], cached["fetched_at"]

    def _fallback(self, symbol, rule, now):
        if not self.allow_fallback:
            raise ValueError("No valid supplied reference; fallback disabled for this valuation")
        def load():
            # Import only when needed: monitor imports this module for checks.
            from monitor import fetch_payload, parse_quote
            raw = self.fetcher(symbol) if self.fetcher else fetch_payload(symbol)
            parsed = parse_quote(symbol, raw).as_dict() if isinstance(raw, dict) and "chart" in raw else raw
            return validate_reference_quote(symbol, parsed, rule, now)
        key = "portfolio-quote-" + symbol
        value, fetched = self._cached(key, now, load)
        # Revalidate the session even when a one-hour cache hasn't expired.
        try:
            value = validate_reference_quote(symbol, value, rule, now)
        except (ValueError, KeyError, TypeError):
            value, fetched = self._cached(key, now, load, force=True)
            value = validate_reference_quote(symbol, value, rule, now)
        return {**value, "fetched_at": fetched}

    def prepare(self, quote_map, now):
        now = _utc(now)
        self._positions = {}
        summary = {"status": "UNAVAILABLE", "complete": False, "checked_at": now.isoformat(),
                   "confirmed_at": None, "holdings_input_valid": False, "reasons": [], "scope": "Current exposure only; suitability to add unassessed",
                   "metrics": {"total_value_usd": None, "converted_cash_usd": None, "cash_usd": None,
                               "cash_by_currency": {}, "position_count": 0, "largest_positions": [],
                               "known_position_value_usd": 0.0, "known_cash_value_usd": 0.0}}
        self._summary = summary
        try:
            raw = self.portfolio_path.read_bytes()
            portfolio = json.loads(raw)
            confirmed = _utc(datetime.fromisoformat(portfolio["confirmed_at"]))
            if confirmed > now:
                raise ValueError("Portfolio confirmation timestamp is in the future")
            if portfolio.get("version") != 1 or portfolio.get("maintenance") != "user_updates_on_change" or portfolio.get("base_currency") != "USD":
                raise ValueError("Unsupported portfolio input version, maintenance mode or base currency")
            summary.update(confirmed_at=confirmed.isoformat(), maintenance=portfolio["maintenance"],
                           input_sha256=hashlib.sha256(raw).hexdigest(), source=str(self.portfolio_path))
            rows, cash = portfolio["positions"], portfolio["cash"]
            if not isinstance(rows, list) or not isinstance(cash, dict) or not rows:
                raise ValueError("Portfolio positions/cash are missing")
            currencies, holdings = set(), []
            for row in rows:
                symbol, currency = row["symbol"], row["currency"]
                if not re.fullmatch(r"[A-Z0-9][A-Z0-9.\-]{0,19}", symbol) or symbol in self._positions:
                    raise ValueError("Invalid or duplicate portfolio symbol")
                if symbol not in self.rules or self.rules[symbol].get("currency", "HKD" if symbol.endswith(".HK") else "USD") != currency:
                    raise ValueError("Portfolio security is missing a matching configured rule/currency: " + symbol)
                qty = _number(row["quantity"], positive=True)
                currencies.add(currency)
                record = {"symbol": symbol, "quantity": qty, "currency": currency,
                          "exposure_group": row.get("exposure_group"), "value_local": None,
                          "value_usd": None, "weight_pct": None, "quote": None}
                self._positions[symbol] = record
                holdings.append(record)
            cash = {currency: _number(amount) for currency, amount in cash.items()}
            currencies.update(cash)
            if any(not re.fullmatch(r"[A-Z]{3}", c) for c in currencies):
                raise ValueError("Invalid portfolio currency code")
            summary["holdings_input_valid"] = True
            metrics = summary["metrics"]
            metrics.update(position_count=len(holdings), cash_by_currency=cash, cash_usd=cash.get("USD", 0.0),
                           risk_limits=portfolio.get("risk_limits", {}), proposed_addition=None)
            fx_currencies = sorted(currencies - {"USD"})
            rates = {"USD": 1.0}
            if fx_currencies:
                try:
                    def load_fx():
                        return self.fx_fetcher(fx_currencies)
                    payload, fetched = self._cached("portfolio-fx-" + "-".join(fx_currencies), now, load_fx, daily=True)
                    fx = parse_fx(payload, fx_currencies, now)
                    rates = fx["rates_per_usd"]
                    metrics["fx"] = {**fx, "fetched_at": fetched, "source": FX_SOURCE.format(quotes=",".join(fx_currencies))}
                except (ValueError, KeyError, TypeError, OSError) as exc:
                    summary["reasons"].append("FX unavailable: " + str(exc))
            else:
                metrics["fx"] = {"rates_per_usd": rates, "as_of": None, "basis": "USD-only portfolio; no conversion needed"}
            def price_position(record):
                symbol = record["symbol"]
                rule = self.rules[symbol]
                try:
                    quote = validate_reference_quote(symbol, (quote_map or {}).get(symbol), rule, now)
                except (ValueError, KeyError, TypeError):
                    try:
                        quote = self._fallback(symbol, rule, now)
                    except Exception as exc:
                        return symbol, None, str(exc)
                return symbol, quote, None
            with ThreadPoolExecutor(max_workers=4) as pool:
                for symbol, quote, error in pool.map(price_position, holdings):
                    position = self._positions[symbol]
                    if error:
                        position["error"] = error
                        summary["reasons"].append(symbol + " valuation price unavailable: " + error)
                        continue
                    position["quote"] = quote
                    position["value_local"] = position["quantity"] * quote["price"]
                    if position["currency"] in rates:
                        position["value_usd"] = position["value_local"] / rates[position["currency"]]
            known_positions = sum(p["value_usd"] for p in holdings if p["value_usd"] is not None)
            known_cash = sum(amount/rates[c] for c, amount in cash.items() if c in rates)
            metrics.update(known_position_value_usd=known_positions, known_cash_value_usd=known_cash,
                           valued_position_count=sum(p["value_usd"] is not None for p in holdings),
                           valuation_basis="Latest accepted market references and daily ECB FX; mixed timestamps shown per holding")
            if all(c in rates for c in cash):
                metrics["converted_cash_usd"] = known_cash
            complete = all(p["value_usd"] is not None for p in holdings) and all(c in rates for c in cash)
            if complete:
                total = known_positions + known_cash
                if total <= 0:
                    raise ValueError("Portfolio valuation total must be positive")
                metrics["total_value_usd"] = total
                for p in holdings:
                    p["weight_pct"] = p["value_usd"] / total * 100
                summary.update(status="REVIEW", complete=True)
            else:
                summary["reasons"].append("Coverage is partial: total portfolio value and all weights are withheld.")
            metrics["largest_positions"] = sorted([p.copy() for p in holdings if p["value_usd"] is not None], key=lambda p: p["value_usd"], reverse=True)[:5]
            metrics["positions"] = [p.copy() for p in holdings]
            summary["reasons"].extend([
                "Holdings and cash are user-maintained; update them after any change. No automatic broker reconciliation.",
                ("Risk limits and a proposed purchase amount are unconfigured; suitability to add is not assessed."
                 if not portfolio.get("risk_limits") and not portfolio.get("proposed_additions") else
                 "This exposure-only module does not evaluate risk limits or proposed purchases; suitability to add is not assessed."),
                "Converted cash is a valuation estimate, not settled cash or broker buying power. Treasury ETFs remain investments.",
                "Fund exposure labels are descriptive; ETF holdings overlap and sector look-through are not calculated."])
        except (OSError, ValueError, KeyError, TypeError, OverflowError) as exc:
            summary.update(status="UNAVAILABLE", complete=False)
            summary["reasons"].append("Portfolio input/valuation unavailable: " + str(exc))
        return summary

    def evaluate(self, rule, now):
        now = _utc(now)
        summary = self._summary
        if summary is None:
            return {"status": "UNAVAILABLE", "complete": False, "checked_at": now.isoformat(),
                    "confirmed_at": None, "reasons": ["Portfolio valuation has not been prepared."], "metrics": {}}
        symbol = rule["symbol"]
        position = self._positions.get(symbol)
        total = summary["metrics"]["total_value_usd"]
        absent = 0.0 if summary.get("holdings_input_valid") else None
        metrics = {"position_quantity": position["quantity"] if position else absent,
                   "position_value_usd": position["value_usd"] if position else absent,
                   "position_weight_pct": position["weight_pct"] if position else (0.0 if total is not None else None),
                   "total_value_usd": total, "cash_usd": summary["metrics"]["cash_usd"],
                   "cash_by_currency": summary["metrics"]["cash_by_currency"],
                   "converted_cash_usd": summary["metrics"]["converted_cash_usd"],
                   "fx_reference": summary["metrics"].get("fx"),
                   "proposed_addition": None, "exposure_complete": summary["complete"],
                   "reference_quote": position["quote"] if position else None,
                   "exposure_group": position.get("exposure_group") if position else None}
        return {"status": "REVIEW" if summary["complete"] else "UNAVAILABLE", "complete": False,
                "checked_at": summary["checked_at"], "confirmed_at": summary["confirmed_at"],
                "source": str(self.portfolio_path), "scope": "Exposure only; no suitability approval",
                "reasons": summary["reasons"].copy(), "metrics": metrics}
