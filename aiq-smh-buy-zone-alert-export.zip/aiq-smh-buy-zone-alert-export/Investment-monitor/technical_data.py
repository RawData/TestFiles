"""Validated, completed-session daily OHLCV for deterministic technical checks.

The Yahoo daily quote arrays are used together: adjusted-close is never
substituted into raw OHLC. Yahoo supplies historical quote OHLC on its split
adjusted price basis; that corporate-action adjustment is vendor supplied, not
independently reconstructed here. No dividend/total-return adjustment is used.
No network operation, cache hit, or partial live bar can turn old history into
current history. An isolated session with no provider data is skipped (never
interpolated) up to a small tolerance; beyond that, failures are explicit and
retry after a five-minute backoff.
"""

from datetime import date, datetime, timedelta, timezone
import json
import math
import os
from pathlib import Path
import re
import tempfile
import threading
import urllib.error
import urllib.request
from zoneinfo import ZoneInfo

from market_clock import MARKETS, _calendar

UTC = timezone.utc
SOURCE = "Yahoo Finance daily OHLCV (unofficial; may be delayed)"
BASIS = "Vendor split-adjusted quote OHLC; no dividend adjustment or adjusted-close substitution"
CACHE_VERSION = 2
MAX_RESPONSE_BYTES = 2_000_000


def _utc(now):
    if not isinstance(now, datetime) or now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be a timezone-aware datetime")
    return now.astimezone(UTC)


def _rule_identity(rule):
    symbol = rule["symbol"].upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9.\-^=]{0,19}", symbol):
        raise ValueError("Invalid daily-history symbol")
    market = rule.get("market", "HK" if symbol.endswith(".HK") else "US")
    if market not in MARKETS:
        raise ValueError("Unsupported daily-history market")
    currency = rule.get("currency", MARKETS[market]["currency"])
    if currency != MARKETS[market]["currency"]:
        raise ValueError("Unexpected configured currency for market")
    return symbol, market, currency


def _sessions(start, end, market):
    """Get inclusive exchange sessions without assuming a calendar-year boundary."""
    result = []
    for year in range(start.year, end.year + 1):
        cal = _calendar(year, market)
        lo, hi = max(start, cal.first_session.date()), min(end, cal.last_session.date())
        if lo <= hi:
            result.extend(s.date().isoformat() for s in cal.sessions_in_range(lo.isoformat(), hi.isoformat()))
    return result


def expected_completed_session(now, market="US", publish_grace_minutes=20):
    """Most recent session whose close, HK auction and publish grace have elapsed.

    During a session, its close and the grace period, use the prior completed
    daily bar. HK's lunch is not a daily close. Calendar early closes and
    holidays are respected, including sessions in the previous calendar year.
    """
    now = _utc(now)
    if market not in MARKETS:
        raise ValueError("Unsupported daily-history market")
    if not isinstance(publish_grace_minutes, (int, float)) or not 0 <= publish_grace_minutes <= 120:
        raise ValueError("Invalid history publication grace")
    local_day = now.astimezone(ZoneInfo(MARKETS[market]["timezone"])).date()
    for offset in range(40):
        day = local_day - timedelta(days=offset)
        cal = _calendar(day.year, market)
        if day.isoformat() not in cal.sessions:
            continue
        closes = cal.session_close(day.isoformat()).to_pydatetime().astimezone(UTC)
        if market == "HK":
            closes += timedelta(minutes=10)
        if now >= closes + timedelta(minutes=publish_grace_minutes):
            return day.isoformat()
    raise ValueError("No recently completed exchange session found")


def _finite(value, field, allow_zero=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"Daily {field} is not numeric")
    number = float(value)
    if not math.isfinite(number) or number < 0 or (number == 0 and not allow_zero):
        raise ValueError(f"Daily {field} is not a valid finite value")
    return number


def _validate_bars(bars, expected, market, gap_window, max_missing):
    if not isinstance(bars, list) or not bars:
        raise ValueError("Daily history has no completed bars")
    last = None
    normalized = []
    for bar in bars:
        day = date.fromisoformat(bar["date"]).isoformat()
        if last is not None and day <= last:
            raise ValueError("Duplicate or unordered daily sessions")
        if day > expected:
            raise ValueError("Cache contains incomplete daily sessions")
        if day not in _calendar(int(day[:4]), market).sessions:
            raise ValueError("Daily history contains a non-trading date")
        record = {"date": day}
        for field in ("open", "high", "low", "close", "volume"):
            record[field] = _finite(bar[field], field, allow_zero=field == "volume")
        if record["high"] < max(record["open"], record["close"], record["low"]) or record["low"] > min(record["open"], record["close"], record["high"]):
            raise ValueError("Daily OHLC bounds are inconsistent")
        normalized.append(record)
        last = day
    recent = normalized[-gap_window:]
    expected_dates = _sessions(date.fromisoformat(recent[0]["date"]), date.fromisoformat(expected), market)
    have = {b["date"] for b in recent}
    missing = [d for d in expected_dates if d not in have]
    if len(missing) > max_missing:
        raise ValueError(f"Daily history has {len(missing)} missing exchange sessions in the latest analysis window (limit {max_missing})")
    return normalized, missing


def parse_daily_payload(rule, payload, now, *, publish_grace_minutes=20, gap_window=260, max_missing_sessions=5):
    """Validate provider identity/data, discard partial bars, require current history."""
    now = _utc(now)
    symbol, market, currency = _rule_identity(rule)
    expected = expected_completed_session(now, market, publish_grace_minutes)
    try:
        chart = payload["chart"]
        if chart.get("error"):
            raise ValueError("Daily provider returned an error")
        result = chart["result"][0]
        meta = result["meta"]
        if meta["symbol"].upper() != symbol:
            raise ValueError("Daily provider returned a different symbol")
        if meta["currency"] != currency:
            raise ValueError("Daily provider returned a different currency")
        if meta.get("exchangeTimezoneName") != MARKETS[market]["timezone"]:
            raise ValueError("Daily provider returned a different exchange timezone")
        if meta.get("dataGranularity") != "1d":
            raise ValueError("Daily history must use one-day bars")
        timestamps = result["timestamp"]
        quotes = result["indicators"]["quote"][0]
        if not isinstance(timestamps, list) or not timestamps:
            raise ValueError("Daily provider returned no timestamps")
        for field in ("open", "high", "low", "close", "volume"):
            if not isinstance(quotes[field], list) or len(quotes[field]) != len(timestamps):
                raise ValueError("Daily provider returned mismatched OHLCV arrays")
        bars = []
        previous_stamp = previous_day = None
        for index, stamp in enumerate(timestamps):
            stamp = _finite(stamp, "timestamp")
            if stamp != int(stamp):
                raise ValueError("Daily timestamps must be whole seconds")
            if previous_stamp is not None and stamp <= previous_stamp:
                raise ValueError("Duplicate or unordered daily timestamps")
            if stamp > now.timestamp():
                raise ValueError("Daily provider returned a future timestamp")
            day = datetime.fromtimestamp(stamp, UTC).astimezone(ZoneInfo(MARKETS[market]["timezone"])).date().isoformat()
            if previous_day is not None and day <= previous_day:
                raise ValueError("Daily provider returned duplicate session dates")
            if day not in _calendar(int(day[:4]), market).sessions:
                raise ValueError("Daily provider returned a non-trading date")
            previous_stamp, previous_day = stamp, day
            if day > expected:
                continue  # In-progress OHLCV may be null; it is never analysed or cached.
            row = {name: quotes[name][index] for name in ("open", "high", "low", "close", "volume")}
            if any(row[name] is None for name in row):
                # Skip a missing or incomplete provider row; never interpolate it.
                continue
            if (row["high"] < max(row["open"], row["close"], row["low"]) or
                    row["low"] > min(row["open"], row["close"], row["high"])):
                # Skip a vendor-inconsistent row (split-adjustment artifact);
                # skipped rows count toward the missing-session tolerance below.
                continue
            bars.append({"date": day, **row})
        bars, missing = _validate_bars(bars, expected, market, gap_window, max_missing_sessions)
        events = []
        for kind in ("splits", "dividends"):
            for event in result.get("events", {}).get(kind, {}).values():
                stamp = _finite(event["date"], "corporate action timestamp")
                if stamp > now.timestamp():
                    continue
                day = datetime.fromtimestamp(stamp, UTC).astimezone(ZoneInfo(MARKETS[market]["timezone"])).date().isoformat()
                item = {"type": kind, "date": day}
                if kind == "splits":
                    item["ratio"] = _finite(event["numerator"], "split numerator") / _finite(event["denominator"], "split denominator")
                else:
                    item["amount"] = _finite(event["amount"], "dividend", allow_zero=True)
                events.append(item)
        return {"status": "AVAILABLE", "bars": bars, "as_of": bars[-1]["date"],
                "expected_session": expected, "symbol": symbol, "market": market,
                "currency": currency, "source": SOURCE, "basis": BASIS,
                "fetched_at": now.isoformat(), "events": events,
                "missing_sessions": missing}
    except (KeyError, TypeError, IndexError, OverflowError, OSError) as exc:
        raise ValueError("Daily provider response lacks usable OHLCV history") from exc


def fetch_daily_payload(symbol):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?range=2y&interval=1d&includePrePost=false&events=div%2Csplits"
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            raw = response.read(MAX_RESPONSE_BYTES + 1)
        if len(raw) > MAX_RESPONSE_BYTES:
            raise ValueError("Daily provider response too large")
        return json.loads(raw)
    except urllib.error.HTTPError as exc:
        raise ValueError(f"Daily provider HTTP {exc.code}") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise ValueError("Daily provider unavailable or timed out") from exc


def _atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, allow_nan=False, separators=(",", ":"))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class DailyHistoryService:
    def __init__(self, cache_dir, config=None, *, fetcher=None, read_only=False):
        self.cache_dir = Path(cache_dir)
        self.config = (config or {}).get("technical_analysis", {})
        self.grace = self.config.get("publish_grace_minutes", 20)
        self.retry_seconds = self.config.get("retry_seconds", 300)
        self.gap_window = self.config.get("gap_window", 260)
        if isinstance(self.grace, bool) or not isinstance(self.grace, (int, float)) or not 0 <= self.grace <= 120:
            raise ValueError("Invalid daily-history publication grace")
        if isinstance(self.retry_seconds, bool) or not isinstance(self.retry_seconds, int) or not 1 <= self.retry_seconds <= 86400:
            raise ValueError("Invalid daily-history retry interval")
        if isinstance(self.gap_window, bool) or not isinstance(self.gap_window, int) or not 200 <= self.gap_window <= 600:
            raise ValueError("Daily-history gap window must be 200 to 600 sessions")
        self.max_missing = self.config.get("max_missing_sessions", 5)
        if isinstance(self.max_missing, bool) or not isinstance(self.max_missing, int) or not 0 <= self.max_missing <= 20:
            raise ValueError("Daily-history missing-session tolerance must be 0 to 20 sessions")
        self.fetcher = fetcher or fetch_daily_payload
        self.read_only = read_only
        self._memory = {}
        self._lock = threading.Lock()
        self._symbol_locks = {}

    def _read(self, path):
        if path in self._memory:
            return self._memory[path]
        try:
            with path.open(encoding="utf-8") as stream:
                entry = json.load(stream)
            return entry if isinstance(entry, dict) else {}
        except (OSError, ValueError):
            return {}

    def _write(self, path, entry):
        self._memory[path] = entry
        if not self.read_only:
            _atomic_json(path, entry)

    def get_history(self, rule, now):
        now = _utc(now)
        symbol, market, currency = _rule_identity(rule)
        expected = expected_completed_session(now, market, self.grace)
        path = self.cache_dir / f"{market}-{symbol}.json"
        with self._lock:
            lock = self._symbol_locks.setdefault(path, threading.Lock())
        with lock:
            entry = self._read(path)
            valid_entry = entry.get("version") == CACHE_VERSION and entry.get("symbol") == symbol and entry.get("market") == market
            if valid_entry:
                cached = entry.get("history", {})
                if cached.get("expected_session") == expected and cached.get("basis") == BASIS and cached.get("currency") == currency:
                    try:
                        fetched = _utc(datetime.fromisoformat(cached["fetched_at"]))
                        if fetched > now:
                            raise ValueError("Daily cache is dated in the future")
                        if expected_completed_session(fetched, market, self.grace) != expected:
                            raise ValueError("Daily cache was obtained before the session completed")
                        zone = ZoneInfo(MARKETS[market]["timezone"])
                        if fetched.astimezone(zone).date() != now.astimezone(zone).date():
                            raise ValueError("Refresh history on a new local date to check corporate actions")
                        bars, _ = _validate_bars(cached["bars"], expected, market, self.gap_window, self.max_missing)
                        if bars[-1]["date"] != expected and (now - fetched).total_seconds() >= self.retry_seconds:
                            raise ValueError("Retry provider for the missing latest completed session")
                        return {**cached, "bars": bars, "status": "AVAILABLE", "expected_session": expected, "cache_hit": True}
                    except (ValueError, KeyError, TypeError):
                        pass  # Corrupt/stale caches are never a technical pass.
                failure = entry.get("failure", {})
                try:
                    retry = _utc(datetime.fromisoformat(failure["retry_after"]))
                    failed_at = _utc(datetime.fromisoformat(failure["checked_at"]))
                    if failure.get("expected_session") == expected and failed_at <= now < retry:
                        return {**failure, "status": "UNAVAILABLE", "cache_hit": True}
                except (KeyError, ValueError, TypeError):
                    pass
            try:
                history = parse_daily_payload(rule, self.fetcher(symbol), now,
                                              publish_grace_minutes=self.grace, gap_window=self.gap_window,
                                              max_missing_sessions=self.max_missing)
                self._write(path, {"version": CACHE_VERSION, "symbol": symbol, "market": market, "history": history})
                return {**history, "cache_hit": False}
            except Exception as exc:
                # All provider/cache-write failures are fail-closed; no old PASS fallback.
                failure = {"status": "UNAVAILABLE", "symbol": symbol, "market": market,
                           "expected_session": expected, "as_of": None, "source": SOURCE,
                           "basis": BASIS, "checked_at": now.isoformat(),
                           "retry_after": (now + timedelta(seconds=self.retry_seconds)).isoformat(),
                           "reasons": [f"Daily history unavailable: {str(exc)[:240]}"]}
                try:
                    self._write(path, {"version": CACHE_VERSION, "symbol": symbol, "market": market, "failure": failure})
                except OSError:
                    pass  # The caller still receives UNAVAILABLE even if storage failed.
                return failure

    def evaluate(self, rule, quote_dict, now):
        from technical_analysis import analyze_daily
        now = _utc(now)
        policy = rule.get("technical_policy", {})
        if policy.get("mode") == "nav_review":
            evaluation = analyze_daily([], live_price=quote_dict.get("price"), policy=policy)
            return {**evaluation, "checked_at": now.isoformat(), "source": SOURCE,
                    "basis": BASIS, "expected_session": None, "fetched_at": None}
        history = self.get_history(rule, now)
        if history["status"] != "AVAILABLE":
            return {**history, "schema_version": 1, "status": "UNAVAILABLE", "daily_status": "UNAVAILABLE",
                    "trend": "unknown", "metrics": {}, "live_check": {}, "policy": policy,
                    "checked_at": now.isoformat()}
        evaluation = analyze_daily(history["bars"], live_price=quote_dict.get("price"), policy=policy)
        if history["as_of"] != history["expected_session"]:
            evaluation["status"] = "UNAVAILABLE"
            evaluation["reasons"].insert(0, "Latest completed session is missing: data through " + history["as_of"] + "; expected " + history["expected_session"] + ". Older indicators are retained as dated context only.")
        if quote_dict.get("price") is not None:
            price = float(quote_dict["price"])
            close = history["bars"][-1]["close"]
            if price > 0 and max(price / close, close / price) >= 1.5:
                evaluation["status"] = "UNAVAILABLE"
                evaluation["reasons"].insert(0, "Current quote differs from the daily close by a factor of at least 1.5; verify a large gap, split or price-basis mismatch before using fixed levels.")
        missing = history.get("missing_sessions") or []
        if missing:
            shown = ", ".join(missing[:5]) + ("..." if len(missing) > 5 else "")
            evaluation["reasons"].append(f"Skipped {len(missing)} session(s) with no provider data ({shown}); analysis uses {len(history['bars'])} completed sessions and no prices were interpolated.")
        # Raw price patterns around distributions are not total-return signals.
        # Saved numeric zones are never silently rescaled after a split.
        zone_date = rule.get("zone_as_of", "2026-09-06")
        recent_start = history["bars"][-3]["date"] if len(history["bars"]) >= 3 else history["as_of"]
        events = history.get("events", [])
        if any(e["type"] == "splits" and e["date"] > zone_date for e in events):
            evaluation["status"] = "UNAVAILABLE"
            evaluation["reasons"].insert(0, "A split occurred after the saved zone date; manually review the fixed entry/stop/target levels before using this setup.")
        elif any(e["type"] == "dividends" and e["date"] >= recent_start and
                 e["amount"] / history["bars"][-1]["close"] >= 0.0025 for e in events):
            if evaluation["status"] == "PASS":
                evaluation["status"] = "WAIT"
            evaluation["reasons"].insert(0, "A recent distribution of at least 0.25% can affect the raw price chart; manually review ex-dividend/NAV effects before entry.")
        return {**evaluation, **{key: history[key] for key in ("expected_session", "source", "basis", "fetched_at", "cache_hit")},
                "checked_at": now.isoformat(), "corporate_actions": events[-8:]}

    __call__ = evaluate
