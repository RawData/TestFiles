#!/usr/bin/env python3
"""Preview or explicitly send a labelled delivery test, without reading prices or alert state."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import uuid

from monitor import DEFAULT_CONFIG, channel_names, load_config, runtime_home, send_channel


def run_test(config, home, *, send=False, sender=None):
    """Return independent per-channel outcomes; never read/write price-monitor state."""
    event_id = uuid.uuid4().hex
    timestamp = datetime.now(timezone.utc).isoformat()
    title = "TEST ONLY - Price monitor delivery check"
    # The shared Mac sender extracts rows containing '| saved zone'. State
    # classification is never invoked and no simulated market price is used.
    body = (
        "TEST ONLY: notification/email delivery check | saved zone NOT EVALUATED\n\n"
        "This is a delivery test you requested. No quote was fetched, no price signal\n"
        "was generated, and no trading action is suggested.\n"
        "Your live watchlist, pending alerts and delivery history are unchanged.\n"
        f"Time: {timestamp}\nEvent: {event_id}\n"
    )
    channels = channel_names(config)
    if not channels:
        raise ValueError("No notification channels are enabled in config.json")
    sender = sender or (lambda channel, subject, text: send_channel(channel, subject, text, config, home))
    results = []
    for channel in channels:
        if not send:
            results.append({"channel": channel, "status": "preview_only"})
            continue
        try:
            sender(channel, title, body)
        except Exception as exc:
            # Keep potentially sensitive SMTP server diagnostics out of logs.
            results.append({"channel": channel, "status": "failed", "error_type": type(exc).__name__})
        else:
            results.append({"channel": channel, "status": "accepted_by_sender"})
    return {"timestamp_utc": timestamp, "event_id": event_id, "test_only": True,
            "sent": send, "subject": title, "results": results}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--send", action="store_true",
                        help="Send one test to each enabled Mac/email destination; default only previews")
    args = parser.parse_args(argv)
    try:
        config = load_config(args.config)
        home = runtime_home()
        result = run_test(config, home, send=args.send)
        print(json.dumps(result, indent=2))
        if not args.send:
            print("Preview only. Add --send to send these labelled test messages.")
            return 0
        home.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(home / "test-delivery.jsonl", os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
        with os.fdopen(fd, "a") as handle:
            handle.write(json.dumps(result) + "\n")
        print("Check Notification Centre and each email inbox for the TEST ONLY message.")
        print("Sender acceptance does not confirm banner visibility or inbox delivery.")
        print(f"Test log: {home / 'test-delivery.jsonl'}")
        failed = any(row["status"] == "failed" for row in result["results"])
        if failed:
            print("A destination failed. Check email setup and macOS notification settings.")
        return 1 if failed else 0
    except Exception as exc:
        print(f"Test could not complete ({type(exc).__name__}). Check configuration and local email setup.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
