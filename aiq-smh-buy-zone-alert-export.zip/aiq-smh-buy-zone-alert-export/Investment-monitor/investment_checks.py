"""Dated public evidence and exposure checks. No AI, order placement or buy approval."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path

from fundamental_checks import FundamentalsService, _policy
from nav_checks import NavService
from portfolio_checks import PortfolioService


def validate_settings(config, config_path):
    settings = config.get("investment_analysis", {})
    if not isinstance(settings, dict) or not isinstance(settings.get("enabled", False), bool):
        raise ValueError("investment_analysis.enabled must be boolean")
    if set(settings) - {"enabled", "policies_file", "portfolio_file"}:
        raise ValueError("Unknown investment_analysis configuration field")
    if not settings.get("enabled"):
        return
    for key in ("policies_file", "portfolio_file"):
        if not isinstance(settings.get(key), str) or not settings[key].strip():
            raise ValueError(f"investment_analysis.{key} is required")
        settings[key] = str((Path(config_path).resolve().parent / settings[key]).resolve())
    policies = json.loads(Path(settings["policies_file"]).read_text())
    if policies.get("version") != 1 or not isinstance(policies.get("instruments"), dict):
        raise ValueError("Invalid investment policies file")
    for rule in config.get("watchlist", []):
        policy = policies["instruments"].get(rule["symbol"])
        if not isinstance(policy, dict):
            raise ValueError(f"Investment policies missing {rule['symbol']}")
        _policy({**rule, **policy})
        nav = policy.get("nav_policy", {})
        if nav.get("kind") not in {"etf", "cef", "not_applicable"}:
            raise ValueError(f"NAV security type missing for {rule['symbol']}")


def unavailable(reason, now):
    return {"status": "UNAVAILABLE", "complete": False, "checked_at": now.isoformat(),
            "as_of": None, "metrics": {}, "reasons": [reason]}


class InvestmentService:
    def __init__(self, config, home, *, read_only=False, nav=None, fundamentals=None, portfolio=None):
        settings = config["investment_analysis"]
        self.policies = json.loads(Path(settings["policies_file"]).read_text())["instruments"]
        cache = Path(home) / "investment-data"
        self.nav = nav or NavService(cache / "nav", read_only=read_only)
        self.fundamentals = fundamentals or FundamentalsService(cache / "fundamentals", read_only=read_only)
        self.portfolio = portfolio or PortfolioService(cache / "portfolio", settings["portfolio_file"],
                                                       config["watchlist"], read_only=read_only)

    def batch(self, rules, quote_map, now, *, clock=None):
        """One portfolio valuation per batch; source caches bound repeated public requests."""
        def check(rule):
            checked = clock() if clock else now
            enriched = {**rule, **self.policies.get(rule["symbol"], {})}
            result = {"overall": "REVIEW", "checked_at": checked.isoformat(),
                      "arora": {"status": "UNVERIFIED", "complete": False, "as_of": None,
                                "metrics": {}, "reasons": ["Latest Arora recommendation is not fetched. Saved zones retain their original source/date."]}}
            for key, service in (("nav", self.nav), ("fundamentals", self.fundamentals)):
                try:
                    value = service.evaluate(enriched, quote_map.get(rule["symbol"], {}), checked)
                    if value.get("status") not in {"PASS", "FAIL", "REVIEW", "UNAVAILABLE", "NOT_APPLICABLE"}:
                        raise ValueError("Invalid evidence status")
                    result[key] = value
                except Exception as exc:
                    result[key] = unavailable(f"{key.title()} check unavailable ({type(exc).__name__}).", checked)
            return rule["symbol"], result

        with ThreadPoolExecutor(max_workers=4) as pool:
            results = dict(pool.map(check, rules))
        checked = clock() if clock else now
        try:
            summary = self.portfolio.prepare(quote_map, checked)
        except Exception as exc:
            summary = unavailable(f"Portfolio valuation unavailable ({type(exc).__name__}).", checked)
        for rule in rules:
            result = results[rule["symbol"]]
            try:
                result["portfolio"] = self.portfolio.evaluate(rule, checked) if summary.get("metrics") else summary
            except Exception as exc:
                result["portfolio"] = unavailable(f"Portfolio exposure unavailable ({type(exc).__name__}).", checked)
            # No aggregate PASS: guidance/valuation, current Arora and risk limits are not verified.
            result["overall"] = "REVIEW"
            result["checked_at"] = checked.isoformat()
        return results, summary


def evidence_lines(investment):
    if not investment:
        return ["NAV, fundamental and portfolio evidence: not enabled for this observation."]
    lines = ["AUTOMATED INVESTMENT EVIDENCE - partial checks; no combined buy approval"]
    for key, label in (("nav", "NAV"), ("fundamentals", "Fundamentals"), ("portfolio", "Portfolio exposure"), ("arora", "Arora")):
        value = investment.get(key, {})
        date_label = "valuation checked" if key == "portfolio" else "evidence date"
        stamp = value.get("checked_at") if key == "portfolio" else value.get("as_of")
        lines.append(f"{label}: {value.get('status', 'UNAVAILABLE')} | {date_label}: {stamp or 'not available'}")
        if value.get("scope"):
            lines.append("Scope: " + value["scope"])
        if value.get("fetched_at"):
            lines.append(f"Source retrieved: {value['fetched_at']}")
        if value.get("confirmed_at"):
            lines.append(f"Holdings last confirmed: {value['confirmed_at']}; user updates on change.")
        lines.extend(f"- {reason}" for reason in value.get("reasons", []))
        for name, metric in value.get("metrics", {}).items():
            if metric is not None:
                rendered = f"{metric:,.2f}" if isinstance(metric, (int, float)) and not isinstance(metric, bool) else str(metric)
                lines.append(f"  {name.replace('_', ' ')}: {rendered}")
        lines.extend(f"Not verified: {item}" for item in value.get("unverified", []))
        if value.get("free_cash_flow_basis"):
            lines.append("Cash-flow basis: " + value["free_cash_flow_basis"])
        current = value.get("current_period")
        if current:
            lines.append(f"Latest filing period: {current['status']} | {current.get('period_start', '?')} to {current.get('as_of', '?')} | filed {current.get('filed_at', '?')}")
            lines.append(current.get("scope", ""))
            lines.extend(f"- {reason}" for reason in current.get("reasons", []))
            lines.extend(f"  YTD {name.replace('_', ' ')}: {metric:,.2f}" for name, metric in current.get("metrics", {}).items())
            if current.get("free_cash_flow_basis"):
                lines.append("Cash-flow basis: " + current["free_cash_flow_basis"])
            if current.get("missing_metrics"):
                lines.append("Missing current-period metrics: " + ", ".join(current["missing_metrics"]))
        for source in value.get("sources", []):
            lines.append("Source: " + (source.get("url", "") if isinstance(source, dict) else str(source)))
    return lines


def main(argv=None):
    """Read-only evidence command; writing a requested report never sends notifications."""
    import argparse
    from monitor import DEFAULT_CONFIG, fetch_quote, load_config, runtime_home, atomic_json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--symbols", help="Comma-separated configured symbols; portfolio still values every holding")
    parser.add_argument("--output", type=Path, help="Save the read-only evidence JSON to this file")
    args = parser.parse_args(argv)
    config = load_config(args.config)
    if not config.get("investment_analysis", {}).get("enabled"):
        parser.error("investment_analysis is not enabled")
    wanted = set(args.symbols.upper().split(",")) if args.symbols else None
    available = {r["symbol"] for r in config["watchlist"]}
    if wanted and wanted - available:
        parser.error("Unknown configured symbols: " + ", ".join(sorted(wanted - available)))
    rules = [r for r in config["watchlist"] if not wanted or r["symbol"] in wanted]
    now = datetime.now(timezone.utc)
    def quote(rule):
        try:
            return rule["symbol"], fetch_quote(rule["symbol"]).as_dict()
        except Exception:
            return rule["symbol"], {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        quotes = dict(pool.map(quote, rules))
    rows, portfolio = InvestmentService(config, runtime_home(), read_only=True).batch(
        rules, quotes, now, clock=lambda: datetime.now(timezone.utc))
    result = {"checked_at": datetime.now(timezone.utc).isoformat(), "read_only": True,
              "scope": "Public evidence and portfolio reference valuation; no order or email sent",
              "portfolio_summary": portfolio, "rows": [{"symbol": symbol, "investment": value} for symbol, value in rows.items()]}
    if args.output:
        atomic_json(args.output, result)
        print(f"Evidence saved: {args.output.resolve()}; no email sent or runtime state changed")
    else:
        print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
