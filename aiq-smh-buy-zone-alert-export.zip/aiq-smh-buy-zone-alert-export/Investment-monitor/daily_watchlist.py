#!/usr/bin/env python3
"""Send one watchlist digest before each NY trading day. No AI or trading calls."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from email.utils import format_datetime
import fcntl
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import smtplib
import sys
import time

from market_clock import _calendar, NEW_YORK, MARKETS, extended_market_session
from monitor import (DEFAULT_CONFIG, atomic_json, runtime_home, load_config,
                     fetch_payload, parse_extended_quote, parse_quote, validate_quote,
                     rule_status, connect_smtp, smtp_password)
from technical_data import DailyHistoryService, expected_completed_session
from buy_sell_signals import BuySellSignalService, signal_settings
from watchlist_email import render_report
from news_context_view import load_news_analysis

ROOT = Path(__file__).resolve().parent
DEFAULT_RESEARCH = ROOT.parent / "master-watchlist-2026-09-07/master-watchlist-data.json"
UTC = timezone.utc
LOG = logging.getLogger("daily-watchlist")


def schedule(now):
    """Target 09:00 NY on XNYS session days; retries only until 09:25.

    A one-minute LaunchAgent cadence permits up to one minute scheduling delay.
    Reports missed while asleep can catch up before the cutoff, never after it.
    """
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("Timezone-aware current time required")
    local = now.astimezone(NEW_YORK)
    day = local.date().isoformat()
    cal = _calendar(local.year, "US")
    if not cal.is_session(day):
        return {"session_date": day, "phase": "closed", "due": False}
    opening = cal.session_open(day).to_pydatetime().astimezone(UTC)
    target = local.replace(hour=9, minute=0, second=0, microsecond=0).astimezone(UTC)
    cutoff = min(target + timedelta(minutes=25), opening - timedelta(minutes=5))
    phase = "before" if now < target else "due" if now < cutoff else "expired"
    return {"session_date": day, "phase": phase, "due": phase == "due",
            "scheduled_at": target.isoformat(), "market_open": opening.isoformat(),
            "cutoff": cutoff.isoformat()}


def next_scheduled(now):
    for offset in range(370):
        local = (now.astimezone(NEW_YORK) + timedelta(days=offset)).replace(hour=9, minute=0, second=0, microsecond=0)
        plan = schedule(local)
        if plan["due"] and local > now:
            return plan["scheduled_at"]
    raise ValueError("No next trading session found")


def load_research(path):
    """Never relabel dated research prices/fundamentals as current observations."""
    try:
        data = json.loads(Path(path).read_text())
        rows = data["rows"]
        if not isinstance(rows, list):
            raise ValueError("Research rows must be a list")
        lookup = {r["ticker"]: r for r in rows}
        if len(lookup) != len(rows):
            raise ValueError("Duplicate research ticker")
        return data.get("asOf"), lookup, None
    except (OSError, ValueError, KeyError, TypeError):
        return None, {}, "Saved entry/TP/stop research unavailable; no levels invented."


def changes(row, previous):
    if previous is None:
        return "First report; no comparison"
    parts = []
    a, b = previous.get("technical", {}).get("status"), row["technical"].get("status")
    if a != b:
        parts.append(f"Technical {a or 'unavailable'} -> {b}")
    if previous.get("zone_status") != row["zone_status"]:
        parts.append(f"Zone {previous.get('zone_status', 'unavailable')} -> {row['zone_status']}")
    for key in ("zone_low", "zone_high", "entry", "tp", "stop"):
        if str(previous.get(key)) != str(row.get(key)):
            parts.append(f"Saved {key.replace('_',' ')} changed")
    for key in ("nav", "fundamentals", "portfolio"):
        before, after = previous.get("investment", {}).get(key), row.get("investment", {}).get(key)
        if before and after:
            if before.get("status") != after.get("status"):
                parts.append(f"{key.title()} {before.get('status')} -> {after.get('status')}")
            if key == "fundamentals" and before.get("latest_financial_filing", {}).get("accessionNumber") != after.get("latest_financial_filing", {}).get("accessionNumber"):
                parts.append("Financial filing evidence changed")
    before_signals = previous.get("buy_sell_signals", {}).get("timeframes", {})
    after_signals = row.get("buy_sell_signals", {}).get("timeframes", {})
    for timeframe in ("15m", "1h", "1d"):
        before = before_signals.get(timeframe, {}).get("status")
        after = after_signals.get(timeframe, {}).get("status")
        if after is not None and before != after:
            parts.append(f"{timeframe} signal {before or 'unavailable'} -> {after}")
    return "; ".join(parts) or "No technical grade or saved-zone/plan change"


def collect_report(config, research_path, home, now, previous=None, *,
                   fetcher=fetch_payload, evaluator=None, clock=lambda: datetime.now(UTC),
                   investment_evaluator=None, signal_evaluator=None):
    research_date, research, warning = load_research(research_path)
    evaluator = evaluator or DailyHistoryService(home / "daily-history", config, read_only=True)
    signal_options = signal_settings(config)
    if signal_evaluator is None and signal_options["enabled"] and signal_options["daily_digest"]:
        signal_evaluator = BuySellSignalService(
            home / "buy-sell-signals", config, read_only=True,
            daily_service=evaluator if hasattr(evaluator, "get_history") else None)
    plan = schedule(now)
    baseline = {r["symbol"]: r for r in (previous or {}).get("rows", [])}

    def collect(rule):
        symbol, market = rule["symbol"], rule.get("market", "US")
        saved = research.get(symbol, {})
        row = {"symbol": symbol, "currency": MARKETS[market]["currency"],
               "holding": saved.get("holding", False), "price": None, "quote_time": None,
               "quote_label": "Unavailable", "quote_error": None, "zone_low": rule["low"],
               "zone_high": rule["high"], "zone_status": "unavailable", "trigger": rule.get("trigger", "range"),
               "entry": saved.get("entry", "Not supplied"), "tp": saved.get("tp", "Not supplied"),
               "stop": saved.get("stop", "Not supplied"), "assessment": saved.get("assessment", "Saved plan unavailable"),
               "comments": saved.get("comments", ""), "gate": saved.get("gate", rule.get("review_notes", "")),
               "research_date": research_date, "enabled": rule.get("enabled", True)}
        quote = None
        try:
            if market == "US":
                initial_session = extended_market_session(now)
                if not initial_session or initial_session["phase"] != "pre":
                    raise ValueError("No current US pre-market quote window")
            payload = fetcher(symbol, extended=market == "US")
            checked = clock()
            if market == "US":
                session = extended_market_session(checked)
                if not session or session["phase"] != "pre":
                    raise ValueError("No current US pre-market quote window")
                quote = parse_extended_quote(symbol, payload, session, checked)
                validate_quote(quote, checked, session, config.get("max_quote_age_seconds", 1200))
                row["quote_label"] = "Pre-market indicative chart price; may be delayed"
            else:
                quote = parse_quote(symbol, payload)
                expected = expected_completed_session(checked, "HK", config.get("technical_analysis", {}).get("publish_grace_minutes", 20))
                cal = _calendar(int(expected[:4]), "HK")
                close = cal.session_close(expected).to_pydatetime().astimezone(UTC)
                if not close - timedelta(minutes=1) <= quote.timestamp <= close + timedelta(minutes=30):
                    raise ValueError("HK quote is not from the most recent completed session's closing window")
                if quote.timestamp > checked + timedelta(seconds=60):
                    raise ValueError("Future HK quote")
                row["quote_label"] = f"HK completed-session closing quote ({expected}); not live US pre-market"
            row.update(price=str(quote.price), quote_time=quote.timestamp.isoformat(),
                       zone_status=rule_status(quote.price, rule))
        except Exception as exc:
            quote = None
            row["quote_error"] = str(exc)[:240]
        checked = clock()
        try:
            live = quote.as_dict() if quote is not None and market == "US" else {}
            technical = evaluator(rule, live, checked)
            if technical.get("status") not in ("PASS", "WAIT", "FAIL", "UNAVAILABLE", "NOT_APPLICABLE"):
                raise ValueError("Invalid technical result")
            technical["live_quote_valid"] = bool(live)
            row["technical"] = technical
        except Exception as exc:
            row["technical"] = {"status": "UNAVAILABLE", "as_of": None, "checked_at": checked.isoformat(),
                                "reasons": [f"Technical data unavailable ({type(exc).__name__})."],
                                "metrics": {}, "live_quote_valid": False}
        if signal_evaluator is not None:
            try:
                signals = signal_evaluator(rule, checked)
                if not isinstance(signals, dict) or not isinstance(signals.get("timeframes"), dict):
                    raise ValueError("Invalid buy/sell signal result")
                row["buy_sell_signals"] = signals
            except Exception as exc:
                row["buy_sell_signals"] = {
                    "symbol": symbol, "status": "UNAVAILABLE", "checked_at": checked.isoformat(),
                    "timeframes": {}, "scope": f"Signal evidence unavailable ({type(exc).__name__}).",
                }
        row["change"] = changes(row, baseline.get(symbol))
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(collect, config["watchlist"]))
    portfolio_summary = None
    if config.get("investment_analysis", {}).get("enabled"):
        from investment_checks import InvestmentService, unavailable
        try:
            service = investment_evaluator or InvestmentService(config, home, read_only=True)
            quotes = {r["symbol"]: {"symbol": r["symbol"], "price": r["price"],
                       "timestamp": r["quote_time"], "currency": r["currency"],
                       "phase": "pre" if r["currency"] == "USD" else "regular"}
                      for r in rows if r["price"] is not None}
            investments, portfolio_summary = service.batch(config["watchlist"], quotes, clock(), clock=clock)
            for row in rows:
                row["investment"] = investments[row["symbol"]]
        except Exception as exc:
            failure = unavailable(f"Investment evidence unavailable ({type(exc).__name__}).", clock())
            portfolio_summary = failure
            for row in rows:
                row["investment"] = {"overall": "REVIEW", **{k: failure for k in ("nav", "fundamentals", "portfolio", "arora")}}
    finished = clock()
    # Do not describe an observation that aged during a slow collection as current.
    for row in rows:
        if row["currency"] == "USD" and row["quote_time"] and (
                finished - datetime.fromisoformat(row["quote_time"])).total_seconds() > config.get("max_quote_age_seconds", 1200):
            row.update(price=None, zone_status="unavailable", quote_label="Unavailable",
                       quote_error="Pre-market quote aged beyond the limit during collection")
            row["technical"]["live_quote_valid"] = False
            row["technical"]["status"] = "UNAVAILABLE"
            row["technical"].setdefault("reasons", []).insert(0, "Quote expired during report collection; current combined assessment unavailable.")
            if row.get("investment", {}).get("nav", {}).get("status") != "NOT_APPLICABLE" and row.get("investment"):
                row["investment"]["nav"] = unavailable("Quote expired during collection; current NAV comparison unavailable.", finished)
            row["change"] = changes(row, baseline.get(row["symbol"]))
    for row in rows:
        row["change"] = changes(row, baseline.get(row["symbol"]))
    return {"session_date": plan["session_date"], "generated_at": finished.isoformat(), "started_at": now.isoformat(),
            "scheduled_at": plan.get("scheduled_at"), "market_open": plan.get("market_open"),
            "research_as_of": research_date, "research_warning": warning,
            "previous_session_date": (previous or {}).get("session_date"), "rows": rows,
            "news_context":load_news_analysis(ROOT/'news-evidence/news-analysis.json',finished),
            **({"portfolio_summary": portfolio_summary} if config.get("investment_analysis", {}).get("enabled") else {})}


class DeliveryUncertain(Exception):
    """SMTP may have accepted the DATA; do not automatically duplicate this report."""


class DeliveryWindowExpired(Exception):
    """No email submitted: pre-open cutoff passed before SMTP submission."""


def send_digest(recipient, report, config, home, *, clock=lambda: datetime.now(UTC)):
    title, text_body, html_body = render_report(report, include_details=False)
    full_html = render_report(report)[2]
    email = config["alerts"]["email"]
    message = EmailMessage()
    message["From"], message["To"], message["Subject"] = email["from"], recipient, title
    message["Date"] = format_datetime(datetime.now(UTC))
    identity = hashlib.sha256((report["session_date"] + ":" + recipient).encode()).hexdigest()
    message["Message-ID"] = f"<daily-watchlist.{identity}@{email['from'].split('@')[-1]}>"
    message.set_content(text_body)
    message.add_alternative(html_body, subtype="html")
    message.add_attachment(full_html.encode("utf-8"), maintype="text", subtype="html",
                           filename=f"investment-watchlist-{report['session_date']}.html")
    connection = connect_smtp(email, smtp_password(home, email))
    try:
        # Connection/TLS/login can stall. Recheck at the actual submission point.
        current = schedule(clock())
        if not current["due"] or current["session_date"] != report["session_date"]:
            raise DeliveryWindowExpired("Pre-open submission window expired")
        try:
            refused = connection.send_message(message, from_addr=email["from"], to_addrs=[recipient])
        except (smtplib.SMTPResponseException, smtplib.SMTPRecipientsRefused):
            raise  # Explicit rejection; retrying does not duplicate acceptance.
        except Exception as exc:
            raise DeliveryUncertain(type(exc).__name__) from exc
        if refused:
            raise smtplib.SMTPRecipientsRefused(refused)
    finally:
        try:
            connection.quit()
        except Exception:
            try:
                connection.close()
            except Exception:
                pass  # SMTP acceptance cannot be undone by cleanup failure.


def write_report(report, directory):
    directory.mkdir(parents=True, exist_ok=True)
    title, text_body, html_body = render_report(report)
    prefix = directory / report["session_date"]
    atomic_json(prefix.with_suffix(".json"), report)
    prefix.with_suffix(".txt").write_text(title + "\n\n" + text_body)
    prefix.with_suffix(".html").write_text(html_body)
    return str(prefix.with_suffix(".json"))


def load_digest_state(path):
    if not path.exists():
        return {"version": 1, "days": {}}
    data = json.loads(path.read_text())
    if data.get("version") != 1 or not isinstance(data.get("days"), dict):
        raise ValueError("Daily watchlist state is invalid; refusing to risk duplicate delivery")
    return data


def run_due(config, research_path, home, *, clock=lambda: datetime.now(UTC),
            collector=collect_report, sender=send_digest):
    """Caller holds the daily digest lock; price-alert state is never touched."""
    now = clock()
    plan = schedule(now)
    if not plan["due"]:
        return 0
    if not config["alerts"]["email"]["enabled"]:
        LOG.error("Daily watchlist not sent: existing email channel disabled")
        return 1
    folder = home / "daily-watchlist"
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = folder / "state.json"
    state = load_digest_state(path)
    day = state["days"].get(plan["session_date"])
    if not day:
        previous_path = state.get("last_complete_report")
        previous = json.loads(Path(previous_path).read_text()) if previous_path else None
        report = collector(config, research_path, home, now, previous, clock=clock)
        if not schedule(clock())["due"] or schedule(clock())["session_date"] != plan["session_date"]:
            LOG.warning("Daily watchlist collection finished after the pre-open delivery cutoff; not sent")
            return 1
        saved = write_report(report, folder / "reports")
        day = {"report_path": saved, "created_at": clock().isoformat(),
               "recipients": {r: {"status": "pending", "attempts": 0} for r in config["alerts"]["email"]["to"]}}
        state["days"][plan["session_date"]] = day
        atomic_json(path, state)
    else:
        report = json.loads(Path(day["report_path"]).read_text())
    errors = 0
    for recipient, delivery in day["recipients"].items():
        # Removing a recipient from config revokes all future attempts immediately.
        if recipient not in config["alerts"]["email"]["to"]:
            continue
        if delivery["status"] == "sent":
            continue
        if delivery["status"] in ("sending", "uncertain"):
            delivery["status"] = "uncertain"
            atomic_json(path, state)
            LOG.error("Daily watchlist %s has an uncertain SMTP delivery; automatic resend suppressed", plan["session_date"])
            errors += 1
            continue
        latest = schedule(clock())
        if not latest["due"] or latest["session_date"] != plan["session_date"]:
            LOG.warning("Daily watchlist retry window expired; remaining recipients not sent")
            return 1
        delivery.update(status="sending", last_attempt=clock().isoformat(), attempts=delivery["attempts"]+1)
        atomic_json(path, state)  # Journal intent before SMTP to handle process death.
        try:
            sender(recipient, report, config, home)
        except DeliveryUncertain as exc:
            delivery.update(status="uncertain", error=type(exc).__name__)
            errors += 1
            LOG.error("Daily watchlist delivery uncertain; duplicate retry suppressed")
        except Exception as exc:
            delivery.update(status="pending", error=type(exc).__name__)
            errors += 1
            LOG.error("Daily watchlist delivery failed (%s); will retry before cutoff", type(exc).__name__)
        else:
            delivery.update(status="sent", accepted_at=clock().isoformat())
            delivery.pop("error", None)
            LOG.info("Daily watchlist %s accepted by SMTP for recipient %s/%s", plan["session_date"],
                     list(day["recipients"]).index(recipient)+1, len(day["recipients"]))
        atomic_json(path, state)
    active = [v for r,v in day["recipients"].items() if r in config["alerts"]["email"]["to"]]
    if active and all(x["status"] == "sent" for x in active):
        state["last_complete_report"] = day["report_path"]
        state["last_complete_session"] = plan["session_date"]
        atomic_json(path, state)
    return 1 if errors else 0


def setup_logging(folder):
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    handler = RotatingFileHandler(folder / "daily-watchlist.log", maxBytes=1_000_000, backupCount=3)
    formatter = logging.Formatter("%(asctime)sZ %(levelname)s %(message)s")
    formatter.converter = time.gmtime
    handler.setFormatter(formatter)
    LOG.setLevel(logging.INFO)
    LOG.addHandler(handler)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--research", type=Path, default=DEFAULT_RESEARCH)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--preview", type=Path, help="Fetch and save a preview here, no SMTP or runtime writes")
    group.add_argument("--status", action="store_true", help="Read-only schedule/delivery status")
    args = parser.parse_args(argv)
    config, home = load_config(args.config), runtime_home()
    folder = home / "daily-watchlist"
    if args.status:
        state = load_digest_state(folder / "state.json")
        # Do not print addresses, account settings or credentials.
        print(json.dumps({"schedule": schedule(datetime.now(UTC)), "next_scheduled": next_scheduled(datetime.now(UTC)),
                          "last_complete_session": state.get("last_complete_session"),
                          "days": {d: {"report_path": x["report_path"], "delivery_statuses": [v["status"] for v in x["recipients"].values()]}
                                   for d,x in state["days"].items()}, "runtime_directory": str(folder)}, indent=2))
        return 0
    if args.preview:
        state = load_digest_state(folder / "state.json")
        prev = json.loads(Path(state["last_complete_report"]).read_text()) if state.get("last_complete_report") else None
        report = collect_report(config, args.research, home, datetime.now(UTC), prev)
        saved = write_report(report, args.preview)
        print(f"Preview saved: {saved}; no email sent or runtime state changed")
        return 0
    if not schedule(datetime.now(UTC))["due"]:
        return 0
    setup_logging(folder)
    with (folder / "digest.lock").open("a") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return 0
        try:
            return run_due(config, args.research, home)
        except Exception as exc:
            LOG.error("Daily watchlist failed (%s); no state reset", type(exc).__name__)
            return 1


if __name__ == "__main__":
    sys.exit(main())
