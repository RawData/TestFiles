"""Pure, escaped rendering of the scheduled watchlist digest.

The caller owns data freshness, comparisons, scheduling and delivery. This
module neither reads local account data nor fetches prices or sends messages.
"""

from collections import Counter
from collections.abc import Mapping
from datetime import datetime, timezone
from html import escape
import math
import re
from zoneinfo import ZoneInfo
from news_context_view import render_news_analysis, news_analysis_text


STATUSES = ("PASS", "WAIT", "FAIL", "UNAVAILABLE", "NOT_APPLICABLE")
STATUS_LABELS = {
    "PASS": "PASS — checks met; watchlist only",
    "WAIT": "WAIT — conditions incomplete",
    "FAIL": "FAIL — technical checks failed",
    "UNAVAILABLE": "UNAVAILABLE — cannot assess",
    "NOT_APPLICABLE": "N/A — manual NAV/risk review",
}
COLORS = {"PASS": "#165e49", "WAIT": "#875b07", "FAIL": "#a02424",
          "UNAVAILABLE": "#555c68", "NOT_APPLICABLE": "#555c68"}
DISCLAIMER = (
    "Prices: Yahoo Finance (unofficial; may be delayed). Each row shows its quote "
    "timestamp and session. Unavailable prices are not replaced with an old research close. "
    "Daily technical evidence uses completed sessions; a daily-only result cannot confirm "
    "the current intraday setup. Saved entry, take-profit (TP), stop/review levels, "
    "assessments and manual gates are dated research, not freshly revalidated fundamentals "
    "or orders. Check current earnings, news, NAV, distributions and portfolio fit before "
    "acting. PASS means the configured chart checks are met; the backtest did not establish "
    "a consistent buying advantage. FAIL identifies a failed setup, not a forecast that "
    "the security must fall. The monitor continues rechecking."
)
INVESTMENT_DISCLAIMER = (
    "Prices: Yahoo Finance (unofficial; may be delayed). Quote timestamps and completed "
    "daily technical sessions are shown separately. Unavailable prices are not replaced "
    "with an old research close. Saved entry, TP, stop/review levels and assessments remain "
    "dated research. The additional investment checks cover dated issuer NAV where available, "
    "partial SEC annual and available fiscal year-to-date evidence and portfolio exposure. Guidance, valuation, news "
    "and distribution sustainability are not fully verified; Arora recommendations have not "
    "been refreshed. Portfolio risk limits are unset: exposure figures are not a suitability "
    "endorsement. Investment review remains REVIEW. Technical PASS means chart checks are "
    "met; the backtest did not establish a consistent buying advantage. A daily-only result "
    "cannot confirm the current intraday setup. FAIL identifies a failed check, not a forecast "
    "that the security must fall. No orders are placed."
)
SIGNAL_DISCLAIMER = (
    " Separate BUY/SELL candle signals use completed regular-session bars. They only report "
    "the configured mechanical breakout and next-candle confirmation pattern; they are not orders, "
    "return forecasts, or investment recommendations."
)


def _text(value, fallback="Not supplied"):
    if value is None or value == "":
        return fallback
    if isinstance(value, (list, tuple)):
        return "; ".join(_text(item, "") for item in value) or fallback
    return str(value)


def _html(value):
    return escape(_text(value), quote=True).replace("\n", "<br>")


def _stamp(value):
    """Make an aware ISO timestamp readable without guessing a missing timezone."""
    if not value:
        return "Unavailable"
    raw = str(value)
    try:
        instant = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if instant.tzinfo is None:
            return raw + " (timezone not supplied)"
        ny = instant.astimezone(ZoneInfo("America/New_York"))
        utc = instant.astimezone(ZoneInfo("UTC"))
        return ny.strftime("%Y-%m-%d %H:%M:%S %Z") + utc.strftime(" (%H:%M:%S UTC)")
    except (ValueError, TypeError, OverflowError):
        return raw


def _status(row):
    tech = row.get("technical")
    if not isinstance(tech, Mapping):
        return "UNAVAILABLE"
    status = tech.get("status", "UNAVAILABLE")
    return status if status in STATUSES else "UNAVAILABLE"


def _technical_label(row):
    if _status(row) == "NOT_APPLICABLE" and isinstance(row.get("investment"), Mapping):
        return "N/A — equity chart filter does not apply"
    return STATUS_LABELS[_status(row)]


def _mapping(value):
    return value if isinstance(value, Mapping) else {}


def _dated(value):
    if value and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(value)):
        return str(value)
    return _stamp(value)


def _evidence_value(value):
    """Readable structured evidence, still plain text until final HTML escaping."""
    if isinstance(value, Mapping):
        return "; ".join(f"{str(key).replace('_', ' ')}: {_evidence_value(item)}"
                         for key, item in value.items()) or "Unavailable"
    if isinstance(value, (list, tuple)):
        return " | ".join(_evidence_value(item) for item in value) or "None supplied"
    if value is None:
        return "Unavailable"
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, int):
        return f"{value:,}"
    if isinstance(value, float):
        return f"{value:,.6f}".rstrip("0").rstrip(".") if math.isfinite(value) else "Unavailable"
    return _metric_value(value)


def _investment_short(row):
    investment = _mapping(row.get("investment"))
    if not investment:
        return "Investment checks: unavailable"
    parts = ["Investment: REVIEW"]
    for key, label in (("nav", "NAV"), ("fundamentals", "Financials"),
                       ("portfolio", "Exposure"), ("arora", "Arora")):
        parts.append(f"{label}: {_text(_mapping(investment.get(key)).get('status'), 'UNAVAILABLE')}")
    weight = _mapping(_mapping(investment.get("portfolio")).get("metrics")).get("position_weight_pct")
    parts.append("Weight: " + (_metric_value(weight) + "%" if weight is not None else "unavailable"))
    return " | ".join(parts)


def _investment_details(row):
    investment = _mapping(row.get("investment"))
    if not investment:
        return [("Investment checks", "Unavailable; no investment evidence supplied for this ticker")]
    details = [("Investment conclusion", "REVIEW — individual checks do not establish a buying recommendation")]
    metric_labels = {
        "nav": "Dated NAV", "currency": "Currency", "price": "Compared price",
        "official_close": "Official dated close", "official_close_date": "Official close date",
        "official_premium_discount_pct": "Official same-date close vs NAV (%)",
        "price_vs_dated_nav_pct": "Indicative price vs dated NAV (%)",
        "premium_discount_pct": "Verified same-close premium/discount (%)",
        "max_premium_pct": "Configured maximum premium (%)",
        "dated_close_meets_premium_limit": "Dated close meets configured premium limit",
        "nav_lag_sessions": "NAV age in trading sessions", "expected_nav_session": "Expected NAV session",
        "max_nav_lag_sessions": "Maximum NAV age in trading sessions",
        "quote_timestamp": "Compared quote timestamp", "quote_age_seconds": "Quote age (seconds)",
        "publish_grace_minutes": "NAV publication grace (minutes)",
        "revenue": "Annual revenue (USD)", "previous_revenue": "Prior comparable annual revenue (USD)",
        "net_income": "Annual net income (USD)", "operating_cash_flow": "Annual operating cash flow (USD)",
        "capital_expenditure": "Annual PP&E payments (USD)", "ppe_free_cash_flow_proxy": "Annual CFO less PP&E payments proxy (USD)",
        "cash": "Reported cash (USD)", "equity": "Reported book equity (USD)",
        "assets": "Reported assets (USD)", "liabilities": "Reported liabilities (USD)",
        "revenue_growth_pct": "Comparable annual revenue growth (%)", "net_margin_pct": "Annual net margin (%)",
        "position_quantity": "Position quantity", "position_value_usd": "Position value (USD)",
        "position_weight_pct": "Position weight (%)", "cash_usd": "USD cash balance",
        "cash_by_currency": "Cash balances by original currency", "converted_cash_usd": "Combined cash converted to USD",
        "total_value_usd": "Portfolio value (USD)", "proposed_addition": "Proposed addition",
    }
    for key, label in (("nav", "NAV check"), ("fundamentals", "Financial checks"),
                       ("portfolio", "Portfolio exposure"), ("arora", "Arora check")):
        check = _mapping(investment.get(key))
        details.append((label, _text(check.get("status"), "UNAVAILABLE")))
        details.append((label + " dates", "Evidence as of: " + _dated(check.get("as_of"))
                        + "; fetched: " + _dated(check.get("fetched_at"))
                        + ("; checked: " + _dated(check.get("checked_at")) if check.get("checked_at") else "")
                        + ("; filed: " + _dated(check.get("filed_at")) if check.get("filed_at") else "")))
        details.append((label + " evidence", _text(check.get("reasons"), "Evidence unavailable")))
        metrics = _mapping(check.get("metrics"))
        if metrics:
            details.append((label + " values", " | ".join(
                f"{metric_labels.get(name, str(name).replace('_', ' ').capitalize())}: "
                + ("None specified; exposure only" if name == "proposed_addition" and value is None else _evidence_value(value))
                for name, value in metrics.items())))
        if key == "fundamentals":
            details.append(("Financial check coverage", "Partial SEC annual and supported latest 10-Q fiscal YTD checks. Current guidance, "
                            "customer retention, unparsed disclosures and valuation are not verified."))
            if check.get("free_cash_flow_basis"):
                details.append(("Annual cash-flow proxy basis", _text(check["free_cash_flow_basis"])))
            if check.get("facts"):
                details.append(("Annual filing facts and units", _evidence_value(check["facts"])))
            if check.get("missing_metrics"):
                details.append(("Missing annual facts", _text(check["missing_metrics"])))
            current = _mapping(check.get("current_period"))
            if current:
                details.extend([
                    ("Latest filing period", _text(current.get("status")) + "; " + _text(current.get("scope"))),
                    ("Latest filing period dates", _dated(current.get("period_start")) + " to " + _dated(current.get("as_of")) + "; filed " + _dated(current.get("filed_at"))),
                    ("Latest fiscal YTD values (USD; ratios in %)", _evidence_value(current.get("metrics"))),
                    ("Latest fiscal YTD evidence", _text(current.get("reasons"))),
                    ("Latest fiscal YTD source facts and units", _evidence_value(current.get("facts"))),
                    ("Missing current-period facts", _text(current.get("missing_metrics"), "None reported")),
                ])
                if current.get("free_cash_flow_basis"):
                    details.append(("Latest cash-flow proxy basis", _text(current["free_cash_flow_basis"])))
        if key == "portfolio":
            details.append(("Portfolio interpretation", "Risk limits are unset; exposure only. No suitability "
                            "endorsement or proposed purchase is inferred."))
        if key == "arora":
            details.append(("Arora freshness", "Arora recommendations have not been refreshed by these automated checks."))
        if check.get("unverified"):
            details.append((label + " unverified items", _evidence_value(check["unverified"])))
        details.append((label + " sources", _evidence_value(check.get("sources") or check.get("source"))))
    return details


def _portfolio_overview(report):
    overview = _mapping(report.get("portfolio_summary"))
    if not overview:
        return [("Portfolio exposure", "Unavailable; portfolio totals and weights are not assumed")]
    metrics = _mapping(overview.get("metrics"))
    details = [("Portfolio exposure", _text(overview.get("status"), "UNAVAILABLE")),
               ("Valuation coverage", "Complete" if overview.get("complete") is True else "Partial / incomplete"),
               ("Portfolio evidence as of", _dated(overview.get("as_of")) if overview.get("as_of") else "Mixed reference timestamps; each holding and FX rate is dated separately"),
               ("Portfolio checked", _dated(overview.get("checked_at"))),
               ("Holdings last confirmed", _dated(overview.get("confirmed_at"))),
               ("Portfolio interpretation", "Risk limits are unset; exposure only, without a suitability endorsement.")]
    for name, label in (("total_value_usd", "Portfolio value (USD)"), ("position_count", "Position count"),
                        ("cash_by_currency", "Cash balances by original currency"),
                        ("converted_cash_usd", "Combined cash converted to USD")):
        details.append((label, _evidence_value(metrics.get(name))))
    largest = metrics.get("largest_positions")
    if isinstance(largest, list):
        details.append(("Largest positions", " | ".join(
            _text(p.get("symbol")) + ": USD " + _evidence_value(p.get("value_usd")) +
            "; weight " + _evidence_value(p.get("weight_pct", p.get("position_weight_pct"))) + "%"
            for p in largest if isinstance(p, Mapping))))
    if metrics.get("fx"):
        details.append(("Reference FX", _evidence_value(metrics["fx"])))
    if overview.get("reasons"):
        details.append(("Portfolio evidence limitations", _text(overview["reasons"])))
    return details


def _price(row):
    value = row.get("price")
    if value is None or value == "":
        return "Unavailable"
    return f"{_text(row.get('currency'), 'Currency unspecified')} {_text(value)}"


def _zone(row):
    low, high = row.get("zone_low"), row.get("zone_high")
    if low is None or high is None:
        return "No saved numeric zone"
    status = row.get("zone_status", "unavailable")
    # Without a quote a caller's stale zone relationship must not look current.
    if row.get("price") in (None, ""):
        status = "unavailable"
    level = f"≤{high}" if row.get("trigger") == "at_or_below" else f"{low}–{high}"
    return (f"{_text(row.get('currency'), 'Currency unspecified')} {level}; "
            f"price {_text(status)}")


def _change(row):
    return _text(row.get("change"), "First report; no comparison")


def _is_change(row):
    text = _change(row).strip().lower()
    return not (text.startswith("first report") or text.startswith("no change")
                or text.startswith("unchanged") or text.startswith("no previous")
                or text == "no technical grade or saved-zone/plan change")


def _metric_value(value):
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, (int, float)):
        return f"{value:.4g}" if math.isfinite(value) else "unavailable"
    return _text(value, "unavailable")


def _metrics(technical):
    metrics = technical.get("metrics") or {}
    if not isinstance(metrics, Mapping):
        return "Indicator values unavailable"
    labels = (
        ("close", "Daily close"), ("sma20", "SMA20"), ("sma50", "SMA50"),
        ("sma200", "SMA200"), ("sma50_slope", "SMA50 slope"),
        ("rsi14", "RSI14"), ("macd_histogram", "MACD histogram"),
        ("atr14", "ATR14"), ("support20", "Prior 20-session support"),
        ("breakout_level", "Breakout level"), ("higher_low", "Higher low"),
        ("lower_low", "Lower low"), ("breakout_confirmed", "Breakout confirmed"),
        ("relative_volume20", "Relative volume"),
        ("extension_from_sma20_atr", "Extension above SMA20 in ATR"),
    )
    values = [f"{label}: {_metric_value(metrics[key])}" for key, label in labels
              if key in metrics and metrics[key] is not None]
    return " | ".join(values) or "Indicator values unavailable"


def _signal_summary(row):
    snapshot = _mapping(row.get("buy_sell_signals"))
    timeframes = _mapping(snapshot.get("timeframes"))
    if not timeframes:
        return ("Overall: " + _text(snapshot.get("status"), "UNAVAILABLE")) if snapshot else None
    values = []
    for timeframe in ("15m", "1h", "1d"):
        assessment = _mapping(timeframes.get(timeframe))
        if not assessment:
            continue
        status = _text(assessment.get("status"), "UNAVAILABLE")
        event = _mapping(assessment.get("last_event"))
        if status == "NONE" and event:
            status += f" (last {_text(event.get('direction'), 'signal')} {_stamp(event.get('confirmed_at'))})"
        values.append(f"{timeframe}: {status}")
    return " | ".join(values)


def _signal_details(row):
    snapshot = _mapping(row.get("buy_sell_signals"))
    timeframes = _mapping(snapshot.get("timeframes"))
    details = []
    for timeframe in ("15m", "1h", "1d"):
        assessment = _mapping(timeframes.get(timeframe))
        if not assessment:
            continue
        value = (f"{_text(assessment.get('status'), 'UNAVAILABLE')}; completed through "
                 f"{_stamp(assessment.get('as_of'))}")
        pending = _mapping(assessment.get("pending"))
        last_event = _mapping(assessment.get("last_event"))
        if pending:
            value += (f"; awaiting next candle after { _stamp(pending.get('setup_at')) }; "
                      f"break midpoint {_metric_value(pending.get('break_mid'))}")
        elif last_event:
            value += (f"; last { _text(last_event.get('direction'), 'signal') } confirmed "
                      f"{_stamp(last_event.get('confirmed_at'))}")
        if assessment.get("reasons"):
            value += "; " + _text(assessment["reasons"])
        details.append((timeframe + " candle signal", value))
    if details:
        details.insert(0, ("Candle signal scope", _text(snapshot.get("scope"),
                        "Completed-candle research signal; not an order")))
    elif snapshot:
        details.extend([
            ("Candle signal status", _text(snapshot.get("status"), "UNAVAILABLE")),
            ("Candle signal scope", _text(snapshot.get("scope"), "Signal evidence unavailable")),
        ])
    return details


def _details(row, research_as_of):
    tech = row.get("technical")
    if not isinstance(tech, Mapping):
        tech = {}
    current = tech.get("live_quote_valid")
    quote_check = ("Valid quote used for intraday checks" if current is True
                   else "Daily-only; no valid quote used for intraday checks")
    reasons = _text(tech.get("reasons"), "No technical reasons available")
    details = [
        ("Quote", f"{_price(row)}; {_stamp(row.get('quote_time'))}; "
                  f"{_text(row.get('quote_label'), 'Session unavailable')}"),
        ("Technical evidence", f"Completed daily session: {_text(tech.get('as_of'), 'Unavailable')}; "
                               f"{quote_check}"),
        ("Technical reasons", reasons),
        ("Indicators", _metrics(tech)),
        ("Change since previous delivered report", _change(row)),
        ("Saved assessment", _text(row.get("assessment"))),
        ("Saved comments", _text(row.get("comments"))),
        ("Saved entry conditions (check coverage below)" if isinstance(row.get("investment"), Mapping)
         else "Manual entry conditions", _text(row.get("gate"), "No separate manual gate supplied")),
        ("Saved research date", _text(row.get("research_date") or research_as_of)),
    ]
    if row.get("quote_error"):
        details.insert(1, ("Quote unavailable / limitation", _text(row["quote_error"])))
    details.extend(_signal_details(row))
    return details


def render_report(report, *, include_details=True):
    """Return ``(subject, plain_text, html_text)`` for an assembled report.

    All rows are retained in input order. Missing quote/technical fields remain
    visibly unavailable; static research prices are never read as a fallback.
    No values are interpolated into HTML attributes or unescaped markup. With
    include_details=False the caller must attach the default full HTML report;
    the body retains all tickers and quote timestamps but omits expanded detail.
    """
    if not isinstance(report, Mapping):
        raise TypeError("report must be a mapping")
    rows = report.get("rows", [])
    if not isinstance(rows, (list, tuple)) or any(not isinstance(row, Mapping) for row in rows):
        raise TypeError("report rows must be a list of mappings")
    has_investment = "portfolio_summary" in report or any("investment" in row for row in rows)
    disclaimer = INVESTMENT_DISCLAIMER if has_investment else DISCLAIMER
    has_signals = any(isinstance(row.get("buy_sell_signals"), Mapping) for row in rows)
    if has_signals:
        disclaimer += SIGNAL_DISCLAIMER
    overview = _portfolio_overview(report) if has_investment else []
    counts = Counter(_status(row) for row in rows)
    changed = [row for row in rows if _is_change(row)]
    inside = [row for row in rows if row.get("zone_status") == "inside"
              and row.get("price") not in (None, "")]
    missing = sum(row.get("price") in (None, "") for row in rows)
    day = _text(report.get("session_date"), "Date unavailable")
    subject = (f"Investment watchlist | {day} NY | "
               f"{counts['PASS']} PASS, {counts['WAIT']} WAIT, {counts['FAIL']} FAIL")
    signal_counts = Counter(
        _mapping(assessment).get("status")
        for row in rows
        for assessment in _mapping(_mapping(row.get("buy_sell_signals")).get("timeframes")).values())
    if signal_counts["BUY"] or signal_counts["SELL"]:
        subject += f" | {signal_counts['BUY']} BUY, {signal_counts['SELL']} SELL candle signals"
    subject = re.sub(r"[\r\n\x00-\x1f\x7f]+", " ", subject)
    summary = (f"{len(rows)} tickers | " + " | ".join(f"{counts[status]} {status}" for status in STATUSES)
               + f" | {len(inside)} inside saved zones | {missing} prices unavailable")
    if has_signals:
        summary += (f" | candle timeframes: {signal_counts['BUY']} BUY, {signal_counts['SELL']} SELL, "
                    f"{signal_counts['PENDING_BUY'] + signal_counts['PENDING_SELL']} pending")
    metadata = [
        ("NY trading session", day),
        ("Report generated", _stamp(report.get("generated_at"))),
        ("Scheduled delivery", _stamp(report.get("scheduled_at"))),
        ("NY regular market open", _stamp(report.get("market_open"))),
        ("Previous delivered report", _text(report.get("previous_session_date"), "None — first report")),
        ("Saved research snapshot", _text(report.get("research_as_of"))),
    ]
    changes_title = "Changes since previous delivered report"
    changes = [f"{_text(row.get('symbol'))}: {_change(row)}" for row in changed]
    if not changes:
        changes = [("No previous delivered report to compare." if not report.get("previous_session_date")
                    else "No reported technical grade or saved-zone relationship changes.")]

    plain = ["INVESTMENT WATCHLIST", *[f"{key}: {value}" for key, value in metadata], "", summary,
             "", changes_title, *[f"- {value}" for value in changes], "", disclaimer,
             *(["", "PORTFOLIO EXPOSURE", *[f"{key}: {value}" for key, value in overview]] if overview else []),
             "", "ALL TICKERS — SAVED LEVELS AND CURRENT CHECKS",
             "TP = saved take-profit/review level. All numeric levels use the row's currency."]
    research_warning = report.get("research_warning")
    if research_warning:
        plain.insert(1, "RESEARCH DATA WARNING: " + _text(research_warning))
    html = ["<!doctype html><html><head><meta charset=\"utf-8\"></head>",
            '<body style="margin:0;padding:16px;background:#f3f5f8;color:#192433;font-family:Arial,sans-serif;font-size:13px;line-height:1.5">',
            '<div style="max-width:1080px;margin:0 auto;background:#fff;padding:20px">',
            '<h1 style="font-size:23px;margin:0 0 12px">Investment watchlist</h1>',
            (f'<p style="background:#fff1d9;padding:12px;color:#814b00"><b>Research data warning:</b> {_html(research_warning)}</p>'
             if research_warning else ""),
            '<p style="margin:0 0 14px">' + "<br>".join(f"<b>{_html(k)}:</b> {_html(v)}" for k, v in metadata) + "</p>",
            f'<p style="background:#eef2f7;padding:12px"><b>{_html(summary)}</b></p>',
            f'<h2 style="font-size:17px">{changes_title}</h2><ul>' + "".join(f"<li>{_html(v)}</li>" for v in changes) + "</ul>",
            f'<p style="color:#4c5665;font-size:12px">{_html(disclaimer)}</p>',
            ('<h2 style="font-size:17px">Portfolio exposure</h2><p>'
             + "<br>".join(f"<b>{_html(key)}:</b> {_html(value)}" for key, value in overview) + "</p>" if overview else ""),
            '<h2 style="font-size:17px">All tickers — saved levels and current checks</h2>',
            '<p>TP = saved take-profit/review level. All numeric levels use the row’s currency.</p>',
            '<table role="table" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;font-size:12px;text-align:left">',
            '<thead><tr>' + "".join('<th scope="col" style="padding:8px;border-bottom:2px solid #c6cdd8;background:#edf1f6">' + x + "</th>"
                                   for x in ("Ticker", "Quote / saved zone", "Technical / investment checks" if has_investment else "Technical check", "Saved entry", "Saved TP", "Saved stop / review")) + "</tr></thead><tbody>"]

    if "news_context" in report:
        checked_at=datetime.now(timezone.utc)
        plain.insert(plain.index("ALL TICKERS — SAVED LEVELS AND CURRENT CHECKS"),
                     "LOCAL NEWS CONTEXT\n"+news_analysis_text(report["news_context"],checked_at)+"\n")
        insert_at=next(i for i,line in enumerate(html) if line.startswith('<h2 style="font-size:17px">All tickers'))
        html.insert(insert_at,render_news_analysis(report["news_context"],checked_at))

    for row in rows:
        symbol = _text(row.get("symbol"), "Unknown ticker")
        holding = " · Held" if row.get("holding") is True else ""
        status = _status(row)
        title = symbol + holding
        plain.extend(["", title, f"Quote: {_price(row)}", f"Saved zone: {_zone(row)}",
                      _technical_label(row), f"Saved entry: {_text(row.get('entry'))}",
                      f"Saved TP: {_text(row.get('tp'))}", f"Saved stop / review: {_text(row.get('stop'))}"])
        signal_summary = _signal_summary(row)
        if signal_summary:
            plain.append("Candle signals: " + signal_summary)
        if has_investment:
            plain.append(_investment_short(row))
        quote_field = _html(_price(row)) + "<br>" + _html(_zone(row))
        if not include_details:
            quote_info = (_stamp(row.get("quote_time")) + "; "
                          + _text(row.get("quote_label"), "Session unavailable"))
            quote_field += "<br>" + _html(quote_info)
            if row.get("quote_error"):
                quote_field += "<br>" + _html(row["quote_error"])
            plain.extend(["Quote time / session: " + quote_info,
                          "Daily evidence: " + _text((row.get("technical") or {}).get("as_of")
                                                   if isinstance(row.get("technical"), Mapping) else None,
                                                   "Unavailable"),
                          "Change: " + _change(row)])
            if row.get("quote_error"):
                plain.append("Quote limitation: " + _text(row["quote_error"]))
        technical_field = ('<span style="color:' + COLORS[status] + '"><b>' + _html(_technical_label(row))
                           + '</b></span><br>Daily: ' + _html((row.get("technical") or {}).get("as_of")
                                                            if isinstance(row.get("technical"), Mapping) else "Unavailable"))
        if signal_summary:
            technical_field += "<br>Candle signals: " + _html(signal_summary)
        if has_investment:
            technical_field += "<br>" + _html(_investment_short(row))
        fields = [_html(title), quote_field, technical_field,
                  _html(row.get("entry")), _html(row.get("tp")), _html(row.get("stop"))]
        background = "#fff9e9" if _is_change(row) else "#ffffff"
        html.append('<tr style="background:' + background + '">' + "".join('<td valign="top">' + field + "</td>" for field in fields) + "</tr>")
    html.append('</tbody></table>')
    if not include_details:
        attachment_note = ("Full technical and investment evidence, source dates, unverified items and saved review conditions "
                           "are in the attached HTML report." if has_investment else
                           "Full technical evidence and saved review conditions are in the attached HTML report.")
        plain.extend(["", attachment_note])
        html.append('<p style="padding:12px;background:#eef2f7">' + attachment_note + "</p></div></body></html>")
        return subject, "\n".join(plain) + "\n", "\n".join(html)
    html.append('<h2 style="font-size:17px;margin-top:24px">Evidence and saved review conditions</h2>')
    plain.extend(["", "EVIDENCE AND SAVED REVIEW CONDITIONS"])
    for row in rows:
        title = f"{_text(row.get('symbol'), 'Unknown ticker')} — {_technical_label(row)}"
        details = _details(row, report.get("research_as_of"))
        if has_investment:
            details.extend(_investment_details(row))
        plain.extend(["", title, *[f"{key}: {value}" for key, value in details]])
        html.append('<div style="padding:12px 0;border-top:1px solid #dce1e8"><h3 style="font-size:14px;margin:0 0 6px">' + _html(title) + "</h3>"
                    + "<br>".join(f"<b>{_html(key)}:</b> {_html(value)}" for key, value in details) + "</div>")
    html.append("</div></body></html>")
    return subject, "\n".join(plain) + "\n", "\n".join(html)
