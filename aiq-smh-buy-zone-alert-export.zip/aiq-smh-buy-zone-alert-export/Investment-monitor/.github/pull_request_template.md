## Summary

- Describe the behavior changed and why.

## Validation

- [ ] Offline unit suite passes
- [ ] Compilation and Ruff checks pass
- [ ] No live configuration, portfolio data, credentials, reports, or logs added
- [ ] Behavior changes include a regression test