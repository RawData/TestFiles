#!/usr/bin/env python3
"""Install the separate Python daily watchlist LaunchAgent; no AI scheduler."""
import argparse
from pathlib import Path
import os
import plistlib
import subprocess
import sys
from install_launchd import absolute_path, atomic_write, launchctl, runtime_home

ROOT = Path(__file__).resolve().parent
LABEL = "com.local.arora-daily-watchlist"


def make_plist(python, config, research, home):
    folder = home / "daily-watchlist"
    return {"Label": LABEL,
            "ProgramArguments": [str(absolute_path(python)), str(ROOT / "daily_watchlist.py"),
                                 "--config", str(absolute_path(config)), "--research", str(absolute_path(research))],
            "WorkingDirectory": str(ROOT), "RunAtLoad": True, "StartInterval": 60,
            "ProcessType": "Background", "EnvironmentVariables": {"ARORA_MONITOR_HOME": str(home), "PYTHONUNBUFFERED": "1"},
            "StandardOutPath": str(folder / "launchd.stdout.log"), "StandardErrorPath": str(folder / "launchd.stderr.log")}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("install", "status", "uninstall"))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output", type=absolute_path, default=ROOT / (LABEL + ".plist"))
    parser.add_argument("--python", type=absolute_path, default=ROOT / ".venv/bin/python")
    parser.add_argument("--config", type=absolute_path, default=ROOT / "config.json")
    parser.add_argument("--research", type=absolute_path, default=ROOT.parent / "master-watchlist-2026-09-07/master-watchlist-data.json")
    parser.add_argument("--runtime-home", type=absolute_path, default=runtime_home())
    args = parser.parse_args(argv)
    destination = Path.home() / "Library/LaunchAgents" / (LABEL + ".plist")
    domain = f"gui/{os.getuid()}"
    service = domain + "/" + LABEL
    if args.action == "status":
        result = launchctl("print", service, check=False)
        print(result.stdout if result.returncode == 0 else "Daily watchlist job is not loaded")
        return 0
    if args.action == "uninstall":
        if args.dry_run:
            print(f"Would unload/remove {destination}; reports retained")
            return 0
        if destination.exists() and plistlib.loads(destination.read_bytes()).get("Label") != LABEL:
            raise ValueError("Unexpected plist identity")
        if launchctl("print", service, check=False).returncode == 0:
            launchctl("bootout", service)
        destination.unlink(missing_ok=True)
        print("Daily watchlist schedule removed; price alerts and saved reports preserved")
        return 0
    # Import-only preflight, no SMTP/network/account secrets. Preserve venv symlink.
    check = subprocess.run([str(args.python), "-c", "import daily_watchlist; import monitor; monitor.load_config(__import__('sys').argv[1])", str(args.config)],
                           cwd=ROOT, capture_output=True, text=True, timeout=30)
    if check.returncode:
        raise RuntimeError("Daily-watchlist import/config preflight failed: " + check.stderr[-1500:])
    if not args.research.is_file():
        raise ValueError("Saved watchlist research path is missing")
    payload = plistlib.dumps(make_plist(args.python, args.config, args.research, args.runtime_home))
    if args.dry_run:
        if args.output.resolve() == destination.resolve():
            raise ValueError("Dry-run output cannot be the installed plist")
        atomic_write(args.output, payload)
        print(f"Reviewable plist written to {args.output}; schedule unchanged")
        return 0
    existing = destination.read_bytes() if destination.exists() else None
    if existing is not None and plistlib.loads(existing).get("Label") != LABEL:
        raise ValueError("Unexpected existing plist identity")
    loaded = launchctl("print", service, check=False).returncode == 0
    if loaded and existing == payload:
        launchctl("enable", service)
        print("Identical daily watchlist job is already loaded and enabled")
        return 0
    if loaded and existing is None:
        raise RuntimeError("Service already loaded without expected plist; inspect before replacing")
    (args.runtime_home / "daily-watchlist").mkdir(parents=True, exist_ok=True, mode=0o700)
    if loaded:
        launchctl("bootout", service)
    try:
        atomic_write(destination, payload)
        launchctl("enable", service)
        launchctl("bootstrap", domain, str(destination))
    except Exception:
        if existing is None:
            destination.unlink(missing_ok=True)
        else:
            atomic_write(destination, existing)
            if loaded:
                launchctl("bootstrap", domain, str(destination), check=False)
        raise
    print(f"Installed and enabled {service}; targets 09:00 America/New_York on XNYS trading days")
    return 0


if __name__ == "__main__":
    sys.exit(main())
