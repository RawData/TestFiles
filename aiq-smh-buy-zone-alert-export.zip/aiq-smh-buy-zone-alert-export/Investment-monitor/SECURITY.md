# Security and privacy

## Private data boundary

Never commit live configuration, email addresses, credentials, holdings,
position sizes, account values, generated reports, runtime state, logs, or
provider response caches. The `.gitignore` covers the standard local paths, but
it is not a substitute for reviewing staged content.

Before every push, run:

```bash
git diff --cached --check
git grep -nE '(/Users/|BEGIN (RSA|OPENSSH|EC) PRIVATE KEY|api[_-]?key[[:space:]]*[=:]|password[[:space:]]*[=:])' -- ':!tests/*'
```

Test fixtures deliberately contain placeholder domains and strings such as
`password` and `secret`; they must never contain working credentials.

## Reporting a vulnerability

Do not open a public issue containing credentials, portfolio data, local paths,
or exploit details. Use the repository owner's private security-reporting
channel. Rotate any credential that may have been disclosed.

## Operational safeguards

- Keep runtime files owner-only.
- Keep Ollama endpoints on loopback unless an authenticated transport is added.
- Treat all remote feeds and article text as untrusted data.
- Reproduce model findings before changing production behavior.
- Do not weaken stale-data, market-session, atomic-write, or delivery guards.