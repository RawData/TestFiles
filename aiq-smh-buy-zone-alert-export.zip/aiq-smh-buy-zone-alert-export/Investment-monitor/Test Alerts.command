#!/bin/bash
set -euo pipefail
monitor_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd -- "$monitor_root"

finish() {
  if [ -t 0 ]; then
    read -r -p "Press Return to close this window. " || true
  fi
}
trap finish EXIT

echo "Sending one clearly labelled TEST ONLY message to each enabled Mac/email destination."
echo "The live watchlist and price-alert history are unchanged."
if [ ! -x .venv/bin/python ]; then
  echo "Python environment is missing. Complete Install.command first."
  exit 1
fi
.venv/bin/python test_delivery.py --send
