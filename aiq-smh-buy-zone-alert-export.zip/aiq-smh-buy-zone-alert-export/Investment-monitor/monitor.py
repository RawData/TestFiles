#!/usr/bin/env python3
"""Observe saved US/Hong Kong price conditions and deliver alerts; never trade."""

import argparse
import copy
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from email.message import EmailMessage
from email.utils import formatdate
import fcntl
import getpass
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import smtplib
import ssl
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid

from market_clock import MARKETS, market_session, extended_market_session

UTC = timezone.utc
SOURCE = "Yahoo Finance (unofficial; may be delayed)"
EXTENDED_SOURCE = "Yahoo Finance 1-minute extended-hours chart (unofficial; may be delayed; trade time/volume unverified)"
LOG = logging.getLogger("arora-monitor")
CONFIG_PATH = Path(__file__).with_name("config.json")
DEFAULT_CONFIG = CONFIG_PATH if CONFIG_PATH.exists() else Path(__file__).with_name("config.example.json")


def runtime_home():
    return Path(os.environ.get("ARORA_MONITOR_HOME", str(
        Path.home() / "Library/Application Support/AroraPriceMonitor"))).expanduser()


def number(value):
    if isinstance(value, bool):
        raise ValueError("Expected a positive finite number")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("Expected a positive finite number") from exc
    if not result.is_finite() or result <= 0:
        raise ValueError("Expected a positive finite number")
    return result


@dataclass(frozen=True)
class Quote:
    symbol: str
    price: Decimal
    timestamp: datetime
    currency: str = "USD"
    source: str = SOURCE
    phase: str = "regular"

    def as_dict(self):
        result = {"symbol": self.symbol, "price": str(self.price),
                "timestamp": self.timestamp.isoformat(), "currency": self.currency,
                "source": self.source}
        if self.phase != "regular":
            result["phase"] = self.phase
            result["timestamp_basis"] = "Start of a completed one-minute chart bar, not a verified last-trade timestamp"
        return result


def parse_quote(symbol, payload):
    try:
        chart = payload["chart"]
        if chart.get("error"):
            raise ValueError("Provider returned an error")
        meta = chart["result"][0]["meta"]
        if meta["symbol"].upper() != symbol.upper():
            raise ValueError("Provider returned a different symbol")
        stamp = number(meta["regularMarketTime"])
        quote = Quote(symbol, number(meta["regularMarketPrice"]),
                      datetime.fromtimestamp(float(stamp), UTC), meta["currency"])
        market = "HK" if re.fullmatch(r"[0-9]{4,5}\.HK", symbol) else "US"
        if meta.get("exchangeTimezoneName") != MARKETS[market]["timezone"]:
            raise ValueError("Unexpected exchange timezone for symbol")
        if quote.currency != MARKETS[market]["currency"]:
            raise ValueError("Unexpected quote currency for symbol")
        return quote
    except (KeyError, TypeError, IndexError, OverflowError, OSError) as exc:
        raise ValueError("Provider response lacks a usable regular-session quote") from exc


def fetch_payload(symbol, extended=False):
    # Only configuration-validated ticker symbols reach this URL.
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?range=1d&interval=1m"
    if extended:
        url += "&includePrePost=true"
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(2):
        try:
            with urllib.request.urlopen(request, timeout=12) as response:
                raw = response.read(2_000_001)
            if len(raw) > 2_000_000:
                raise ValueError("Provider response too large")
            return json.loads(raw)
        except urllib.error.HTTPError as exc:
            # Do not immediately retry rate limits, authentication, or missing tickers.
            if exc.code not in (500, 502, 503, 504) or attempt:
                raise ValueError(f"Price provider HTTP {exc.code}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            if attempt:
                raise ValueError("Price provider unavailable or timed out") from exc
        time.sleep(1)
    raise ValueError("Price provider unavailable")


def fetch_quote(symbol):
    return parse_quote(symbol, fetch_payload(symbol))


def parse_extended_quote(symbol, payload, session, now):
    """Select only a completed, in-session US chart bar; never use regular metadata as fallback."""
    if not session or session.get("market") != "US" or session.get("phase") not in ("pre", "post"):
        raise ValueError("An eligible US extended session is required")
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    if symbol.endswith(".HK"):
        raise ValueError("US extended-hours data cannot be used for Hong Kong tickers")
    try:
        chart = payload["chart"]
        if chart.get("error"):
            raise ValueError("Provider returned an error")
        result = chart["result"][0]
        meta = result["meta"]
        if meta["symbol"].upper() != symbol.upper():
            raise ValueError("Provider returned a different symbol")
        if meta.get("currency") != "USD" or meta.get("exchangeTimezoneName") != MARKETS["US"]["timezone"]:
            raise ValueError("Unexpected extended-hours exchange or currency")
        if meta.get("dataGranularity") != "1m":
            raise ValueError("Extended-hours data must use one-minute bars")
        stamps = result.get("timestamp", [])
        closes = result["indicators"]["quote"][0]["close"]
        if len(stamps) != len(closes):
            raise ValueError("Extended-hours timestamps and prices differ in length")
        selected = None
        for stamp, close in zip(stamps, closes):
            if close is None:
                continue
            # Yahoo sometimes appends an irregular last-price point to the bar series.
            # Ignore that point and the unfinished current minute.
            timestamp = number(stamp)
            if timestamp % 60:
                continue
            moment = datetime.fromtimestamp(float(timestamp), UTC)
            if not session["open"] <= moment < session["close"]:
                continue
            if moment + timedelta(minutes=1) > min(now, session["close"]):
                continue
            price = number(close)
            if selected is None or moment > selected.timestamp:
                selected = Quote(symbol, price, moment, "USD", EXTENDED_SOURCE, session["phase"])
        if selected is None:
            raise ValueError("No completed chart bar for the current extended session; regular close is not substituted")
        return selected
    except (KeyError, TypeError, IndexError, OverflowError, OSError) as exc:
        raise ValueError("Provider response lacks usable extended-hours chart data") from exc


def fetch_extended_quote(symbol, session):
    payload = fetch_payload(symbol, extended=True)
    return parse_extended_quote(symbol, payload, session, datetime.now(UTC))


def validate_quote(quote, now, session, max_age_seconds=1200):
    number(quote.price)
    if session is None:
        raise ValueError("Market is closed: no eligible regular-session quote")
    phase = session.get("phase", "regular")
    if quote.phase != phase:
        raise ValueError("Quote session does not match the requested trading session")
    expected_currency = session.get("currency", "USD") if session else "USD"
    if quote.currency != expected_currency:
        raise ValueError(f"Quote currency is not {expected_currency}")
    if quote.timestamp.tzinfo is None or now.tzinfo is None:
        raise ValueError("Quote and current time must include timezone")
    # Extended data is a completed minute bar: retain its start in the output,
    # but measure the age of its closing value from that minute's end.
    price_as_of = quote.timestamp + (timedelta(minutes=1) if phase != "regular" else timedelta())
    age = (now - price_as_of).total_seconds()
    if age < -60:
        raise ValueError("Quote timestamp is in the future")
    if age > max_age_seconds:
        raise ValueError(f"Stale quote ({int(age // 60)} minutes old)")
    # Yahoo's regularMarketTime can stamp the closing auction 1-2 seconds
    # after the exchange close. Post-market price fields are never parsed.
    if phase == "regular":
        in_session = session["open"] <= quote.timestamp <= session["close"] + timedelta(seconds=5)
    else:
        in_session = (session["open"] <= quote.timestamp < session["close"]
                      and quote.timestamp + timedelta(minutes=1) <= min(now, session["close"]))
        if not session["open"] <= now <= session["close"] + (timedelta(minutes=20) if phase == "post" else timedelta()):
            in_session = False
        if phase == "pre" and now >= session["close"]:
            in_session = False
    if not in_session:
        raise ValueError("Quote is outside the requested trading session")
    break_start, break_end = session.get("break_start"), session.get("break_end")
    if break_start and break_end:
        if break_start < quote.timestamp < break_end:
            raise ValueError("Quote is during the lunch break")
        if now >= break_end and quote.timestamp < break_end:
            raise ValueError("Afternoon check requires an afternoon quote")
    if session["slot"].endswith(":close") and quote.timestamp < session.get(
            "closing_quote_min", session["close"] - timedelta(minutes=1)):
        raise ValueError("Closing check is waiting for a quote from the final minute of the session")


def classify(price, low, high):
    price, low, high = number(price), number(low), number(high)
    if low > high:
        raise ValueError("Zone lower bound exceeds upper bound")
    return "below" if price < low else "above" if price > high else "inside"


def zone_key(rule):
    key = f"{rule['symbol']}:{number(rule['low']).normalize()}:{number(rule['high']).normalize()}"
    if rule.get("market", "US") != "US":
        key += f":{rule['market']}:{rule.get('currency', MARKETS[rule['market']]['currency'])}"
    if rule.get("trigger", "range") != "range":
        key += f":{rule['trigger']}"
    return key


def rule_status(price, rule):
    if rule.get("trigger", "range") == "at_or_below":
        return "inside" if number(price) <= number(rule["high"]) else "above"
    return classify(price, rule["low"], rule["high"])


def observe(previous, quote, rule, slot, channels, now):
    """Pure transition: caller must validate freshness before invoking this."""
    key = zone_key(rule)
    previous = previous if previous and previous.get("zone_key") == key else None
    status = rule_status(quote.price, rule)
    pending = copy.deepcopy(previous.get("pending")) if previous else None
    if status != "inside":
        pending = None  # Never deliver an old entry after a fresh exit.
    elif previous is None or previous.get("status") != "inside":
        reason = ("First observed inside saved zone" if previous is None else
                  f"Entered saved zone from {previous['status']}")
        if rule.get("trigger") == "at_or_below":
            reason = "First observed at/below review threshold" if previous is None else "Crossed at/below review threshold"
        pending = {"id": uuid.uuid4().hex, "reason": reason,
                   "created_at": now.isoformat(), "ack": []} if channels else None
    if pending and set(channels) <= set(pending["ack"]):
        pending = None
    return {"status": status, "zone_key": key, "last_slot": slot,
            "quote": quote.as_dict(), "pending": pending}


def load_config(path):
    config = json.loads(Path(path).read_text())
    if config.get("version") != 1:
        raise ValueError("Unsupported config version")
    from buy_sell_signals import validate_settings as validate_signal_settings
    validate_signal_settings(config)
    if not isinstance(config.get("extended_hours", False), bool):
        raise ValueError("extended_hours must be true or false")
    technical = config.get("technical_analysis", {})
    if not isinstance(technical, dict) or not isinstance(technical.get("enabled", False), bool):
        raise ValueError("technical_analysis.enabled must be true or false")
    if technical:
        from technical_data import DailyHistoryService
        allowed = {"enabled", "publish_grace_minutes", "retry_seconds", "gap_window", "max_missing_sessions"}
        if set(technical) - allowed:
            raise ValueError("Unknown technical_analysis configuration field")
        DailyHistoryService(Path("."), config, read_only=True)  # Validation only, no I/O.
    rules = config.get("watchlist")
    if not isinstance(rules, list) or not rules:
        raise ValueError("Watchlist must be a non-empty list")
    symbols = set()
    for rule in rules:
        symbol = rule.get("symbol", "")
        market = rule.get("market", "US")
        if market not in MARKETS:
            raise ValueError(f"Unsupported market for {symbol}")
        pattern = r"[0-9]{4,5}\.HK" if market == "HK" else r"[A-Z][A-Z0-9.-]{0,9}"
        if not re.fullmatch(pattern, symbol) or symbol in symbols or (market == "US" and symbol.endswith(".HK")):
            raise ValueError(f"Invalid or duplicate ticker: {symbol!r}")
        if rule.get("currency", MARKETS[market]["currency"]) != MARKETS[market]["currency"]:
            raise ValueError(f"Currency does not match market for {symbol}")
        symbols.add(symbol)
        if "zone_as_of" in rule:
            if not isinstance(rule["zone_as_of"], str) or len(rule["zone_as_of"]) != 10:
                raise ValueError(f"Invalid zone date for {symbol}")
            datetime.strptime(rule["zone_as_of"], "%Y-%m-%d")
        if "technical_policy" in rule:
            from technical_analysis import _policy
            policy = rule["technical_policy"]
            if not isinstance(policy, dict) or policy.get("mode", "equity") not in ("equity", "nav_review"):
                raise ValueError(f"Invalid technical policy for {symbol}")
            _policy(policy)
        if number(rule["low"]) > number(rule["high"]):
            raise ValueError(f"Invalid zone for {symbol}")
        if rule.get("trigger", "range") not in ("range", "at_or_below"):
            raise ValueError(f"Invalid trigger for {symbol}")
        if rule.get("trigger") == "at_or_below" and (
                number(rule["low"]) != number(rule["high"]) or rule.get("alert_kind") != "support_watch"):
            raise ValueError("At-or-below reviews require equal low/high and support_watch kind")
        if not isinstance(rule.get("enabled", True), bool):
            raise ValueError("Rule enabled must be true or false")
        if rule.get("alert_kind", "model_zone") not in ("model_zone", "review_zone", "support_watch"):
            raise ValueError(f"Invalid alert kind for {symbol}")
        for field in ("source", "review_notes"):
            if field in rule and (not isinstance(rule[field], str) or not rule[field].strip()
                                  or len(rule[field]) > 4000 or any(c in rule[field] for c in "\r\n\x00")):
                raise ValueError(f"Invalid {field} for {symbol}; use one non-empty line")
        if rule.get("alert_kind", "model_zone") != "model_zone" and not all(
                rule.get(field) for field in ("source", "review_notes")):
            raise ValueError(f"Independent review rule {symbol} needs source and review_notes")
    age = config.get("max_quote_age_seconds", 1200)
    if isinstance(age, bool) or not isinstance(age, int) or not 60 <= age <= 1800:
        raise ValueError("max_quote_age_seconds must be between 60 and 1800")
    if config.get("currency") != "USD":
        raise ValueError("Default watchlist currency must be USD; use per-rule HK/HKD metadata")
    alerts = config["alerts"]
    if not isinstance(alerts["mac"], bool) or not isinstance(alerts["email"]["enabled"], bool):
        raise ValueError("Alert switches must be true or false")
    email = alerts["email"]
    if email["enabled"]:
        for address in [email["username"], email["from"], *email["to"]]:
            if not isinstance(address, str) or not re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", address):
                raise ValueError("Email addresses must be plain addresses without display names")
        if not email["to"] or len(set(email["to"])) != len(email["to"]):
            raise ValueError("Email recipients must be non-empty and unique")
        if email.get("security") != "starttls":
            raise ValueError("Email requires STARTTLS")
        if not isinstance(email["host"], str) or not re.fullmatch(r"[A-Za-z0-9.-]+", email["host"]):
            raise ValueError("Invalid SMTP hostname")
        if not isinstance(email["port"], int) or not 1 <= email["port"] <= 65535:
            raise ValueError("Invalid SMTP port")
    if config.get("investment_analysis"):
        from investment_checks import validate_settings
        validate_settings(config, path)
    return config


def channel_names(config):
    alerts = config["alerts"]
    return (["mac"] if alerts["mac"] else []) + (
        [f"email:{address}" for address in alerts["email"]["to"]]
        if alerts["email"]["enabled"] else [])


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as handle:
            json.dump(value, handle, indent=2, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load_state(path):
    if not path.exists():
        return {"version": 1, "symbols": {}}
    state = json.loads(path.read_text())
    if state.get("version") != 1 or not isinstance(state.get("symbols"), dict):
        raise ValueError("State file is invalid; preserve it and investigate before resetting")
    entries = []
    for bucket, phase in (("symbols", "regular"), ("pre_symbols", "pre"), ("post_symbols", "post")):
        observations = state.get(bucket, {})
        if not isinstance(observations, dict):
            raise ValueError("State contains an invalid session observation store")
        for entry in observations.values():
            if isinstance(entry, dict) and isinstance(entry.get("quote"), dict):
                if entry["quote"].get("phase", "regular") != phase:
                    raise ValueError("State quote is in the wrong session observation store")
            entries.append(entry)
    for entry in entries:
        if not isinstance(entry, dict) or entry.get("status") not in ("inside", "below", "above"):
            raise ValueError("State contains an invalid price observation")
        if not isinstance(entry.get("zone_key"), str) or not isinstance(entry.get("last_slot"), str):
            raise ValueError("State contains invalid zone or schedule data")
        quote = entry["quote"]
        number(quote["price"])
        if datetime.fromisoformat(quote["timestamp"]).tzinfo is None:
            raise ValueError("State quote timestamp has no timezone")
        pending = entry.get("pending")
        if pending is not None and (not isinstance(pending, dict) or
                                    not isinstance(pending.get("ack"), list) or
                                    not all(isinstance(pending.get(k), str) for k in ("id", "reason", "created_at"))):
            raise ValueError("State contains an invalid pending delivery")
    return state


def smtp_password(home, email_config):
    supplied = os.environ.get("ARORA_SMTP_PASSWORD")
    if supplied:
        return supplied
    path = home / "email-secret.json"
    if not path.exists():
        raise ValueError("Email is not set up. Run monitor.py --configure-email locally")
    info = path.lstat()
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) & 0o077):
        raise ValueError("Email secret must be a regular file owned by you with permissions 600")
    secret = json.loads(path.read_text())
    if secret.get("username") != email_config["username"] or secret.get("host") != email_config["host"]:
        raise ValueError("Stored email credentials do not match current SMTP configuration")
    if not isinstance(secret.get("password"), str) or not secret["password"]:
        raise ValueError("Stored email password is empty")
    return secret["password"]


def connect_smtp(config, password):
    connection = smtplib.SMTP(config["host"], config["port"], timeout=20)
    try:
        connection.ehlo()
        connection.starttls(context=ssl.create_default_context())
        connection.ehlo()
        connection.login(config["username"], password)
    except Exception:
        connection.close()
        raise
    return connection


def configure_email(config, home):
    if not sys.stdin.isatty():
        raise ValueError("Run --configure-email in Terminal so the password stays local")
    email = config["alerts"]["email"]
    print(f"SMTP account: {email['username']} at {email['host']}:{email['port']}")
    print("Enter an app-specific password locally. It is hidden and never printed.")
    password = getpass.getpass("App-specific password: ").strip()
    if not password:
        raise ValueError("No password entered; nothing saved")
    # Authenticate first; this does not send any email.
    with connect_smtp(email, password):
        pass
    home.mkdir(parents=True, exist_ok=True, mode=0o700)
    atomic_json(home / "email-secret.json", {"username": email["username"],
                "host": email["host"], "password": password})
    print("SMTP login verified. Credentials saved locally with owner-only file permissions.")
    print("No test email was sent.")


def send_channel(channel, title, body, config, home):
    if channel == "mac":
        # Pass all dynamic content as argv; no executable AppleScript interpolation.
        script = 'on run argv\n display notification (item 2 of argv) with title (item 1 of argv)\nend run'
        rows = [line for line in body.splitlines() if "| saved zone" in line or "| review threshold" in line]
        summary = "\n".join(rows[:6])
        if len(rows) > 6:
            summary += f"\nPlus {len(rows)-6} more. Full details in email and monitor.log."
        summary += "\nQuotes may be delayed. Review before acting."
        subprocess.run(["/usr/bin/osascript", "-e", script, title, summary],
                       check=True, capture_output=True, text=True, timeout=20)
        return
    recipient = channel.removeprefix("email:")
    email = config["alerts"]["email"]
    message = EmailMessage()
    message["From"] = email["from"]
    message["To"] = recipient
    message["Subject"] = title
    message["Date"] = formatdate(localtime=False)
    events = re.findall(r"^Event: ([a-f0-9]+)", body, re.MULTILINE)
    identity = hashlib.sha256((recipient + ":" + ":".join(sorted(events))).encode()).hexdigest()
    message["Message-ID"] = f"<arora.{identity}@{email['from'].split('@')[-1]}>"
    message.set_content(body)
    connection = connect_smtp(email, smtp_password(home, email))
    try:
        refused = connection.send_message(message, from_addr=email["from"], to_addrs=[recipient])
        if refused:
            raise ValueError("SMTP server refused recipient")
    finally:
        # An error during QUIT must not turn confirmed message acceptance into
        # a failed delivery and duplicate it on the next polling cycle.
        try:
            connection.quit()
        except (smtplib.SMTPException, OSError):
            pass
        connection.close()


def update_technical_event(state, rule, entry, previous, channels, now):
    """Track meaningful grades across streams; retain pending per-recipient delivery.

    No event on migration alone or on changing indicator decimals. Within a
    daily data date each grade is announced at most once, unless a new observed
    price entry independently warrants an alert.
    """
    technical = entry["technical"]
    trackers = state.setdefault("technical_notifications", {})
    old = trackers.get(rule["symbol"], {})
    grade = technical["status"]
    stamp = entry["quote"]["timestamp"]
    if old.get("quote_time") and datetime.fromisoformat(stamp) < datetime.fromisoformat(old["quote_time"]):
        return
    fingerprint = f"{technical.get('expected_session') or technical.get('as_of') or now.date().isoformat()}:{grade}"
    seen = old.get("seen", [])[-30:]
    changed = old.get("status") is not None and old["status"] != grade
    if entry["status"] == "inside" and channels:
        if (changed and (fingerprint not in seen or entry.get("pending"))) or (
                not old and (entry.get("pending") or {}).get("ack")):
            # New verdict gets a new event, including recipients who already
            # received the earlier verdict. Never change an ACKed event's meaning.
            previous_id = entry["pending"]["id"] if entry.get("pending") else None
            entry["pending"] = {"id": uuid.uuid4().hex, "ack": [], "created_at": now.isoformat(),
                                "reason": f"Technical assessment changed from {old.get('status', 'not checked')} to {grade} while inside the saved zone"}
            if previous_id:
                LOG.info("%s superseded pending event %s after technical change", rule["symbol"], previous_id)
        if entry.get("pending") and fingerprint not in seen:
            seen.append(fingerprint)
    trackers[rule["symbol"]] = {"status": grade, "quote_time": stamp, "seen": seen[-30:]}


def technical_action(rule, entry):
    status = entry.get("technical", {}).get("status")
    if rule.get("trigger") == "at_or_below":
        return "RISK REVIEW - not a buy signal"
    if rule.get("alert_kind") == "support_watch":
        return "SUPPORT WATCH - no standing buy recommendation"
    return {"PASS": "CHECKS MET (PASS) - watchlist only; buying advantage not established",
            "FAIL": "DO NOT ENTER on this setup - technical checks failed",
            "WAIT": "WAIT - technical entry confirmation incomplete",
            "UNAVAILABLE": "WATCH ONLY - current technical data unavailable",
            "NOT_APPLICABLE": "NAV / INCOME REVIEW - equity entry filter not applicable"}.get(
                status, "WATCH ONLY - buy conditions NOT confirmed")


def technical_lines(technical):
    if not technical:
        return ["Technical checks: not enabled for this observation."]
    lines = [f"Automatic daily technical check: {technical['status']} | completed data through {technical.get('as_of') or 'unavailable'}",
             *[f"- {reason}" for reason in technical.get("reasons", [])]]
    lines.append("Evidence: historical testing did not establish a consistent buying advantage for this daily filter. Saved price zones and five-minute execution have not been backtested.")
    m = technical.get("metrics", {})
    def fmt(key):
        value = m.get(key)
        return f"{value:.2f}" if isinstance(value, (float, int)) else "unavailable"
    if m.get("sma50") is not None:
        lines.extend([
            f"Daily close {fmt('close')}; SMA20/50/200: {fmt('sma20')} / {fmt('sma50')} / {fmt('sma200')}; SMA50 change over 5 sessions: {fmt('sma50_slope')}",
            f"Structure: higher low={m.get('higher_low')}; lower low={m.get('lower_low')}; lower high={m.get('lower_high')}. Confirmed pivot breakout={m.get('breakout_confirmed')}; level {fmt('breakout_level')}",
            f"RSI14 {fmt('rsi14')}; MACD/signal {fmt('macd')} / {fmt('macd_signal')}; ATR14 {fmt('atr14')}; completed-session relative volume {fmt('relative_volume20')}x",
            f"Prior 20-session support/resistance: {fmt('support20')} / {fmt('resistance20')} (observations, not automatic stop/TP orders).",
        ])
    lines.append("Current quote can flag deterioration; it cannot confirm a daily reversal before the session closes.")
    if technical.get("fetched_at"):
        lines.append(f"History fetched: {technical['fetched_at']} | {technical.get('source', '')} | {technical.get('basis', '')}")
    return lines


def alert_text(items, config):
    symbols = ", ".join(rule["symbol"] for rule, entry in items)
    legacy_only = all(rule.get("alert_kind", "model_zone") == "model_zone" for rule, _ in items)
    title = f"{'Arora saved-zone alert' if legacy_only else 'Saved price review alert'}: {symbols}"
    phases = {entry["quote"].get("phase", "regular") for _, entry in items}
    extended = bool(phases & {"pre", "post"})
    if extended:
        phase_name = {"pre": "Pre-market", "post": "After-hours"}.get(next(iter(phases)) if len(phases) == 1 else "", "Extended-hours")
        title = f"{phase_name} indicative price review: {symbols}"
    title = "WATCH ONLY - buy conditions unconfirmed | " + title
    if any(entry.get("technical") for _, entry in items):
        grades = sorted({entry.get("technical", {}).get("status", "UNAVAILABLE") for _, entry in items})
        prefix = "TECHNICAL REVIEW " + "/".join(grades)
        title = f"{prefix} (not a buy instruction): {symbols}"
        if extended:
            title = f"{phase_name} indicative price review | " + title
    lines = []
    for rule, entry in items:
        price = number(entry["quote"]["price"])
        low, high = number(rule["low"]), number(rule["high"])
        mid = (low + high) / 2
        label = {"model_zone": "", "review_zone": " (review only)",
                 "support_watch": " (support watch only)"}[rule.get("alert_kind", "model_zone")]
        phase = entry["quote"].get("phase", "regular")
        if phase in ("pre", "post"):
            label += " (pre-market chart price)" if phase == "pre" else " (after-hours chart price)"
        unit = "HK$" if entry["quote"].get("currency") == "HKD" else "$"
        decimals = 3 if unit == "HK$" else 2
        if rule.get("trigger") == "at_or_below":
            first = f"{rule['symbol']}: {unit}{price:.{decimals}f} | review threshold <= {unit}{high:.{decimals}f}{label}"
            second = f"{entry['pending']['reason']}. Anomaly/risk review; no investment buy signal."
        else:
            first = f"{rule['symbol']}: {unit}{price:.{decimals}f} | saved zone {unit}{low:.{decimals}f}-{unit}{high:.{decimals}f}{label}"
            second = (f"{entry['pending']['reason']}. Midpoint {unit}{mid:.{decimals}f}; price vs midpoint "
                      f"{unit}{price-mid:+.{decimals}f} ({(price/mid-1)*100:+.2f}%).")
        kind = rule.get("alert_kind", "model_zone")
        status = technical_action(rule, entry)
        if entry.get("technical"):
            first += f" | {status}"
        lines.extend([first, f"ACTION STATUS: {status}",
                      f"What happened: {entry['pending']['reason']}.",
                      "What this confirms: the observed price meets the saved price condition only.",
                      ("Investment evidence below reports the checks actually performed; a price-zone entry is not a combined investment approval."
                       if entry.get("investment") else
                       "What this does NOT confirm: current fundamentals, NAV, the latest Arora recommendation or suitability to add.")])
        lines.extend(technical_lines(entry.get("technical")))
        if entry.get("investment"):
            from investment_checks import evidence_lines
            lines.extend(evidence_lines(entry["investment"]))
        if rule["symbol"] == "FISV":
            lines.extend([
                "Before considering a buy: verify a daily price base and a higher low; verify no further guidance cut, stable customer retention and improving cash conversion.",
                "Use the automatic technical result above for the chart filter. If technical or business checks are missing or fail: keep FISV on watch.",
                "Risk: a weekly close below $47 or another guidance cut requires a fresh thesis review. $47 is NOT an automatic stop order.",
            ])
        if kind == "model_zone":
            lines.append("Next step: verify the latest Arora recommendation; this is a saved range, not a newly confirmed model buy.")
        if rule.get("review_notes"):
            lines.append(f"Review conditions: {rule['review_notes']}")
        lines.extend([
            ("Remaining review: guidance, valuation, distribution sustainability, latest Arora view, and the saved plan's specific conditions. Portfolio limits are unset: exposure is reported, suitability is not assessed."
             if entry.get("investment") else
             "Remaining manual checks: fundamentals, NAV/distributions, portfolio size, and any ticker-specific close/retest/limit conditions in the saved plan. The automatic filter is a separate rule set, not verification of every saved condition."),
            "Technical details:", second,
            f"Quote: {entry['quote']['timestamp']} | {entry['quote']['source']}",
            f"Event: {entry['pending']['id']} | first detected {entry['pending']['created_at']}",
            f"Threshold source: {rule.get('source', config['zone_source'])}",
        ])
        if entry["quote"].get("timestamp_basis"):
            lines.append(f"Timestamp basis: {entry['quote']['timestamp_basis']}")
        lines.append("")
    lines.append("Research alert only; a technical PASS is not a standing buy recommendation. Review the current model and your portfolio before acting.")
    if extended:
        lines.append("Extended-hours chart observation only, not a confirmed trade or executable bid/ask. Yahoo may report zero volume or carried-forward prices. Confirm a current broker quote; liquidity and spreads can differ from the regular session.")
    if not legacy_only:
        if not any(entry.get("investment") for _, entry in items):
            lines.append("Company fundamentals and NAV conditions are not verified by this monitor.")
        if not any(entry.get("technical") for _, entry in items):
            lines.append("Only the price condition is checked automatically for this observation.")
    lines.append("Zones are maintained manually. This script does not read new Arora reports or place orders.")
    return title, "\n".join(lines)


def run_cycle(config, state, now, session, fetcher=fetch_quote, sender=None,
              persist=None, dry_run=False, clock=None, check_closed=False, state_key="symbols",
              technical_evaluator=None, investment_evaluator=None):
    """One bounded run. Fresh observations and delivery acknowledgements are persisted separately."""
    persist = persist or (lambda value: None)
    if dry_run:
        state = copy.deepcopy(state)
    expected_phase = {"symbols": "regular", "pre_symbols": "pre", "post_symbols": "post"}.get(state_key)
    if expected_phase is None:
        raise ValueError("Unknown session observation store")
    observations = state.setdefault(state_key, {})
    channels = channel_names(config)
    sessions = ({session.get("market", "US"): session} if session and "slot" in session else
                session if session is not None else {"US": None})
    if any(s and s.get("phase", "regular") != expected_phase for s in sessions.values()):
        raise ValueError("Requested session does not match its observation store")
    rules = [r for r in config["watchlist"] if r.get("enabled", True) and
             (sessions.get(r.get("market", "US")) is not None or (dry_run and check_closed))]
    if not channels:
        LOG.warning("All delivery channels are disabled; observations only")
    slots = {m: s["slot"] for m, s in sessions.items() if s is not None}
    slot = ",".join(slots.values()) or "diagnostic"
    due = [r for r in rules if dry_run or
           observations.get(r["symbol"], {}).get("last_slot") != slots[r.get("market", "US")] or
           observations.get(r["symbol"], {}).get("zone_key") != zone_key(r) or
           observations.get(r["symbol"], {}).get("pending")]
    if not due:
        LOG.info("Current five-minute slot already checked: %s", slot)
        return 0
    results = {}
    technical_results = {}
    technical_enabled = config.get("technical_analysis", {}).get("enabled", False)

    def fetch_observation(rule):
        try:
            quote = fetcher(rule["symbol"])
            if quote.symbol != rule["symbol"]:
                raise ValueError("Quote symbol mismatch")
            validate_quote(quote, clock() if clock else now, sessions.get(rule.get("market", "US")),
                           config.get("max_quote_age_seconds", 1200))
        except Exception as exc:
            quote = exc
        analysis = None
        if technical_enabled:
            try:
                if technical_evaluator is None:
                    raise ValueError("Technical evaluator is not configured")
                analysis = technical_evaluator(rule, {} if isinstance(quote, Exception) else quote.as_dict(), clock() if clock else now)
                if analysis.get("status") not in ("PASS", "WAIT", "FAIL", "UNAVAILABLE", "NOT_APPLICABLE"):
                    raise ValueError("Technical evaluator returned an invalid status")
            except Exception as exc:
                analysis = {"status": "UNAVAILABLE", "reasons": [f"Technical check failed ({type(exc).__name__})."],
                            "checked_at": (clock() if clock else now).isoformat(), "metrics": {}}
            analysis["live_quote_valid"] = not isinstance(quote, Exception)
        return quote, analysis

    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(fetch_observation, r): r["symbol"] for r in due}
        for future in as_completed(futures):
            symbol = futures[future]
            try:
                results[symbol], technical_results[symbol] = future.result()
            except Exception as exc:
                results[symbol] = exc
    investment_results = {}
    if config.get("investment_analysis", {}).get("enabled"):
        checked = clock() if clock else now
        try:
            if investment_evaluator is None:
                raise ValueError("Investment evaluator is not configured")
            investment_results, summary = investment_evaluator.batch(
                due, {s: q.as_dict() for s, q in results.items() if isinstance(q, Quote)}, checked, clock=clock)
            state["portfolio_review"] = summary
        except Exception as exc:
            from investment_checks import unavailable
            failure = unavailable(f"Investment evidence unavailable ({type(exc).__name__}).", checked)
            investment_results = {r["symbol"]: {"overall": "REVIEW", **{k: copy.deepcopy(failure) for k in
                                  ("nav", "fundamentals", "portfolio", "arora")}} for r in due}
        state.setdefault("investment_reviews", {}).update(copy.deepcopy(investment_results))
    errors = 0
    fresh = set()
    for rule in due:
        symbol = rule["symbol"]
        result = results[symbol]
        if technical_enabled and technical_results.get(symbol):
            state.setdefault("technical_reviews", {})[symbol] = copy.deepcopy(technical_results[symbol])
            if isinstance(result, Exception):
                LOG.info("%s daily-only technical=%s as_of=%s; live quote unavailable, no price alert", symbol,
                         technical_results[symbol]["status"], technical_results[symbol].get("as_of"))
        try:
            if isinstance(result, Exception):
                raise result
            if result.symbol != symbol:
                raise ValueError("Quote symbol mismatch")
            checked_at = clock() if clock else now
            rule_session = sessions.get(rule.get("market", "US"))
            validate_quote(result, checked_at, rule_session, config.get("max_quote_age_seconds", 1200))
            previous = observations.get(symbol)
            if previous and result.timestamp < datetime.fromisoformat(previous["quote"]["timestamp"]):
                raise ValueError("Quote is older than the last accepted observation")
            entry = observe(previous, result, rule, rule_session["slot"], channels, checked_at)
            if symbol in investment_results:
                entry["investment"] = investment_results[symbol]
                LOG.info("%s investment NAV=%s fundamentals=%s portfolio=%s; no combined buy approval", symbol,
                         entry["investment"]["nav"]["status"], entry["investment"]["fundamentals"]["status"],
                         entry["investment"]["portfolio"]["status"])
            if technical_enabled:
                entry["technical"] = technical_results[symbol]
                if entry["technical"].get("as_of"):
                    from technical_data import expected_completed_session
                    expected = expected_completed_session(checked_at, rule.get("market", "US"),
                        config.get("technical_analysis", {}).get("publish_grace_minutes", 20))
                    if entry["technical"]["as_of"] != expected:
                        entry["technical"]["status"] = "UNAVAILABLE"
                        entry["technical"]["reasons"].insert(0, "A new completed session became due while checking; wait for refreshed daily history.")
                update_technical_event(state, rule, entry, previous, channels, checked_at)
                state["technical_reviews"][symbol] = copy.deepcopy(entry["technical"])
                LOG.info("%s technical=%s daily_as_of=%s reasons=%s", symbol,
                         entry["technical"]["status"], entry["technical"].get("as_of", "unavailable"),
                         "; ".join(entry["technical"].get("reasons", [])))
            observations[symbol] = entry
            fresh.add(symbol)
            LOG.info("%s %s %s %s saved condition [%s, %s]; quote=%s%s", symbol, result.currency, result.price,
                     entry["status"], rule["low"], rule["high"], result.timestamp.isoformat(),
                     ("; below-zone caution, no entry alert" if entry["status"] == "below" else "") +
                     (f"; {expected_phase}-market chart bar" if expected_phase != "regular" else ""))
            if entry["pending"] and (not previous or not previous.get("pending") or
                                      previous["pending"]["id"] != entry["pending"]["id"]):
                title, body = alert_text([(rule, entry)], config)
                LOG.info("New alert event: %s\n%s", title, body)
        except Exception as exc:
            errors += 1
            stamp = f"; observed {result.currency} {result.price} at {result.timestamp.isoformat()}" if isinstance(result, Quote) else ""
            LOG.error("%s rejected: %s%s", symbol, str(exc), stamp)
    state["last_run_at"] = now.isoformat()
    state["last_run"] = {"slot": slot, "requested": len(due), "fresh": len(fresh), "errors": errors}
    if technical_enabled:
        state["last_run"]["technical_counts"] = {grade: sum(observations[s].get("technical", {}).get("status") == grade for s in fresh)
            for grade in ("PASS", "WAIT", "FAIL", "UNAVAILABLE", "NOT_APPLICABLE")}
    if expected_phase != "regular":
        state["last_run"]["stream"] = expected_phase
    if not dry_run:
        persist(state)  # Durable event before any external side effect.
    for channel in channels:
        # History requests and earlier deliveries can consume time; never send an aged quote.
        for rule in rules:
            symbol = rule["symbol"]
            if symbol in fresh:
                try:
                    validate_quote(results[symbol], clock() if clock else now,
                                   sessions.get(rule.get("market", "US")),
                                   config.get("max_quote_age_seconds", 1200))
                except ValueError as exc:
                    fresh.remove(symbol)
                    errors += 1
                    LOG.warning("%s delivery deferred: %s", symbol, exc)
        items = [(r, observations[r["symbol"]]) for r in rules
                 if r["symbol"] in fresh and observations[r["symbol"]]["pending"] and
                 channel not in observations[r["symbol"]]["pending"]["ack"]]
        if not items:
            continue
        title, body = alert_text(items, config)
        if dry_run:
            LOG.info("DRY RUN would deliver to %s:\n%s\n%s", channel, title, body)
            continue
        try:
            if sender is None:
                raise ValueError("No alert sender configured")
            sender(channel, title, body)
        except Exception as exc:
            # SMTP error strings may contain server diagnostics; do not log credentials.
            LOG.error("Delivery failed for %s (%s); pending until a fresh in-zone quote is available",
                      channel, type(exc).__name__)
            errors += 1
        else:
            for _, entry in items:
                entry["pending"]["ack"].append(channel)
                if set(channels) <= set(entry["pending"]["ack"]):
                    entry["pending"] = None
            persist(state)
            LOG.info("Delivery accepted for %s: %s", channel, title)
    state["last_run"]["errors"] = errors
    state.setdefault("last_runs", {})[expected_phase] = {
        **copy.deepcopy(state["last_run"]), "checked_at": now.isoformat()}
    if not dry_run:
        persist(state)
    return 1 if errors else 0


def setup_logging(home=None):
    LOG.setLevel(logging.INFO)
    LOG.handlers.clear()
    formatter = logging.Formatter("%(asctime)sZ %(levelname)s %(message)s")
    formatter.converter = time.gmtime
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    LOG.addHandler(console)
    if home:
        handler = RotatingFileHandler(home / "monitor.log", maxBytes=2_000_000, backupCount=3)
        handler.setFormatter(formatter)
        LOG.addHandler(handler)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true", help="Fetch and preview; no writes or deliveries")
    modes.add_argument("--status", action="store_true", help="Show saved status, no network or writes")
    modes.add_argument("--technical-report", action="store_true", help="Read-only daily technical report; no emails, cache or state writes")
    parser.add_argument("--symbols", help="Comma-separated configured tickers for --technical-report")
    modes.add_argument("--configure-email", action="store_true", help="Locally prompt and verify SMTP login; no email sent")
    parser.add_argument("--check-now", action="store_true", help="With --dry-run only: fetch even outside market hours")
    args = parser.parse_args(argv)
    if args.check_now and not args.dry_run:
        parser.error("--check-now is diagnostic only and requires --dry-run")
    if args.symbols and not args.technical_report:
        parser.error("--symbols requires --technical-report")
    setup_logging()
    try:
        config = load_config(args.config)
        home = runtime_home()
        if args.configure_email:
            configure_email(config, home)
            return 0
        if args.status:
            state = load_state(home / "state.json")
            print(json.dumps({"runtime_directory": str(home),
                              "email_secret_present": (home / "email-secret.json").exists(),
                              "channels": channel_names(config), "state": state}, indent=2))
            return 0
        evaluator = None
        if config.get("technical_analysis", {}).get("enabled", False) or args.technical_report:
            from technical_data import DailyHistoryService
            evaluator = DailyHistoryService(home / "daily-history", config,
                                            read_only=args.dry_run or args.technical_report)
        if args.technical_report:
            wanted = set(args.symbols.upper().split(",")) if args.symbols else None
            available = {rule["symbol"] for rule in config["watchlist"]}
            if wanted and wanted - available:
                raise ValueError("Unknown configured symbols: " + ", ".join(sorted(wanted - available)))
            now = datetime.now(UTC)
            rules = [r for r in config["watchlist"] if not wanted or r["symbol"] in wanted]
            with ThreadPoolExecutor(max_workers=4) as pool:
                rows = list(pool.map(lambda r: {"symbol": r["symbol"], **evaluator(r, {}, now)}, rules))
            print(json.dumps({"checked_at": now.isoformat(), "read_only": True,
                              "live_quote_checked": False, "rows": rows}, indent=2, allow_nan=False))
            return 1 if any(row["status"] == "UNAVAILABLE" for row in rows) else 0
        signal_service = None
        from buy_sell_signals import (BuySellSignalService, run_alert_cycle,
                                      signal_market_due, signal_settings)
        signal_options = signal_settings(config)
        signal_delivery_enabled = (signal_options["enabled"] and signal_options["immediate_email"]
                                   and config["alerts"]["email"]["enabled"])
        if signal_delivery_enabled:
            signal_service = BuySellSignalService(
                home / "buy-sell-signals", config, read_only=args.dry_run,
                daily_service=evaluator if hasattr(evaluator, "get_history") else None)
        investment_evaluator = None
        if config.get("investment_analysis", {}).get("enabled"):
            from investment_checks import InvestmentService
            investment_evaluator = InvestmentService(config, home, read_only=args.dry_run)
        now = datetime.now(UTC)
        markets = sorted({r.get("market", "US") for r in config["watchlist"] if r.get("enabled", True)})
        session = {market: market_session(now, market) for market in markets}
        extended = extended_market_session(now) if config.get("extended_hours", False) and "US" in markets else None
        signal_markets = ({market for market in markets if session[market] or signal_market_due(now, market)}
                  if signal_service else set())
        if not any(session.values()) and not extended and not signal_markets and not args.check_now:
            LOG.info("Outside eligible trading hours for %s (exchange holidays and breaks skipped)", ", ".join(markets))
            return 0
        if args.dry_run:
            state = load_state(home / "state.json")
            result = 0
            if any(session.values()) or args.check_now:
                result |= run_cycle(config, state, now, session, dry_run=True,
                                    clock=lambda: datetime.now(UTC), check_closed=args.check_now,
                                    technical_evaluator=evaluator, investment_evaluator=investment_evaluator)
            if signal_service and signal_markets:
                active_rules = [rule for rule in config["watchlist"]
                                if rule.get("market", "US") in signal_markets]
                result |= run_alert_cycle(
                    config, active_rules, now, signal_service,
                    home / "buy-sell-signals" / "state.json",
                    lambda channel, title, body: None, dry_run=True)
            if extended:
                result |= run_cycle(config, state, now, {"US": extended}, dry_run=True,
                                    fetcher=lambda symbol: fetch_extended_quote(symbol, extended),
                                    clock=lambda: datetime.now(UTC), state_key=f"{extended['phase']}_symbols",
                                    technical_evaluator=evaluator, investment_evaluator=investment_evaluator)
            return result
        home.mkdir(parents=True, exist_ok=True, mode=0o700)
        setup_logging(home)
        with (home / "monitor.lock").open("a") as lock:
            try:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                LOG.info("Another monitor invocation is still running; skipping")
                return 0
            state = load_state(home / "state.json")
            result = 0
            options = {"sender": lambda channel, title, body: send_channel(channel, title, body, config, home),
                       "persist": lambda value: atomic_json(home / "state.json", value),
                       "clock": lambda: datetime.now(UTC), "technical_evaluator": evaluator,
                       "investment_evaluator": investment_evaluator}
            if any(session.values()):
                result |= run_cycle(config, state, now, session, **options)
            if signal_service and signal_markets:
                active_rules = [rule for rule in config["watchlist"]
                                if rule.get("market", "US") in signal_markets]
                result |= run_alert_cycle(
                    config, active_rules, datetime.now(UTC), signal_service,
                    home / "buy-sell-signals" / "state.json", options["sender"])
            if extended:
                result |= run_cycle(config, state, now, {"US": extended},
                                    fetcher=lambda symbol: fetch_extended_quote(symbol, extended),
                                    state_key=f"{extended['phase']}_symbols", **options)
            # The regular closing check can overlap the first post-market check.
            # Preserve both results and make the existing top-level summary truthful.
            summaries = {phase: summary for phase, summary in state.get("last_runs", {}).items()
                         if summary.get("checked_at") == now.isoformat()}
            if summaries:
                state["last_run"] = {"slot": ",".join(s["slot"] for s in summaries.values()),
                                     **{key: sum(s[key] for s in summaries.values())
                                        for key in ("requested", "fresh", "errors")}}
                state["last_run_at"] = now.isoformat()
                options["persist"](state)
            return result
    except Exception as exc:
        # Configuration errors are local data; SMTP password/server payloads are never printed.
        if isinstance(exc, (smtplib.SMTPException, subprocess.SubprocessError)):
            LOG.error("Monitor failed: %s", type(exc).__name__)
        else:
            LOG.error("Monitor failed: %s", str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
