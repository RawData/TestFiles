# Investment Monitor

A local, read-only Python monitor for US and Hong Kong price conditions,
completed-daily technical checks, public fundamentals and NAV evidence,
portfolio exposure, and optional local-model news summaries.

The project never places orders and does not treat a price alert, technical
grade, or model summary as investment approval. Market and model data can be
missing, stale, delayed, or wrong.

## Requirements

- Python 3.10 or later
- macOS for LaunchAgent scheduling and Notification Center delivery
- Internet access for configured public data providers
- Optional local Ollama service for news analysis and code-review assistance

## Setup

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
cp config.example.json config.json
chmod 600 config.json
```

Edit `config.json` before running the monitor. The committed examples are
disabled and contain no production thresholds, recipients, holdings, or API
credentials.

```bash
.venv/bin/python monitor.py --dry-run
.venv/bin/python monitor.py --dry-run --check-now
.venv/bin/python monitor.py --status
```

For local macOS scheduling, open `Install.command` after reviewing the private
configuration. Email credentials are prompted for locally and stored outside
the repository with owner-only permissions.

## Optional Inputs

Copy and edit the example files only when enabling their corresponding feature:

```bash
cp portfolio-input.example.json portfolio-input.json
cp investment-policies.example.json investment-policies.json
cp news-sources.example.json news-sources.json
```

To enable investment analysis, set `investment_analysis.enabled` to `true` and
add `policies_file` and `portfolio_file` fields pointing to those two private
copies. Policy instrument keys must cover every configured watchlist symbol.
Keep holdings, thresholds, policy decisions, reports, and evidence snapshots out
of Git.

## Buy/Sell Candle Signals

`buy_sell_signals.py` implements the configured two-candle breakout and
confirmation signal independently of the existing saved-zone and technical
grades. It evaluates completed regular-session 15-minute, exchange-aligned
hourly, and daily candles. Forming candles and extended-hours candles are not
used. The optional higher-timeframe gate maps 15m to 1h, 1h to 1d, and 1d to a
completed exchange week.

When `buy_sell_signals.enabled` is true, the daily watchlist includes each
timeframe's `BUY`, `SELL`, `PENDING_BUY`, `PENDING_SELL`, `NONE`, or
`UNAVAILABLE` result. With `immediate_email` also true, the existing five-minute
monitor sends a separate email for each newly confirmed signal. The first run
records a baseline without replaying historical signals. Event state and candle
caches are stored under the runtime directory in `buy-sell-signals/`; delivery
is tracked independently for each configured recipient. A bounded 45-minute
post-segment window catches the final intraday candle and newly published daily
bar without polling overnight.

These labels reproduce mechanical chart conditions. They are not orders,
profit forecasts, or investment recommendations. Yahoo Finance data is
unofficial and may be delayed.

## Tests

The suite is offline and uses synthetic provider responses:

```bash
.venv/bin/python -m unittest discover -s tests -q
.venv/bin/python -m compileall -q .
```

Optional linting:

```bash
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/ruff check .
```

## Local Model Review

`validate_local_review.py` sends only allowlisted source/test bundles to a
loopback Ollama endpoint. It rejects common private-data patterns and validates
structured output. Model findings are advisory and must be reproduced with
tests or direct source evidence.

```bash
.venv/bin/python validate_local_review.py --scope core --dry-run
.venv/bin/python validate_local_review.py --scope core --timeout 900
```

## GitHub

GitHub Actions runs the offline unit tests, compilation checks, and focused Ruff
rules. CodeQL and Dependabot configuration are included. Before pushing, review
`git status` and run the privacy check documented in [SECURITY.md](SECURITY.md).

After creating an empty GitHub repository:

```bash
git commit -m "Initial import"
git remote add origin https://github.com/OWNER/Investment-monitor.git
git push -u origin main
```

No license is granted by default. Add a license before making the repository
public if reuse or redistribution is intended.