"""Deterministic, deliberately partial company fundamentals from public SEC data.

Annual US-GAAP facts are matched by accession, unit and exact fiscal period.
Quarterly/YTD figures are never treated as annual figures. This module reports
annual health evidence and notices newer filings; it does not read guidance,
value a business, or approve a purchase. Financial companies and funds need
different models. No AI service, subscription, broker access, or email is used.
"""

from datetime import date, datetime, timedelta
import json
import math
import os
from pathlib import Path
import re
import threading
import time
import urllib.error
import urllib.request

from technical_data import _atomic_json, _utc

SOURCE = "SEC EDGAR Company Facts and Submissions"
DOCS = "https://www.sec.gov/search-filings/edgar-application-programming-interfaces"
TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
CACHE_VERSION = 1
MAX_BYTES = 25_000_000
_HTTP_LOCK = threading.Lock()
_LAST_REQUEST = 0.0
_TAGS = {
    "revenue": ("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet", "RevenueFromContractWithCustomerIncludingAssessedTax"),
    "net_income": ("NetIncomeLoss", "ProfitLoss"),
    "operating_cash_flow": ("NetCashProvidedByUsedInOperatingActivities",),
    "capital_expenditure": ("PaymentsToAcquirePropertyPlantAndEquipment",),
    "cash": ("CashAndCashEquivalentsAtCarryingValue",),
    "equity": ("StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"),
    "assets": ("Assets",),
    "liabilities": ("Liabilities",),
}
_INSTANT = {"cash", "equity", "assets", "liabilities"}
_UNVERIFIED = ["Current guidance, earnings-call commentary and customer retention are not parsed.",
               "Annual evidence is not a valuation, investment recommendation, or full fundamental clearance.",
               "New filings may arrive after the daily refresh; custom XBRL tags and unreported facts remain unavailable."]


def fetch_sec_json(url, *, contact=None):
    """At most two SEC requests/second in this process; public API, no key."""
    global _LAST_REQUEST
    if not (url == TICKERS_URL or re.fullmatch(r"https://data\.sec\.gov/(submissions|api/xbrl/companyfacts)/CIK\d{10}\.json", url)):
        raise ValueError("Unapproved SEC endpoint")
    agent = "LocalInvestmentWatchlist/1.0 personal financial research"
    contact = contact or os.environ.get("SEC_CONTACT")
    if contact:
        if not isinstance(contact, str) or len(contact) > 160 or any(c in contact for c in "\r\n"):
            raise ValueError("Invalid SEC contact")
        agent += " " + contact
    with _HTTP_LOCK:
        delay = .5 - (time.monotonic() - _LAST_REQUEST)
        if delay > 0:
            time.sleep(delay)
        _LAST_REQUEST = time.monotonic()
    request = urllib.request.Request(url, headers={"User-Agent": agent, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise ValueError("SEC response exceeds size limit")
        return json.loads(raw)
    except urllib.error.HTTPError as exc:
        raise ValueError(f"SEC HTTP {exc.code}; no alternate issuer or unofficial financial facts substituted") from exc
    except (urllib.error.URLError, TimeoutError) as exc:
        raise ValueError("SEC unavailable or timed out") from exc


def _base(symbol, now, status, reasons):
    return {"schema_version": 1, "symbol": symbol, "status": status, "complete": False,
            "scope": "Annual SEC US-GAAP health evidence; latest filing inventory checked",
            "as_of": None, "filed_at": None, "fetched_at": None, "checked_at": now.isoformat(),
            "source": SOURCE, "sources": [], "metrics": {}, "facts": {}, "reasons": reasons,
            "unverified": list(_UNVERIFIED)}


def _day(value):
    return date.fromisoformat(value)


def _filings(submissions, now):
    recent = submissions["filings"]["recent"]
    fields = ("form", "filingDate", "reportDate", "accessionNumber", "primaryDocument")
    length = len(recent["form"])
    if any(not isinstance(recent.get(k), list) or len(recent[k]) != length for k in fields):
        raise ValueError("SEC filing arrays are inconsistent")
    records = []
    for i in range(length):
        form = recent["form"][i]
        if form not in {"10-K", "10-K/A", "10-Q", "10-Q/A", "20-F", "20-F/A", "40-F", "40-F/A"}:
            continue
        filed = _day(recent["filingDate"][i])
        report = _day(recent["reportDate"][i])
        if filed > now.date() or report > filed:
            continue
        accession = recent["accessionNumber"][i]
        if not re.fullmatch(r"\d{10}-\d{2}-\d{6}", accession):
            raise ValueError("Invalid SEC accession")
        records.append({k: recent[k][i] for k in fields})
    return sorted(records, key=lambda r: (r["filingDate"], r["accessionNumber"]), reverse=True)


def _number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("Non-finite SEC monetary fact")
    return float(value)


def _candidates(gaap, metric, accession, now, *, end, start=None, instant=False, tag=None,
                forms=("10-K", "10-K/A", "20-F", "20-F/A"), min_days=330, max_days=400):
    """Reject inconsistent duplicate contexts instead of guessing an XBRL scope."""
    for concept in ((tag,) if tag else _TAGS[metric]):
        usable = []
        for fact in gaap.get(concept, {}).get("units", {}).get("USD", []):
            if fact.get("accn") != accession or fact.get("end") != end or fact.get("form") not in forms:
                continue
            try:
                if _day(fact["filed"]) > now.date() or _day(fact["end"]) > _day(fact["filed"]):
                    continue
                if instant:
                    if fact.get("start"):
                        continue
                else:
                    beginning = _day(fact["start"])
                    duration = (_day(end) - beginning).days + 1
                    if not min_days <= duration <= max_days or (start and fact["start"] != start):
                        continue
                value = _number(fact["val"])
                usable.append({"value": value, "start": fact.get("start"), "end": end,
                               "filed_at": fact["filed"], "accession": accession, "tag": concept, "unit": "USD"})
            except (KeyError, ValueError, TypeError):
                continue
        if usable:
            # More than one annual start or value cannot safely be collapsed.
            if len({(x["start"], x["value"]) for x in usable}) != 1:
                return None
            return max(usable, key=lambda x: x["filed_at"])
    return None


def _policy(rule):
    p = rule.get("fundamental_policy", {})
    if not isinstance(p, dict):
        raise ValueError("fundamental_policy must be an object")
    allowed = {"mode", "cik", "max_annual_age_days", "max_quarter_age_days", "fail_negative_equity", "fail_negative_cfo", "fail_negative_net_income", "min_revenue_growth_pct"}
    if set(p) - allowed:
        raise ValueError("Unknown fundamental policy key")
    mode = p.get("mode", "company")
    if mode not in {"company", "fund", "financial", "unsupported"}:
        raise ValueError("Unknown fundamental mode")
    for key in ("fail_negative_equity", "fail_negative_cfo", "fail_negative_net_income"):
        if key in p and not isinstance(p[key], bool):
            raise ValueError("Fundamental failure switches must be boolean")
    if "min_revenue_growth_pct" in p and p["min_revenue_growth_pct"] is not None:
        value = _number(p["min_revenue_growth_pct"])
        if not -100 <= value <= 1000:
            raise ValueError("Invalid revenue-growth threshold")
    age = p.get("max_annual_age_days", 550)
    if isinstance(age, bool) or not isinstance(age, int) or not 365 <= age <= 730:
        raise ValueError("Annual age limit must be 365 to 730 days")
    quarter_age = p.get("max_quarter_age_days", 210)
    if isinstance(quarter_age, bool) or not isinstance(quarter_age, int) or not 90 <= quarter_age <= 365:
        raise ValueError("Quarterly age limit must be 90 to 365 days")
    return p


def _latest_ytd(gaap, annual, annual_start, latest, policy, now):
    """Use fiscal YTD exactly; never infer quarter values by subtracting YTDs."""
    result = {"status": "UNAVAILABLE", "complete": False,
              "scope": "Latest 10-Q fiscal year-to-date amounts, not standalone quarter or TTM",
              "as_of": latest["reportDate"], "filed_at": latest["filingDate"],
              "form": latest["form"], "metrics": {}, "facts": {}, "reasons": []}
    if latest["form"] != "10-Q":
        result["reasons"] = ["Latest financial filing is not an unamended 10-Q; no quarterly/YTD assumptions made."]
        return result
    start = (_day(annual["reportDate"]) + timedelta(days=1)).isoformat()
    end = latest["reportDate"]
    days = (_day(end) - _day(start)).days + 1
    if not 60 <= days <= 310:
        result["reasons"] = ["Latest 10-Q does not fit the fiscal YTD following the supported annual period."]
        return result
    result.update(period_start=start, period_days=days, age_days=(now.date() - _day(end)).days,
                  accession=latest["accessionNumber"])
    metrics, facts = result["metrics"], result["facts"]
    for metric in _TAGS:
        fact = _candidates(gaap, metric, latest["accessionNumber"], now, end=end, start=start,
                           instant=metric in _INSTANT, forms=("10-Q",), min_days=60, max_days=310)
        if fact:
            metrics[metric] = fact["value"]
            facts[metric] = fact
    if "revenue" in facts:
        tag = facts["revenue"]["tag"]
        prior_ends = set()
        for fact in gaap.get(tag, {}).get("units", {}).get("USD", []):
            if fact.get("start") == annual_start and fact.get("accn") == latest["accessionNumber"] and fact.get("form") == "10-Q":
                try:
                    prior_days = (_day(fact["end"]) - _day(annual_start)).days + 1
                    if 60 <= prior_days <= 310 and abs(prior_days - days) <= 7:
                        prior_ends.add(fact["end"])
                except (KeyError, TypeError, ValueError):
                    continue
        if len(prior_ends) == 1:
            prior = _candidates(gaap, "revenue", latest["accessionNumber"], now, end=prior_ends.pop(),
                                start=annual_start, tag=tag, forms=("10-Q",), min_days=60, max_days=310)
            if prior and prior["value"] > 0:
                metrics["previous_revenue"] = prior["value"]
                facts["previous_revenue"] = prior
                metrics["revenue_growth_pct"] = (metrics["revenue"] / prior["value"] - 1) * 100
    if metrics.get("capital_expenditure", -1) >= 0 and "operating_cash_flow" in metrics:
        metrics["ppe_free_cash_flow_proxy"] = metrics["operating_cash_flow"] - metrics["capital_expenditure"]
        result["free_cash_flow_basis"] = "Operating cash flow minus PP&E payments only; separately capitalized software/intangibles and other investments are not deducted. Not issuer-defined FCF."
    if metrics.get("revenue", 0) > 0 and "net_income" in metrics:
        metrics["net_margin_pct"] = metrics["net_income"] / metrics["revenue"] * 100
    result["missing_metrics"] = [key for key in ("revenue", "net_income", "operating_cash_flow", "capital_expenditure", "cash", "equity") if key not in metrics]
    for key in ("net_income", "operating_cash_flow", "ppe_free_cash_flow_proxy", "equity"):
        if key in metrics and metrics[key] < 0:
            result["reasons"].append(f"Latest YTD {key.replace('_', ' ')} is negative.")
    if metrics.get("revenue_growth_pct", 0) < 0:
        result["reasons"].append("Latest fiscal YTD revenue declined against the same fiscal-duration prior period.")
    if not any(key in metrics for key in ("revenue", "net_income", "operating_cash_flow")):
        result["reasons"].append("No comparable fiscal YTD income/cash-flow fact; instant balance-sheet values alone do not clear fundamentals.")
    elif result["age_days"] > policy.get("max_quarter_age_days", 210):
        result["reasons"].append("Latest quarterly evidence exceeds the configured freshness limit.")
    else:
        result["status"] = "REVIEW"
        result["reasons"].append("Reported fiscal YTD facts checked; guidance, valuation and unparsed disclosures remain unverified.")
    return result


def analyze_fundamentals(rule, submissions, companyfacts, now):
    """Pure, date-bounded fiscal extraction; partial evidence never implies PASS."""
    now = _utc(now)
    symbol = rule["symbol"].upper()
    policy = _policy(rule)
    result = _base(symbol, now, "REVIEW", [])
    cik = int(submissions["cik"])
    if int(companyfacts["cik"]) != cik:
        raise ValueError("SEC submissions and Company Facts identify different issuers")
    if symbol not in {str(s).upper() for s in submissions.get("tickers", [])}:
        raise ValueError("SEC issuer does not list the configured ticker")
    result.update({"cik": str(cik).zfill(10), "entity_name": submissions.get("name"),
                   "sources": [f"https://data.sec.gov/submissions/CIK{cik:010d}.json", f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json"]})
    filings = _filings(submissions, now)
    if not filings:
        result.update(status="UNAVAILABLE", reasons=["No usable financial filing in the recent SEC filing inventory."])
        return result
    latest = filings[0]
    result["latest_financial_filing"] = latest
    sic = str(submissions.get("sic", ""))
    if policy.get("mode") == "financial" or (sic.isdigit() and 6000 <= int(sic) <= 6999):
        result.update(status="REVIEW", scope="Financial-company filing inventory only", reasons=["Financial company: industrial cash-flow and leverage tests do not apply. NAV, credit quality, investment income and distribution coverage require a specialist model."], as_of=latest["reportDate"], filed_at=latest["filingDate"])
        result["source"] = "SEC EDGAR Submissions"
        result["sources"] = result["sources"][:1]
        return result
    annual = next((f for f in filings if f["form"] in {"10-K", "20-F"}), None)
    if not annual or not companyfacts.get("facts", {}).get("us-gaap"):
        result.update(status="UNAVAILABLE", reasons=["No supported US-GAAP annual 10-K/20-F facts; IFRS/custom-tag accounts are not substituted."], as_of=latest["reportDate"], filed_at=latest["filingDate"])
        return result
    result.update(as_of=annual["reportDate"], filed_at=annual["filingDate"], annual_filing=annual,
                  newer_financial_filing=latest["accessionNumber"] != annual["accessionNumber"])
    if annual["form"] == "20-F":
        result["unverified"].append("Foreign-issuer 6-K interim results are not parsed; these US-GAAP annual figures do not verify current interim performance.")
    gaap = companyfacts["facts"]["us-gaap"]
    anchor = None
    for metric in ("revenue", "net_income", "operating_cash_flow"):
        anchor = _candidates(gaap, metric, annual["accessionNumber"], now, end=annual["reportDate"], forms=(annual["form"],))
        if anchor:
            break
    if not anchor:
        result.update(status="UNAVAILABLE", reasons=["No unambiguous annual fiscal-period anchor in the latest 10-K."])
        return result
    metrics, facts = result["metrics"], result["facts"]
    result["period_start"] = anchor["start"]
    result["period_days"] = (_day(anchor["end"]) - _day(anchor["start"])).days + 1
    for metric in _TAGS:
        fact = _candidates(gaap, metric, annual["accessionNumber"], now, end=annual["reportDate"], start=anchor["start"], instant=metric in _INSTANT, forms=(annual["form"],))
        if fact:
            metrics[metric] = fact["value"]
            facts[metric] = fact
    # Prior-year revenue must be comparative evidence from the same filing,
    # same tag/currency, consecutive fiscal years, and near-identical length.
    if "revenue" in facts:
        current = facts["revenue"]
        prior_end = (_day(anchor["start"]) - timedelta(days=1)).isoformat()
        prior = _candidates(gaap, "revenue", annual["accessionNumber"], now, end=prior_end, tag=current["tag"], forms=(annual["form"],))
        if prior and abs(((_day(prior["end"]) - _day(prior["start"])).days + 1) - result["period_days"]) <= 7 and prior["value"] > 0:
            facts["previous_revenue"] = prior
            metrics["previous_revenue"] = prior["value"]
            metrics["revenue_growth_pct"] = (current["value"] / prior["value"] - 1) * 100
    if "capital_expenditure" in metrics and metrics["capital_expenditure"] < 0:
        result["reasons"].append("Negative capex payment fact is ambiguous; free cash flow was not calculated.")
    elif "capital_expenditure" in metrics and "operating_cash_flow" in metrics:
        metrics["ppe_free_cash_flow_proxy"] = metrics["operating_cash_flow"] - metrics["capital_expenditure"]
        result["free_cash_flow_basis"] = "Operating cash flow minus PP&E payments only; separately capitalized software/intangibles and other investments are not deducted. Not issuer-defined FCF."
    if metrics.get("revenue", 0) > 0 and "net_income" in metrics:
        metrics["net_margin_pct"] = metrics["net_income"] / metrics["revenue"] * 100
    missing = [k for k in ("revenue", "net_income", "operating_cash_flow", "capital_expenditure", "cash", "equity") if k not in metrics]
    result["missing_metrics"] = missing
    if missing:
        result["reasons"].append("Missing comparable annual facts: " + ", ".join(missing) + ".")
    for key, label in (("net_income", "Net income"), ("operating_cash_flow", "Operating cash flow"), ("ppe_free_cash_flow_proxy", "PP&E free cash flow proxy"), ("equity", "Book equity")):
        if key in metrics and metrics[key] < 0:
            result["reasons"].append(f"Annual {label.lower()} is negative; this is a health flag, not a valuation conclusion.")
    if metrics.get("revenue_growth_pct", 0) < 0:
        result["reasons"].append("Revenue declined versus the comparable prior annual period.")
    if result["newer_financial_filing"]:
        result["current_period"] = _latest_ytd(gaap, annual, anchor["start"], latest, policy, now)
        result["reasons"].append(f"Newer {latest['form']} filed {latest['filingDate']} for {latest['reportDate']}; separate current-period evidence is {result['current_period']['status']}. Annual metrics retain their own fiscal dates.")
    result["annual_age_days"] = (now.date() - _day(result["as_of"])).days
    stale = result["annual_age_days"] > policy.get("max_annual_age_days", 550)
    if stale:
        result["reasons"].append("Annual financial evidence exceeds the configured freshness limit.")
        result["status"] = "UNAVAILABLE"
    else:
        failures = []
        for switch, metric in (("fail_negative_equity", "equity"), ("fail_negative_cfo", "operating_cash_flow"), ("fail_negative_net_income", "net_income")):
            if policy.get(switch) and metric in metrics and metrics[metric] < 0:
                failures.append(f"Configured {switch} condition failed.")
        threshold = policy.get("min_revenue_growth_pct")
        if threshold is not None and "revenue_growth_pct" in metrics and metrics["revenue_growth_pct"] < threshold:
            failures.append(f"Revenue growth is below configured minimum {threshold:g}%.")
        if failures:
            result["status"] = "FAIL"
            result["reasons"].extend(failures)
    result["reasons"].append("Annual checks are partial; current fundamentals remain REVIEW even when no configured health flag fails.")
    return result


class FundamentalsService:
    """Daily success cache and 15-minute failure backoff; no AI calls."""

    def __init__(self, cache_dir, *, read_only=False, fetcher=None, contact=None):
        self.cache_dir = Path(cache_dir)
        self.read_only = read_only
        self.fetcher = fetcher or (lambda url: fetch_sec_json(url, contact=contact))
        self._memory = {}
        self._lock = threading.RLock()
        self._key_locks = {}

    def _get(self, key, url, now):
        with self._lock:
            lock = self._key_locks.setdefault(key, threading.Lock())
        # Prevent competing downloads of a shared map or a single issuer, while
        # unrelated issuers can load in parallel within the global rate limit.
        with lock:
            path = self.cache_dir / (key + ".json")
            entry = self._memory.get(key)
            if entry is None:
                try:
                    entry = json.loads(path.read_text())
                except (OSError, ValueError):
                    entry = {}
            try:
                stamp = _utc(datetime.fromisoformat(entry["fetched_at"]))
                valid = entry.get("version") == CACHE_VERSION and entry.get("url") == url and stamp <= now and stamp.date() == now.date()
                if entry.get("error") and (now - stamp).total_seconds() >= 900:
                    valid = False
            except (KeyError, ValueError, TypeError):
                valid = False
            if not valid:
                entry = {"version": CACHE_VERSION, "url": url, "fetched_at": now.isoformat()}
                try:
                    entry["payload"] = self.fetcher(url)
                except Exception as exc:
                    entry["error"] = str(exc)[:180]
                self._memory[key] = entry
                if not self.read_only:
                    _atomic_json(path, entry)
            if entry.get("error"):
                raise ValueError(entry["error"] + "; automatic retry after 15 minutes")
            return entry["payload"], entry["fetched_at"]

    def evaluate(self, rule, quote_dict, now):
        now = _utc(now)
        symbol = str(rule["symbol"]).upper()
        result = _base(symbol, now, "UNAVAILABLE", [])
        try:
            if not re.fullmatch(r"[A-Z0-9][A-Z0-9.\-]{0,19}", symbol):
                raise ValueError("Invalid fundamental symbol")
            policy = _policy(rule)
            mode = policy.get("mode", "company")
            if mode == "fund":
                result.update(status="NOT_APPLICABLE", scope="Fund: issuer-company accounting model does not apply", reasons=["Use fund NAV, distributions, holdings and costs; company revenue/cash-flow checks do not assess a fund."])
                return result
            if mode == "unsupported" or rule.get("market") == "HK" or symbol.endswith(".HK"):
                result["reasons"] = ["This issuer/accounting market is not covered by the SEC US-GAAP annual model."]
                return result
            cik = policy.get("cik")
            if cik is None:
                mapping, _ = self._get("ticker-map", TICKERS_URL, now)
                matches = {int(v["cik_str"]) for v in mapping.values() if isinstance(v, dict) and str(v.get("ticker", "")).upper() == symbol}
                if len(matches) != 1:
                    raise ValueError("No unique SEC ticker-to-CIK match; issuer identity remains unverified")
                cik = matches.pop()
            if isinstance(cik, bool) or not re.fullmatch(r"\d{1,10}", str(cik)) or int(cik) <= 0:
                raise ValueError("Invalid configured SEC CIK")
            cik = int(cik)
            submissions, sub_stamp = self._get(f"submissions-{cik:010d}", f"https://data.sec.gov/submissions/CIK{cik:010d}.json", now)
            if int(submissions.get("cik", 0)) != cik:
                raise ValueError("SEC response does not match the requested CIK")
            sic = str(submissions.get("sic", ""))
            if mode == "financial" or (sic.isdigit() and 6000 <= int(sic) <= 6999):
                # No company-facts request is needed for a model we do not run.
                result = analyze_fundamentals(rule, submissions, {"cik": cik}, now)
                result["fetched_at"] = sub_stamp
                result["source_fetch_times"] = {"submissions": sub_stamp}
                result["refresh_policy"] = "Once per UTC date; failures retry after 15 minutes; financial-company filing inventory only"
                return result
            facts, fact_stamp = self._get(f"facts-{cik:010d}", f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json", now)
            result = analyze_fundamentals(rule, submissions, facts, now)
            result["fetched_at"] = min(sub_stamp, fact_stamp)
            result["source_fetch_times"] = {"submissions": sub_stamp, "companyfacts": fact_stamp}
            result["refresh_policy"] = "Once per UTC date; failures retry after 15 minutes; no real-time guidance parsing"
            return result
        except Exception as exc:
            result.update(status="UNAVAILABLE", reasons=["Fundamental evidence unavailable: " + str(exc)[:220]])
            return result
