"""Dated issuer NAV checks. No AI calls and no purchase recommendation.

Reuse the monitor's exchange calendar, completed-session calculation, and atomic
JSON writer. NAV is not a technical OHLC series: do not reuse Yahoo navPrice or
infer NAV from a fund's price. A fresh trade against yesterday's NAV is labelled
indicative and cannot pass a current premium/discount condition.
"""
from datetime import date, datetime, timedelta
from html import unescape
from html.parser import HTMLParser
import json
import math
from pathlib import Path
import re
import threading
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

from technical_data import _atomic_json, _calendar, _sessions, _utc, expected_completed_session
from market_clock import MARKETS

CACHE_VERSION = 1
MAX_BYTES = 3_000_000
# Security identity and currency belong to the specific listed class, not its
# related funds or similarly named unlisted class. All URLs are public issuers.
SOURCES = {
    "3419.HK": {"parser": "globalx", "currency": "HKD", "identity": "HK0000978962", "url": "https://www.globalxetfs.com.hk/funds/covered-call-etf/"},
    "RMT": {"parser": "royce", "currency": "USD", "identity": "780915104", "url": "https://www.royceinvest.com/funds/royce-micro-cap-trust/rmt"},
    "BMEZ": {"parser": "blackrock", "currency": "USD", "identity": "09260E105", "url": "https://www.blackrock.com/us/individual/products/312196/blackrock-health-sciences-trust-ii-class/"},
    "SGOV": {"parser": "blackrock", "currency": "USD", "identity": "46436E718", "url": "https://www.ishares.com/us/products/314116/ishares-0-3-month-treasury-bond-etf"},
    "SHY": {"parser": "blackrock", "currency": "USD", "identity": "464287457", "url": "https://www.ishares.com/us/products/239452/ishares-13-year-treasury-bond-etf"},
}


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.ignore = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.ignore += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.ignore = max(0, self.ignore - 1)

    def handle_data(self, data):
        if not self.ignore:
            self.parts.append(data)


def _text(raw):
    parser = _Text()
    parser.feed(raw)
    return " ".join(" ".join(parser.parts).split())


def _positive(value):
    if isinstance(value, bool):
        raise ValueError("NAV/price must be positive and finite")
    number = float(str(value).replace(",", "").replace("$", "").strip())
    if not math.isfinite(number) or number <= 0:
        raise ValueError("NAV/price must be positive and finite")
    return number


def _date(value):
    value = re.sub(r"^as of\s*", "", value.strip(), flags=re.I)
    for fmt in ("%Y-%m-%d", "%b %d, %Y", "%d %b %Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    raise ValueError("Issuer NAV date missing or unrecognised")


def _element(raw, attr, value):
    match = re.search(r"<([a-z0-9]+)\b[^>]*\b" + re.escape(attr) + r"\s*=\s*['\"]" + re.escape(value) + r"['\"][^>]*>(.*?)</\1>", raw, re.I | re.S)
    if not match:
        raise ValueError("Required issuer NAV field missing: " + value)
    return _text(match.group(2))


def parse_nav_page(symbol, raw):
    """Parse only observed, dated official fields; reject identity ambiguity."""
    spec = SOURCES[symbol]
    text = _text(raw)
    if spec["identity"] not in text:
        raise ValueError("Issuer page security identity mismatch or missing")
    if spec["parser"] == "globalx":
        if not re.search(r'data-ticker-hkd\s*=\s*[\'\"]3419[\'\"]', raw):
            raise ValueError("Global X listed ticker mismatch")
        day = _date(_element(raw, "data-zrcheck", "daily-nav-asofdate"))
        # The page repeats official-nav for the unlisted R2 class. Select the
        # row by the exact listed-class label rather than the first NAV number.
        rows = re.findall(r"<tr\b[^>]*>(.*?)</tr>", raw, re.I | re.S)
        matches = [row for row in rows if re.search(r"Official NAV per Unit in\s+HKD\s*\(Listed Class\)", _text(row))]
        if len(matches) != 1:
            raise ValueError("Global X listed NAV class missing or ambiguous")
        nav = _positive(_element(matches[0], "data-zrcheck", "official-nav"))
        return {"symbol": symbol, "currency": "HKD", "as_of": day, "nav": nav, "listed_class": spec["identity"]}
    if spec["parser"] == "royce":
        if not re.search(r"Royce Micro-Cap Trust\s*\(RMT\)", unescape(raw)):
            raise ValueError("Royce product ticker mismatch")
        # Quarterly portfolio-diagnostics NAV is a different field/date.
        return {"symbol": symbol, "currency": "USD", "as_of": _date(_element(raw, "id", "LabelRateDateCurrent")),
                "nav": _positive(_element(raw, "id", "ctl02_LabelClosedEndFundNav")),
                "official_close": _positive(_element(raw, "id", "ctl02_LabelClosedEndFundMkt"))}
    if not re.search(r"\b" + re.escape(symbol) + r"\b", text):
        raise ValueError("BlackRock product ticker mismatch")
    # The public BlackRock and iShares pages share a dated NAV summary. The
    # US-listed CUSIP whitelist above fixes USD, rather than guessing from '$'.
    match = re.search(r"\bNAV as of\s+([A-Z][a-z]{2} \d{1,2}, \d{4})\s+\$+\s*([\d,.]+)", text)
    if not match:
        raise ValueError("Dated BlackRock NAV field missing")
    result = {"symbol": symbol, "currency": spec["currency"], "as_of": _date(match[1]), "nav": _positive(match[2])}
    price = re.search(r"Market Price as of\s+([A-Z][a-z]{2} \d{1,2}, \d{4})\s+\$+\s*([\d,.]+)", text)
    if not price:
        price = re.search(r"Closing Price\s+\$+\s*([\d,.]+)\s+as of\s+([A-Z][a-z]{2} \d{1,2}, \d{4})", text)
        if price and _date(price[2]) == result["as_of"]:
            result["official_close"] = _positive(price[1])
    elif _date(price[1]) == result["as_of"]:
        result["official_close"] = _positive(price[2])
    return result


def fetch_nav_page(url):
    request = Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "text/html"})
    with urlopen(request, timeout=12) as response:
        # A changed host/product redirect is not fresh evidence for this class.
        if urlparse(response.geturl()).hostname != urlparse(url).hostname:
            raise ValueError("NAV issuer redirected to a different host")
        raw = response.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError("Issuer NAV page exceeds size limit")
    return raw.decode("utf-8", errors="replace")


class NavService:
    def __init__(self, cache_dir, read_only=False, *, fetcher=None):
        self.cache_dir = Path(cache_dir)
        self.read_only, self.fetcher = read_only, fetcher or fetch_nav_page
        self._memory, self._locks = {}, {}
        self._lock = threading.Lock()

    def _load(self, symbol, now, expected):
        spec = SOURCES[symbol]
        path = self.cache_dir / ("nav-" + symbol + ".json")
        with self._lock:
            lock = self._locks.setdefault(symbol, threading.Lock())
        with lock:
            entry = self._memory.get(symbol)
            if entry is None:
                try:
                    entry = json.loads(path.read_text())
                except (OSError, ValueError):
                    entry = {}
            try:
                elapsed = (now - _utc(datetime.fromisoformat(entry["fetched_at"]))).total_seconds()
                same = entry["version"] == CACHE_VERSION and entry["source"] == spec["url"] and entry["symbol"] == symbol
                ttl = 300 if entry.get("error") or entry.get("data", {}).get("as_of") != expected else 3600
                reuse = same and 0 <= elapsed < ttl
            except (KeyError, TypeError, ValueError, AttributeError):
                reuse = False
            if reuse:
                if entry.get("error"):
                    raise ValueError(entry["error"])
                return entry["data"], entry["fetched_at"]
            entry = {"version": CACHE_VERSION, "symbol": symbol, "source": spec["url"], "fetched_at": now.isoformat()}
            try:
                entry["data"] = parse_nav_page(symbol, self.fetcher(spec["url"]))
            except Exception as exc:
                entry["error"] = "Official NAV source unavailable: " + str(exc)[:180]
            self._memory[symbol] = entry
            if not self.read_only:
                _atomic_json(path, entry)
            if entry.get("error"):
                raise ValueError(entry["error"])
            return entry["data"], entry["fetched_at"]

    def evaluate(self, rule, quote_dict, now):
        result = {"status": "UNAVAILABLE", "reasons": [], "metrics": {}, "as_of": None,
                  "fetched_at": None, "source": None, "sources": [], "complete": False,
                  "scope": "Dated NAV premium/discount condition only; not fundamental health or suitability"}
        try:
            now = _utc(now)
            symbol = rule["symbol"].upper()
            policy = rule.get("nav_policy", {})
            kind = policy.get("kind")
            if kind == "not_applicable":
                result.update(status="NOT_APPLICABLE", complete=True, reasons=["NAV condition does not apply to this security type."])
                return result
            if kind not in ("etf", "cef"):
                raise ValueError("NAV security type is unconfigured")
            if symbol not in SOURCES:
                raise ValueError("No validated free issuer NAV adapter for " + symbol)
            spec = SOURCES[symbol]
            result.update(source=spec["url"], sources=[{"label": "Official issuer NAV", "url": spec["url"]}])
            market = rule.get("market", "HK" if symbol.endswith(".HK") else "US")
            if market not in MARKETS or rule.get("currency", spec["currency"]) != spec["currency"] or MARKETS[market]["currency"] != spec["currency"]:
                raise ValueError("Configured NAV currency or market mismatch")
            lag_limit = policy.get("max_nav_lag_sessions", 0)
            if isinstance(lag_limit, bool) or not isinstance(lag_limit, int) or not 0 <= lag_limit <= 5:
                raise ValueError("NAV lag limit must be 0 to 5 exchange sessions")
            cap = policy.get("max_premium_pct")
            if cap is not None and (isinstance(cap, bool) or not isinstance(cap, (int, float)) or not math.isfinite(cap) or not -100 < cap < 100):
                raise ValueError("Invalid configured maximum NAV premium")
            expected = expected_completed_session(now, market, publish_grace_minutes=120)
            result["metrics"].update(expected_nav_session=expected, max_nav_lag_sessions=lag_limit,
                                     publish_grace_minutes=120, max_premium_pct=cap)
            data, fetched = self._load(symbol, now, expected)
            result.update(as_of=data.get("as_of"), fetched_at=fetched)
            if data.get("symbol") != symbol or data.get("currency") != spec["currency"]:
                raise ValueError("Cached issuer NAV identity or currency mismatch")
            nav_day = date.fromisoformat(data["as_of"])
            if data["as_of"] > expected or data["as_of"] not in _calendar(nav_day.year, market).sessions:
                raise ValueError("NAV date is future, incomplete or not an exchange session")
            nav = _positive(data["nav"])
            if (date.fromisoformat(expected) - nav_day).days > 30:
                raise ValueError("Issuer NAV is more than 30 calendar days old")
            lag = len(_sessions(nav_day, date.fromisoformat(expected), market)) - 1
            result["metrics"].update(nav=nav, currency=spec["currency"], nav_lag_sessions=lag)
            if data.get("official_close"):
                close = _positive(data["official_close"])
                result["metrics"].update(official_close=close, official_close_date=data["as_of"],
                                         official_premium_discount_pct=(close/nav-1)*100)
                if cap is not None:
                    result["metrics"]["dated_close_meets_premium_limit"] = (close/nav-1)*100 <= cap
            if lag > lag_limit:
                raise ValueError(f"Issuer NAV is stale: {data['as_of']}; expected {expected}; lag {lag} sessions exceeds {lag_limit}.")
            quote = quote_dict or {}
            if not quote:
                result.update(status="REVIEW", reasons=["Dated NAV available; current validated price is unavailable."])
                return result
            if quote.get("symbol", symbol) != symbol or quote.get("currency") != spec["currency"]:
                raise ValueError("Quote and NAV security/currency mismatch")
            stamp = _utc(datetime.fromisoformat(quote["timestamp"]))
            age_limit = policy.get("max_quote_age_seconds", 1200)
            if isinstance(age_limit, bool) or not isinstance(age_limit, (int, float)) or not 1 <= age_limit <= 86400:
                raise ValueError("Invalid NAV quote age limit")
            age = (now-stamp).total_seconds()
            if not 0 <= age <= age_limit:
                raise ValueError("Quote for NAV comparison is stale or future")
            price = _positive(quote["price"])
            gap = (price/nav-1)*100
            result["metrics"].update(price=price, quote_timestamp=stamp.isoformat(), quote_age_seconds=age,
                                     price_vs_dated_nav_pct=gap)
            local_day = stamp.astimezone(ZoneInfo(MARKETS[market]["timezone"])).date().isoformat()
            close_stamp = _calendar(nav_day.year, market).session_close(nav_day.isoformat()).to_pydatetime()
            if market == "HK":
                close_stamp += timedelta(minutes=10)
            if local_day != data["as_of"] or abs((stamp-close_stamp).total_seconds()) > 5 or quote.get("phase", "regular") != "regular":
                result.update(status="REVIEW", reasons=[f"Price versus {data['as_of']} NAV is indicative only: timestamps are not the same session close. Current premium/discount cannot be verified from daily NAV."])
                return result
            result["metrics"]["premium_discount_pct"] = gap
            if cap is None:
                result.update(status="REVIEW", reasons=["Comparable close/NAV available, but no numeric premium/discount condition is configured."])
            else:
                status = "PASS" if gap <= cap else "FAIL"
                result.update(status=status, complete=True, reasons=[f"Same-close NAV premium/discount {gap:.2f}% {'meets' if status == 'PASS' else 'exceeds'} configured maximum {cap:.2f}%. This condition alone is not an instruction to buy."])
        except (ValueError, KeyError, TypeError, OSError, OverflowError) as exc:
            result.update(status="UNAVAILABLE", complete=False, reasons=[str(exc)])
        return result
