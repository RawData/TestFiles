"""Collect dated news and optional local model commentary. No alerts or trading."""
import argparse
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
import fcntl
import getpass
import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import stat
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit, urlencode, parse_qsl
from urllib.request import Request, build_opener, HTTPRedirectHandler
import xml.etree.ElementTree as ET

from monitor import atomic_json, runtime_home

UTC = timezone.utc
ROOT = Path(__file__).resolve().parent
MARKETAUX = "https://api.marketaux.com/v1/news/all"
GDELT = "https://api.gdeltproject.org/api/v2/doc/doc"


class TextOnly(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts = []
    def handle_data(self, value):
        self.parts.append(value)


def clean(value, limit=2500):
    parser = TextOnly()
    parser.feed(str(value or "")[:20000])
    return " ".join(" ".join(parser.parts).split())[:limit]


def instant(value):
    if not value:
        return None
    try:
        t = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        try:
            t = datetime.strptime(str(value), "%Y%m%dT%H%M%SZ").replace(tzinfo=UTC)
        except (ValueError, TypeError):
            try:
                t = parsedate_to_datetime(str(value))
            except (ValueError, TypeError):
                return None
    return t.astimezone(UTC) if t.tzinfo else None


def safe_url(value):
    try:
        p = urlsplit(str(value))
        if p.scheme not in ("https", "http") or not p.hostname or p.username or p.password:
            return None
        params = [(k,v) for k,v in parse_qsl(p.query, keep_blank_values=True)
                  if not k.lower().startswith("utm_") and k.lower() not in ("api_token", "api_key", "token", "fbclid", "gclid")]
        return urlunsplit((p.scheme, p.netloc.lower(), p.path, urlencode(params), ""))
    except ValueError:
        return None


def article(source, title, url, published, snippet, now, *, seen=None, symbols=()):
    url = safe_url(url)
    title = clean(title, 400)
    if not url or not title:
        return None
    stamp = instant(published)
    if stamp and stamp > now + timedelta(minutes=5):
        return None
    seen_stamp = instant(seen)
    return {"id": hashlib.sha256(url.encode()).hexdigest()[:24],
            "url": url, "title": title, "snippet": clean(snippet),
            "publisher": urlsplit(url).hostname, "collected_via": [source["id"]],
            "source_kind": source["kind"], "published_at": stamp.isoformat() if stamp else None,
            "provider_seen_at": seen_stamp.isoformat() if seen_stamp and seen_stamp <= now+timedelta(minutes=5) else None,
            "fetched_at": now.isoformat(), "symbols": sorted(set(symbols)),
            "content_scope": "headline_and_snippet" if snippet else "headline_only",
            "verification": "Publisher statement; independent confirmation not assessed"}


def parse_feed(raw, source, now):
    if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise ValueError("DTD or entities are not accepted")
    root = ET.fromstring(raw)
    local = lambda tag: tag.rsplit("}",1)[-1]
    if local(root.tag) not in ("rss", "RDF", "feed"):
        raise ValueError("Not an RSS/Atom document")
    result = []
    for node in root.iter():
        if local(node.tag) not in ("item", "entry"):
            continue
        fields = {}; link = None
        for child in node:
            tag = local(child.tag)
            fields[tag] = "".join(child.itertext())
            if tag == "link" and child.attrib.get("rel", "alternate") == "alternate":
                link = child.attrib.get("href") or fields[tag]
        row = article(source, fields.get("title"), link, fields.get("pubDate") or fields.get("published") or fields.get("date"),
                      fields.get("description") or fields.get("summary"), now)
        if row:
            # Atom updated is not substituted for publication.
            row["publisher_updated_at"] = fields.get("updated")
            result.append(row)
    return result, {"coverage": "Feed entries only; article bodies not fetched"}


def parse_json(raw, source, now):
    data = json.loads(raw)
    kind = source["kind"]
    key = "data" if kind == "marketaux" else "articles"
    if not isinstance(data, dict) or not isinstance(data.get(key), list):
        raise ValueError("Unexpected provider response")
    result = []
    for item in data[key]:
        if not isinstance(item, dict):
            continue
        row = article(source, item.get("title"), item.get("url"),
                      item.get("published_at") if kind == "marketaux" else None,
                      item.get("snippet") or item.get("description"), now,
                      seen=item.get("seendate") if kind == "gdelt" else None,
                      symbols=[e["symbol"] for e in item.get("entities", []) if isinstance(e,dict) and isinstance(e.get("symbol"),str)])
        if row:
            result.append(row)
    meta = {"coverage": "Limited latest results; not exhaustive", "returned": len(result)}
    if kind == "marketaux":
        meta["provider_meta"] = {k: data.get("meta",{}).get(k) for k in ("found","returned","limit","page")}
    return result, meta


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward a credential-bearing URL to another host.


def fetch(url, headers=None):
    try:
        req = Request(url, headers={"User-Agent": "PortfolioNewsReader/1.0", "Accept": "application/json, application/rss+xml, application/atom+xml, application/xml, text/xml, */*;q=0.1", **(headers or {})})
        with build_opener(NoRedirect).open(req, timeout=15) as response:
            raw = response.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ValueError("Response exceeds limit")
        return raw
    except HTTPError as exc:
        raise ValueError("HTTP " + str(exc.code)) from None
    except URLError as exc:
        raise ValueError("Network/response failure: " + type(exc.reason).__name__) from None
    except Exception as exc:
        # Request URLs can contain a key. Never log exception text or bodies.
        raise ValueError("Network/response failure: " + type(exc).__name__) from None


def read_key(path):
    path = Path(path)
    if path.is_symlink() or stat.S_IMODE(path.stat().st_mode) & 0o077:
        raise ValueError("Credential file must be owner-only and not a symlink")
    key = json.loads(path.read_text())["marketaux_api_key"]
    if not isinstance(key,str) or not re.fullmatch(r"[A-Za-z0-9_-]{12,200}", key):
        raise ValueError("Invalid credential format")
    return key


def load_config(path):
    config = json.loads(Path(path).read_text())
    if config.get("version") != 1 or not isinstance(config.get("sources"),list):
        raise ValueError("Invalid news configuration")
    ids = set()
    article_settings = config.get("article_fetch", {})
    if config.get("model_analysis"):
        from news_analysis import validate_settings
        validate_settings(config["model_analysis"])
    for key, default, ceiling in (("max_per_run",12,30),("max_per_host",2,5)):
        value = article_settings.get(key,default)
        if type(value) is not int or not 1 <= value <= ceiling:
            raise ValueError("Invalid article fetch bound")
    for s in config["sources"]:
        if not re.fullmatch(r"[a-z0-9_-]+", s["id"]) or s["id"] in ids:
            raise ValueError("Invalid/duplicate source ID")
        ids.add(s["id"])
        if s["kind"] not in ("rss","gdelt","marketaux"):
            raise ValueError("Unknown source kind")
        if s["kind"] == "rss" and not str(s.get("url","")).startswith("https://"):
            raise ValueError("Feeds require HTTPS")
        if not isinstance(s.get("interval_seconds"),int) or s["interval_seconds"] < 300:
            raise ValueError("Source interval must be at least five minutes")
        if s["kind"] == "marketaux" and (s.get("daily_cap",0) not in range(1,101) or s.get("limit") not in range(1,4)):
            raise ValueError("Default Marketaux free-plan protection exceeded")
    return config


def merge_article(store, row):
    old = store.get(row["id"])
    row["first_seen_at"] = old["first_seen_at"] if old else row["fetched_at"]
    if old:
        if "article" in old: row["article"] = old["article"]
        row["collected_via"] = sorted(set(old["collected_via"] + row["collected_via"]))
        if not row["snippet"] and old["snippet"]:
            row["snippet"], row["content_scope"] = old["snippet"], old["content_scope"]
        row["published_at"] = row["published_at"] or old.get("published_at")
        row["symbols"] = sorted(set(row["symbols"] + old["symbols"]))
    store[row["id"]] = row


def collect(config, folder, key_path, now, transport=fetch, *, articles_only=False, article_reader=None, model_transport=None):
    """Lock persisted attempts before HTTP, enforcing quota across processes."""
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    with (folder/"collection.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        path = folder/"state.json"
        state = json.loads(path.read_text()) if path.exists() else {"version":1,"sources":{},"articles":{}}
        if state.get("version") != 1:
            raise ValueError("Unknown news state; preserve and investigate")
        # The exclusive lock means any persisted PENDING attempt belonged to a
        # previous interrupted run, not another currently active collector.
        for row in state["articles"].values():
            if row.get("article", {}).get("status") == "PENDING":
                row["article"]["status"] = "INTERRUPTED"
        checks = []
        for s in config["sources"]:
            prior = state["sources"].get(s["id"], {})
            if articles_only:
                checks.append({"id":s["id"],"status":"CACHED", "last_result":prior or {"status":"NOT_FETCHED"}}); continue
            last = instant(prior.get("attempted_at"))
            delay = max(s["interval_seconds"], prior.get("retry_seconds",0))
            if last and (now-last).total_seconds() < delay:
                checks.append({"id":s["id"],"status":"CACHED", "last_result":prior}); continue
            if s["kind"] == "marketaux":
                budget = state.setdefault("marketaux_budget", {})
                if budget.get("day") != now.date().isoformat():
                    budget.update(day=now.date().isoformat(), attempts=0)
                if budget["attempts"] >= s["daily_cap"]:
                    checks.append({"id":s["id"],"status":"QUOTA_DEFERRED"}); continue
            entry = {"attempted_at":now.isoformat(), "status":"PENDING"}
            state["sources"][s["id"]] = entry
            key = None
            try:
                if s["kind"] == "marketaux":
                    key = read_key(key_path)
                    params = {"api_token":key,"language":"en","limit":s["limit"],"group_similar":"true",
                              "published_after":(now-timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%S")}
                    if s.get("search"): params["search"] = s["search"]
                    url = MARKETAUX + "?" + urlencode(params)
                    budget["attempts"] += 1
                elif s["kind"] == "gdelt":
                    url = GDELT + "?" + urlencode({"query":s["query"],"mode":"artlist","format":"json","maxrecords":50,"timespan":"24h","sort":"datedesc"})
                else:
                    url = s["url"]
                atomic_json(path, state)
                raw = transport(url)
                if key:
                    raw = raw.replace(key.encode(), b"[REDACTED]")
                rows, meta = parse_feed(raw,s,now) if s["kind"] == "rss" else parse_json(raw,s,now)
                for row in rows:
                    merge_article(state["articles"],row)
                entry.update(status="AVAILABLE", count=len(rows), metadata=meta, succeeded_at=now.isoformat())
            except Exception as exc:
                # Only whitelisted status text; neither raw exception nor response.
                code = str(exc) if isinstance(exc,ValueError) and re.fullmatch(r"HTTP [0-9]{3}|Network/response failure: [A-Za-z]+", str(exc)) else type(exc).__name__
                entry.update(status="UNAVAILABLE", error=code,
                             retry_seconds=min(86400, max(s["interval_seconds"], prior.get("retry_seconds",0)*2, 900)))
            checks.append({"id":s["id"], **entry})
            atomic_json(path,state)
        cutoff = now-timedelta(days=7)
        retained = [r for r in state["articles"].values()
                    if (instant(r.get("published_at")) or instant(r["first_seen_at"])) >= cutoff]
        retained.sort(key=lambda r:r.get("published_at") or r["first_seen_at"], reverse=True)
        state["articles"] = {r["id"]:r for r in retained[:2000]}
        article_events = []
        if config.get("article_fetch", {}).get("enabled", False):
            from article_reader import enrich, model_evidence
            article_events = enrich(retained[:2000],now,config["article_fetch"],reader=article_reader,
                                    checkpoint=lambda:atomic_json(path,state))
            atomic_json(folder/"model-evidence.json",model_evidence(retained[:2000]))
        atomic_json(path,state)
        report = {"generated_at":now.isoformat(),"mode":"collection_only","model_status":"DISABLED_AWAITING_ENDPOINT",
                  "sources":checks,"articles":retained[:2000],
                  "article_checks":article_events,
                  "marketaux_budget":state.get("marketaux_budget"),
                  "limitations":["Public article text where accessible; extraction completeness is unverified. Otherwise headline/snippet only",
                    "URL and text similarity deduplication; syndicated stories are not independent corroboration",
                    "GDELT seen time is not publication time; local model interpretations are conditional, not verified market signals",
                    "Availability describes feed retrieval, not completeness or factual verification"]}
        if config.get("model_analysis",{}).get("enabled"):
            from news_analysis import analyze_news
            analysis = analyze_news(report,config["model_analysis"],folder/"news-analysis.json",now,model_transport)
            report.update(mode="collection_and_local_analysis",model_status=analysis["status"],news_analysis=analysis)
        persist_report(folder,report)
        with (folder/"actions.jsonl").open("a") as log:
            log.write(json.dumps({"at":now.isoformat(),"checks":checks,"article_checks":article_events,"article_count":len(retained[:2000]),
                                  "model_status":report["model_status"],"model_input_digest":report.get("news_analysis",{}).get("input_digest")})+"\n")
        return report


def persist_report(folder, report):
    """Shared artifact writer for collected, cached and explicitly reanalyzed news."""
    folder=Path(folder)
    atomic_json(folder/"latest.json",report)
    (folder/"latest.html").write_text(render(report))
    if report.get("news_analysis"):
        from article_reader import model_evidence
        package=model_evidence(report["articles"])
        package.update(model_status=report["model_status"],analysis_file="news-analysis.json")
        atomic_json(folder/"model-evidence.json",package)


def render(report):
    e = html.escape
    statuses = []
    for s in report["sources"]:
        result = s.get("last_result", s)
        label = s["status"]
        if s["status"] == "CACHED":
            label += " — previous result: " + result["status"]
        if result.get("error"):
            label += " (" + result["error"] + ")"
        label += " · Last attempt: " + result.get("attempted_at", "not attempted")
        statuses.append("<li>" + e(s["id"]) + ": " + e(label) + "</li>")
    status = "".join(statuses)
    def article_detail(r):
        body = r.get("article", {})
        label = body.get("status", "NOT_FETCHED") + " · " + body.get("scope", "headline/snippet only")
        detail = "<p><strong>Article: "+e(label)+"</strong></p>"
        if body.get("attempted_at"): detail += "<small>Article checked: "+e(body["attempted_at"])+"</small>"
        if body.get("publisher_date"): detail += "<p>Publisher date: "+e(body["publisher_date"])+" (publisher metadata)</p>"
        if body.get("final_url"): detail += "<p><a href='"+e(body["final_url"],quote=True)+"'>Fetched publisher page</a></p>"
        if body.get("duplicate_of"): detail += "<p>Likely duplicate of "+e(body["duplicate_of"])+"; excluded from separate model evidence.</p>"
        if body.get("text"):
            excerpt = " ".join(body["text"].split()[:150])
            detail += "<details><summary>Extracted preview · "+str(body["word_count"])+" words detected</summary><p>"+e(excerpt)+"…</p></details>"
        return detail
    items = "".join("<article><h3><a href='"+e(r["url"],quote=True)+"'>"+e(r["title"])+"</a></h3><p>"+e(r["snippet"])+"</p><small>"+
                    e(r["publisher"])+" · "+e(", ".join(r["collected_via"]))+" · "+e(r["content_scope"])+
                    " · Published: "+e(r.get("published_at") or "unknown")+" · Retrieved: "+e(r["fetched_at"])+"</small>"+article_detail(r)+"</article>" for r in report["articles"])
    analysis_html=""
    if report.get("news_analysis"):
        from news_context_view import render_news_analysis
        analysis_html=render_news_analysis(report["news_analysis"],datetime.now(UTC))
    return "<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>News evidence</title><style>body{font:16px/1.6 system-ui;max-width:1050px;margin:30px auto;padding:20px;background:#f6f8f9;color:#233744}article,.news-analysis{background:white;padding:18px;margin:15px 0;border:1px solid #ddd}a{color:#176e6a}small{color:#586770}</style><h1>Collected news evidence</h1><p>Collected: "+e(report["generated_at"])+" · Model status: "+e(report["model_status"])+"</p>"+analysis_html+"<h2>Source availability</h2><ul>"+status+"</ul><p>"+e(" · ".join(report["limitations"]))+"</p>"+items


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config",type=Path,default=ROOT/"news-sources.json")
    p.add_argument("--output",type=Path,default=ROOT/"news-evidence")
    p.add_argument("--key-file",type=Path,default=runtime_home()/"news-secret.json")
    p.add_argument("--set-marketaux-key",action="store_true")
    p.add_argument("--articles-only",action="store_true",help="Enrich saved links without requesting news feeds")
    p.add_argument("--analysis-only",action="store_true",help="Analyze the saved snapshot without fetching sources or publisher pages")
    p.add_argument("--skip-analysis",action="store_true",help="Collect evidence without contacting Ollama")
    args = p.parse_args()
    if args.set_marketaux_key:
        key = getpass.getpass("Marketaux key (hidden): ").strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{12,200}",key):raise SystemExit("Invalid key format")
        atomic_json(args.key_file,{"marketaux_api_key":key})
        print("Credential saved with owner-only file permissions."); return
    config=load_config(args.config)
    if args.skip_analysis: config["model_analysis"]={"enabled":False}
    if args.analysis_only:
        from news_analysis import analyze_news
        args.output.mkdir(parents=True,exist_ok=True)
        with (args.output/"collection.lock").open("a") as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            report=json.loads((args.output/"latest.json").read_text())
            now=datetime.now(UTC)
            analysis=analyze_news(report,config.get("model_analysis",{}),args.output/"news-analysis.json",now)
            report.update(news_analysis=analysis,model_status=analysis["status"],mode="collection_and_local_analysis")
            persist_report(args.output,report)
            with (args.output/"actions.jsonl").open("a") as log:
                log.write(json.dumps({"at":now.isoformat(),"operation":"analysis_only","model_status":analysis["status"],"model_input_digest":analysis.get("input_digest")})+"\n")
    else:
        report = collect(config,args.output,args.key_file,datetime.now(UTC),articles_only=args.articles_only)
    print(json.dumps({"articles":len(report["articles"]),"article_checks":report["article_checks"],"sources":[{"id":s["id"],"status":s["status"],"error":s.get("error")} for s in report["sources"]],"model":report["model_status"]}))


if __name__ == "__main__":
    main()
