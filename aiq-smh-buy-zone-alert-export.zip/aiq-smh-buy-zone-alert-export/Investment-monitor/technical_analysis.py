"""Deterministic, completed-session technical review; no network or AI calls.

The caller must provide chronologically ordered, split-consistent OHLCV bars for
COMPLETED exchange sessions and validate their freshness. This module validates
the values, but cannot decide whether an exchange has closed from a date alone.

PASS means the configured technical checks passed, never a purchase instruction.
Historical testing has not established a consistent buying advantage for this
filter. PASS must not be interpreted as a validated profitable entry signal.
It does not verify valuation, earnings, guidance, NAV, taxes or portfolio fit.
Confirmed pivots use bars on both sides and are usable only on their confirmation
date. These are transparent rules, not a reproduction of the supplied LuxAlgo
script or user-configured chart state. A live quote may downgrade, never upgrade, the
completed-session assessment.
"""

from __future__ import annotations

from datetime import date
import math
from typing import Any, Mapping, Sequence


SCHEMA_VERSION = 1
DEFAULT_POLICY = {
    "mode": "equity",
    "pivot_span": 2,
    "slope_lookback": 5,
    "min_history": 200,
    "max_breakout_age": 5,
    "min_positive_volume_sessions": 15,
    "min_avg_dollar_volume": 100_000.0,
    "min_relative_volume": 0.8,
    "max_extension_atr": 2.0,
    "min_rsi": 45.0,
    "max_rsi": 70.0,
}


def _number(value: Any) -> float:
    if isinstance(value, bool):
        raise ValueError("boolean is not a market-data number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("market-data numbers must be finite")
    return number


def sma(values: Sequence[float], period: int) -> list[float | None]:
    """Trailing arithmetic averages, retaining warm-up None values."""
    if period < 1:
        raise ValueError("period must be positive")
    result: list[float | None] = [None] * len(values)
    total = 0.0
    for i, value in enumerate(values):
        total += value
        if i >= period:
            total -= values[i - period]
        if i >= period - 1:
            result[i] = total / period
    return result


def ema(values: Sequence[float], period: int) -> list[float | None]:
    """EMA seeded with the first period's arithmetic mean, alpha=2/(n+1)."""
    if period < 1:
        raise ValueError("period must be positive")
    result: list[float | None] = [None] * len(values)
    if len(values) < period:
        return result
    running = sum(values[:period]) / period
    result[period - 1] = running
    alpha = 2.0 / (period + 1)
    for i in range(period, len(values)):
        running += alpha * (values[i] - running)
        result[i] = running
    return result


def wilder_rsi(closes: Sequence[float], period: int = 14) -> list[float | None]:
    """Wilder RSI: seed from n changes, then smooth with alpha=1/n.

    Flat series return 50, gains without losses 100, and losses without gains 0.
    """
    if period < 1:
        raise ValueError("period must be positive")
    result: list[float | None] = [None] * len(closes)
    if len(closes) <= period:
        return result
    changes = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gain = sum(max(x, 0.0) for x in changes[:period]) / period
    loss = sum(max(-x, 0.0) for x in changes[:period]) / period

    def value() -> float:
        if gain == 0 and loss == 0:
            return 50.0
        if loss == 0:
            return 100.0
        return 100.0 - 100.0 / (1.0 + gain / loss)

    result[period] = value()
    for i in range(period + 1, len(closes)):
        change = changes[i - 1]
        gain = (gain * (period - 1) + max(change, 0.0)) / period
        loss = (loss * (period - 1) + max(-change, 0.0)) / period
        result[i] = value()
    return result


def wilder_atr(bars: Sequence[Mapping[str, Any]], period: int = 14) -> list[float | None]:
    """Wilder true range average; first bar's true range is high minus low."""
    if period < 1:
        raise ValueError("period must be positive")
    result: list[float | None] = [None] * len(bars)
    if len(bars) < period:
        return result
    ranges = []
    for i, bar in enumerate(bars):
        high, low = bar["high"], bar["low"]
        ranges.append(max(high - low, abs(high - bars[i - 1]["close"]),
                          abs(low - bars[i - 1]["close"])) if i else high - low)
    running = sum(ranges[:period]) / period
    result[period - 1] = running
    for i in range(period, len(bars)):
        running = (running * (period - 1) + ranges[i]) / period
        result[i] = running
    return result


def macd_series(closes: Sequence[float]) -> tuple[list, list, list]:
    """SMA-seeded 12/26 EMA difference, 9-period EMA signal and histogram."""
    fast, slow = ema(closes, 12), ema(closes, 26)
    line = [f - s if f is not None and s is not None else None
            for f, s in zip(fast, slow)]
    available = [x for x in line if x is not None]
    signal = [None] * (len(line) - len(available)) + ema(available, 9)
    histogram = [m - s if m is not None and s is not None else None
                 for m, s in zip(line, signal)]
    return line, signal, histogram


def confirmed_pivots(bars: Sequence[Mapping[str, Any]], span: int = 2) -> dict:
    """Strict extrema with span bars either side; equal highs/lows are not pivots.

    `date` identifies the extremum; `confirmed_on` is the first date it can be
    known. The last span bars can never be returned as confirmed extrema.
    """
    if span < 1:
        raise ValueError("pivot span must be positive")
    result: dict[str, list] = {"highs": [], "lows": []}
    for i in range(span, len(bars) - span):
        neighbours = list(bars[i - span:i]) + list(bars[i + 1:i + span + 1])
        for field, kind, compare in (("high", "highs", max), ("low", "lows", min)):
            extreme = compare(bar[field] for bar in neighbours)
            valid = bars[i][field] > extreme if kind == "highs" else bars[i][field] < extreme
            if valid:
                result[kind].append({"date": bars[i]["date"], "price": bars[i][field],
                                     "index": i, "confirmed_on": bars[i + span]["date"],
                                     "confirmed_index": i + span})
    return result


def _policy(policy: Mapping[str, Any] | None) -> dict:
    supplied = {} if policy is None else dict(policy)
    if set(supplied) - set(DEFAULT_POLICY):
        raise ValueError("Unknown technical policy fields: " + ", ".join(sorted(set(supplied) - set(DEFAULT_POLICY))))
    # An explicit unknown mode must not silently become an equity buy gate.
    result = dict(DEFAULT_POLICY, **supplied)
    if result["mode"] not in ("equity", "nav_review"):
        raise ValueError("technical policy mode must be equity or nav_review")
    for key in ("pivot_span", "slope_lookback", "min_history", "max_breakout_age",
                "min_positive_volume_sessions"):
        value = _number(result[key])
        if value != int(value) or value < 1:
            raise ValueError(f"{key} must be a positive integer")
        result[key] = int(value)
    if result["pivot_span"] > 20 or result["slope_lookback"] > 100:
        raise ValueError("pivot_span or slope_lookback is outside the supported range")
    if result["min_positive_volume_sessions"] > 20:
        raise ValueError("min_positive_volume_sessions cannot exceed 20")
    for key in ("min_avg_dollar_volume", "min_relative_volume", "max_extension_atr"):
        value = _number(result[key])
        if value < 0:
            raise ValueError(f"{key} cannot be negative")
        result[key] = value
    for key in ("min_rsi", "max_rsi"):
        result[key] = _number(result[key])
    if not 0 <= result["min_rsi"] < result["max_rsi"] <= 100:
        raise ValueError("RSI confirmation bounds must satisfy 0 <= min < max <= 100")
    result["min_history"] = max(result["min_history"], 200, 50 + result["slope_lookback"])
    return result


def _validated_bars(bars: Sequence[Mapping[str, Any]]) -> list[dict]:
    result = []
    previous = None
    for index, bar in enumerate(bars):
        if not isinstance(bar, Mapping):
            raise ValueError(f"bar {index} is not an object")
        stamp = bar["date"]
        if not isinstance(stamp, str) or date.fromisoformat(stamp).isoformat() != stamp:
            raise ValueError(f"bar {index}: date must be YYYY-MM-DD")
        if previous is not None and stamp <= previous:
            raise ValueError("daily bar dates must be unique and strictly increasing")
        previous = stamp
        clean = {key: _number(bar[key]) for key in ("open", "high", "low", "close", "volume")}
        if min(clean[key] for key in ("open", "high", "low", "close")) <= 0:
            raise ValueError(f"bar {stamp}: OHLC must be positive")
        if (clean["low"] > min(clean["open"], clean["close"]) or
                clean["high"] < max(clean["open"], clean["close"]) or
                clean["low"] > clean["high"]):
            raise ValueError(f"bar {stamp}: inconsistent OHLC range")
        if clean["volume"] < 0:
            raise ValueError(f"bar {stamp}: negative volume")
        clean["date"] = stamp
        result.append(clean)
    return result


def _result(status: str, reasons: list[str], *, as_of=None, policy=None,
            metrics=None, trend="unknown", daily_status=None, live_check=None) -> dict:
    return {"schema_version": SCHEMA_VERSION, "status": status,
            "daily_status": daily_status or status, "trend": trend,
            "as_of": as_of, "reasons": reasons, "metrics": metrics or {},
            "live_check": live_check or {"provided": False, "can_upgrade": False},
            "policy": policy or {}, "technical_only": True,
            "performance_validation": "NOT_ESTABLISHED",
            "limitations": "Completed-session technical rules only; fundamentals, NAV and portfolio suitability are not verified. Not a LuxAlgo replica."}


def analyze_daily(bars: Sequence[Mapping[str, Any]], live_price=None,
                  policy: Mapping[str, Any] | None = None) -> dict:
    """Return a JSON-serializable review, failing closed on invalid/missing data.

    Equity PASS requires a rising SMA50, close above it, a higher confirmed
    swing low and a recent completed close breakout over a confirmed pivot high.
    A lower-low structure below a falling SMA50 is FAIL; other
    incomplete setups WAIT. Loss of support invalidates the setup. Low volume
    and excessive extension block PASS. Live prices can only deteriorate it.
    """
    try:
        rules = _policy(policy)
    except (TypeError, ValueError, OverflowError) as error:
        return _result("UNAVAILABLE", [f"Invalid technical policy: {error}"])
    if rules["mode"] == "nav_review":
        return _result("NOT_APPLICABLE", ["Equity trend/breakout rules do not establish value for this NAV/income review. Verify NAV, distributions and instrument-specific conditions manually."], policy=rules)
    try:
        clean = _validated_bars(bars)
    except (TypeError, KeyError, ValueError, OverflowError) as error:
        return _result("UNAVAILABLE", [f"Invalid daily history: {error}"], policy=rules)
    as_of = clean[-1]["date"] if clean else None
    if len(clean) < rules["min_history"]:
        return _result("UNAVAILABLE", [f"Need at least {rules['min_history']} completed daily sessions; received {len(clean)}."],
                       as_of=as_of, policy=rules, metrics={"history_sessions": len(clean)})

    closes = [bar["close"] for bar in clean]
    close = closes[-1]
    volumes = [bar["volume"] for bar in clean]
    averages = {period: sma(closes, period) for period in (20, 50, 200)}
    slope_age = rules["slope_lookback"]
    slopes = {period: series[-1] - series[-1 - slope_age] if series[-1 - slope_age] is not None else None
              for period, series in averages.items()}
    rsi = wilder_rsi(closes)[-1]
    atr = wilder_atr(clean)[-1]
    macd, signal, histogram = macd_series(closes)
    pivots = confirmed_pivots(clean, rules["pivot_span"])
    highs, lows = pivots["highs"], pivots["lows"]
    higher_high = highs[-1]["price"] > highs[-2]["price"] if len(highs) >= 2 else None
    lower_high = highs[-1]["price"] < highs[-2]["price"] if len(highs) >= 2 else None
    higher_low = lows[-1]["price"] > lows[-2]["price"] if len(lows) >= 2 else None
    lower_low = lows[-1]["price"] < lows[-2]["price"] if len(lows) >= 2 else None
    support = min(bar["low"] for bar in clean[-21:-1])
    resistance = max(bar["high"] for bar in clean[-21:-1])
    latest_low = lows[-1]["price"] if lows else None
    break_level = max(support, latest_low) if latest_low is not None else support
    level = highs[-1]["price"] if highs else None
    breakout_index = None
    if highs:
        # Do not backdate a breakout to before the pivot was knowable.
        start = max(highs[-1]["confirmed_index"], 1)
        for i in range(start, len(clean)):
            if closes[i] > level and closes[i - 1] <= level:
                breakout_index = i
    breakout_age = len(clean) - 1 - breakout_index if breakout_index is not None else None
    recent_breakout = (level is not None and close > level and breakout_age is not None
                       and breakout_age <= rules["max_breakout_age"])
    average_volume = sum(volumes[-21:-1]) / 20
    relative_volume = volumes[-1] / average_volume if average_volume > 0 else None
    average_dollar_volume = sum(bar["volume"] * bar["close"] for bar in clean[-20:]) / 20
    positive_volume_sessions = sum(volume > 0 for volume in volumes[-20:])
    extension = (close - averages[20][-1]) / atr if atr and atr > 0 else None
    quality = {"positive_volume_sessions20": positive_volume_sessions,
               "average_dollar_volume20": average_dollar_volume,
               "history_sessions": len(clean)}
    metrics = {"history_sessions": len(clean), "close": close,
               **{f"sma{period}": series[-1] for period, series in averages.items()},
               **{f"sma{period}_slope": slope for period, slope in slopes.items()},
               **{f"sma{period}_slope_pct": 100 * slope / averages[period][-1 - slope_age] if slope is not None else None
                  for period, slope in slopes.items()},
               "slope_sessions": slope_age, "rsi14": rsi, "atr14": atr,
               "atr_pct": 100 * atr / close, "macd": macd[-1],
               "macd_signal": signal[-1], "macd_histogram": histogram[-1],
               "support20": support, "resistance20": resistance,
               "latest_confirmed_low": latest_low, "live_break_level": break_level,
               "higher_high": higher_high, "higher_low": higher_low,
               "lower_high": lower_high, "lower_low": lower_low,
               "confirmed_pivots": {"highs": highs[-4:], "lows": lows[-4:]},
               "breakout_level": level, "breakout_confirmed": bool(recent_breakout),
               "breakout_date": clean[breakout_index]["date"] if breakout_index is not None else None,
               "breakout_age_sessions": breakout_age, "volume": volumes[-1],
               "avg_volume20": average_volume, "relative_volume20": relative_volume,
               "extension_from_sma20_atr": extension, "quality": quality}

    rising50 = slopes[50] > 0 and close > averages[50][-1]
    falling50 = slopes[50] < 0 and close < averages[50][-1]
    bearish_structure = lower_low is True and lower_high is True
    bullish_structure = higher_low is True and (higher_high is True or recent_breakout)
    trend = ("bearish" if falling50 and (bearish_structure or lower_low is True)
             else "bullish" if rising50 and bullish_structure else "mixed")
    wait_reasons = []
    fail_reasons = []
    if falling50 and lower_low is True:
        fail_reasons.append("Confirmed lower lows, with the close below a falling 50-session SMA; a minor higher high alone does not establish a reversal.")
    if close < support:
        fail_reasons.append("The completed daily close broke below the preceding 20-session support low.")
    if latest_low is not None and close < latest_low:
        fail_reasons.append("The completed daily close is below the latest confirmed swing low.")
    if not rising50:
        wait_reasons.append("Need a completed close above a rising 50-session SMA.")
    if higher_low is not True:
        wait_reasons.append("A higher confirmed swing low has not formed.")
    if not recent_breakout:
        wait_reasons.append("Need a completed close breakout above the latest confirmed pivot high within the last "
                            f"{rules['max_breakout_age']} sessions.")
    if lows and len(clean) - 1 - lows[-1]["index"] > 60:
        wait_reasons.append("Latest confirmed swing low is older than 60 sessions; require a current base.")
    if not rules["min_rsi"] <= rsi <= rules["max_rsi"]:
        wait_reasons.append(f"RSI14 is outside the {rules['min_rsi']:g}-{rules['max_rsi']:g} confirmation range; oversold alone is not a reversal and overbought entries need a pullback.")
    if histogram[-1] < 0:
        wait_reasons.append("MACD remains below its signal line; momentum confirmation is incomplete.")
    if positive_volume_sessions < rules["min_positive_volume_sessions"]:
        wait_reasons.append("Too few positive-volume sessions in the last 20; liquidity confirmation is weak.")
    if average_dollar_volume < rules["min_avg_dollar_volume"]:
        wait_reasons.append("Average traded value is below the configured liquidity floor.")
    if relative_volume is None or relative_volume < rules["min_relative_volume"]:
        wait_reasons.append("Latest completed-session volume is below the configured confirmation threshold.")
    if atr == 0:
        wait_reasons.append("Daily prices are flat; volatility and a tradable breakout are unconfirmed.")
    elif extension is not None and extension > rules["max_extension_atr"]:
        wait_reasons.append("Price is extended above the 20-session SMA by more than the configured ATR limit; wait for a supported pullback.")

    if not any(volumes[-20:]):
        daily_status = "UNAVAILABLE"
        reasons = ["No positive volume in the last 20 completed sessions; a tradable price series cannot be confirmed."]
    elif fail_reasons:
        daily_status = "FAIL"
        reasons = fail_reasons + wait_reasons
    elif wait_reasons:
        daily_status = "WAIT"
        reasons = wait_reasons
    else:
        daily_status = "PASS"
        reasons = ["Completed-session checks passed: close above a rising SMA50, a confirmed higher low and a recent pivot-high breakout with acceptable liquidity and extension.",
                   "This technical pass does not confirm the fundamental conditions or constitute a buy recommendation."]

    status = daily_status
    live = {"provided": live_price is not None, "can_upgrade": False}
    if live_price is not None:
        try:
            price = _number(live_price)
            if price <= 0:
                raise ValueError("live price must be positive")
            live.update({"price": price, "support_break_level": break_level,
                         "below_support": price < break_level})
            if price < break_level:
                # Inadequate history quality remains unavailable, not a claimed
                # technical conclusion based on an unreliable support estimate.
                if daily_status != "UNAVAILABLE":
                    status = "FAIL"
                reasons.insert(0, "Live price is below the latest confirmed swing-low / prior 20-session support threshold; the setup has deteriorated intraday.")
            elif daily_status == "PASS" and (price < averages[50][-1] or (level is not None and price <= level)):
                status = "WAIT"
                reasons.insert(0, "Live price has lost the completed-session breakout or SMA50; wait for renewed confirmation.")
                live["lost_confirmation"] = True
            elif daily_status == "PASS" and atr > 0 and (price - averages[20][-1]) / atr > rules["max_extension_atr"]:
                status = "WAIT"
                reasons.insert(0, "Live price is now more than the configured ATR limit above SMA20; do not chase the extension.")
        except (TypeError, ValueError, OverflowError) as error:
            status = "UNAVAILABLE"
            reasons.insert(0, f"Invalid live quote; cannot validate current setup: {error}")
            live["error"] = str(error)
    return _result(status, reasons, as_of=as_of, policy=rules, metrics=metrics,
                   trend=trend, daily_status=daily_status, live_check=live)
