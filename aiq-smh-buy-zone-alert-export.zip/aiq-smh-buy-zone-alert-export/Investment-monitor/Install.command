#!/bin/bash
set -euo pipefail
monitor_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd -- "$monitor_root"

finish() {
  monitor_result=$?
  if [ "$monitor_result" -ne 0 ]; then
    echo "Setup stopped. Read the error above; no password is printed."
  fi
  if [ -t 0 ]; then
    read -r -p "Press Return to close this window. " || true
  fi
}
trap finish EXIT

echo "Investment Monitor - local macOS setup"
echo "This installs a read-only market monitor. It never places trades."

if [ ! -f config.json ]; then
  cp config.example.json config.json
  chmod 600 config.json
  echo "Created private config.json from the public example."
  echo "Review it before enabling email or replacing the example watchlist."
fi

monitor_python="${ARORA_PYTHON:-python3}"
"$monitor_python" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else "Python 3.10 or later is required.")'
if [ ! -x .venv/bin/python ]; then
  "$monitor_python" -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.txt

if .venv/bin/python -c 'import json; raise SystemExit(0 if json.load(open("config.json"))["alerts"]["email"]["enabled"] else 1)'; then
  # The password is entered through getpass, verified using TLS, and saved in a
  # private local file. Nothing here prints or commits passwords.
  .venv/bin/python monitor.py --configure-email
fi
.venv/bin/python install_launchd.py install
echo "The local monitor is enabled."
echo "Mac notification visibility depends on macOS notification and Focus settings."
