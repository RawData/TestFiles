"""Dated, source-attributed context for reports. No news inference or AI calls.

Editorial inputs are data, not code. Expired context is clearly historical and
never changes technical grades, position limits or alert thresholds.
"""
from datetime import datetime, timezone
import html
import json
from pathlib import Path
from urllib.parse import urlparse


def stamp(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError("Context timestamps require a timezone")
    return result.astimezone(timezone.utc)


def load_context(path, now):
    if not path:
        return {"status": "UNAVAILABLE", "reason": "No reviewed macro context supplied."}
    try:
        data = json.loads(Path(path).read_text())
        reviewed, expires = stamp(data["reviewed_at"]), stamp(data["expires_at"])
        if data.get("version") != 1 or reviewed > now or expires <= reviewed:
            raise ValueError("Invalid context version or review dates")
        for item in data.get("facts", []) + data.get("events", []) + data.get("seasonality", []):
            url = urlparse(item["source"])
            if url.scheme != "https" or not url.netloc:
                raise ValueError("Context sources require HTTPS links")
        for event in data.get("events", []):
            stamp(event["at"])
        return {**data, "status": "CURRENT" if now < expires else "EXPIRED"}
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return {"status": "UNAVAILABLE", "reason": str(exc)[:200]}


def render_context(data, now):
    e = lambda value: html.escape(str(value))
    if data.get("status") == "UNAVAILABLE" or not data:
        return "<p>Macro/geopolitical context unavailable: " + e(data.get("reason", "Not supplied")) + "</p>"
    expired = now >= stamp(data["expires_at"])
    label = "EXPIRED — historical context; fresh review required" if expired else "Reviewed context; events can change after publication"
    parts = [f"<p class='note'><b>{label}</b>. Reviewed {e(data['reviewed_at'])}; expires {e(data['expires_at'])}. Public-source facts and scenario interpretations are separated below. This is not a live news feed.</p>"]
    parts.append("<h3>Macro and geopolitical evidence</h3>")
    for item in data.get("facts", []):
        parts.append(f"<p><b>{e(item['title'])}</b> · {e(item['as_of'])}. {e(item['text'])} <a href='{e(item['source'])}'>{e(item['publisher'])}</a></p>")
    parts.append("<h3>Event calendar</h3>")
    for event in data.get("events", []):
        status = "Upcoming at report build" if now < stamp(event["at"]) else "Scheduled time has passed; outcome not verified in this context"
        parts.append(f"<p><b>{e(event['title'])}</b>: {e(event['display_time'])}. {status}. <a href='{e(event['source'])}'>Source calendar</a></p>")
    parts.append("<h3>Seasonality</h3>")
    for item in data.get("seasonality", []):
        parts.append(f"<p>{e(item['text'])} <a href='{e(item['source'])}'>{e(item['publisher'])}</a></p>")
    parts.append("<h3>Rebound and downside scenarios · interpretation, not prediction</h3>")
    for scenario in data.get("scenarios", []):
        parts.append(f"<p><b>{e(scenario['title'])}:</b> {e(scenario['conditions'])} <b>Portfolio implication:</b> {e(scenario['implication'])}</p>")
    parts.append("<p>No scenario probabilities were fitted. Calendar seasonality and news narratives do not turn a failed chart setup into a standing buy recommendation. A short-term rebound can occur while slower trend checks still fail.</p>")
    return "".join(parts)
