import copy
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
from technical_data import DailyHistoryService, expected_completed_session, parse_daily_payload, _sessions
from market_clock import _calendar

UTC=timezone.utc
NOW=datetime(2026,9,8,15,tzinfo=UTC)
RULE={'symbol':'CSV'}

def payload(market='US', symbol='CSV', now=NOW, n=260):
    expected=expected_completed_session(now,market)
    ds=_sessions(date.fromisoformat(expected)-timedelta(days=430),date.fromisoformat(expected),market)[-n:]
    stamps=[int(_calendar(int(d[:4]),market).session_open(d).timestamp()) for d in ds]
    quotes={'open':[50.0]*len(ds),'close':[50.0]*len(ds),'high':[51.0]*len(ds),'low':[49.0]*len(ds),'volume':[100000]*len(ds)}
    return {'chart':{'error':None,'result':[{'meta':{'symbol':symbol,'currency':'HKD' if market=='HK' else 'USD',
              'exchangeTimezoneName':'Asia/Hong_Kong' if market=='HK' else 'America/New_York','dataGranularity':'1d'},
              'timestamp':stamps,'indicators':{'quote':[quotes]}}]}}

class DailyData(unittest.TestCase):
    def test_us_holiday_and_publish_grace(self):
        self.assertEqual(expected_completed_session(NOW),'2026-09-04')
        self.assertEqual(expected_completed_session(NOW.replace(hour=20,minute=19)),'2026-09-04')
        self.assertEqual(expected_completed_session(NOW.replace(hour=20,minute=20)),'2026-09-08')
        self.assertEqual(expected_completed_session(datetime(2026,1,1,20,tzinfo=UTC)),'2025-12-31')

    def test_hk_auction_lunch_and_grace(self):
        self.assertEqual(expected_completed_session(NOW.replace(hour=4),'HK'),'2026-09-07')
        self.assertEqual(expected_completed_session(NOW.replace(hour=8,minute=29),'HK'),'2026-09-07')
        self.assertEqual(expected_completed_session(NOW.replace(hour=8,minute=30),'HK'),'2026-09-08')
        h=parse_daily_payload({'symbol':'3419.HK','market':'HK'},payload('HK','3419.HK'),NOW)
        self.assertEqual(h['currency'],'HKD')
        self.assertEqual(h['as_of'],'2026-09-08')

    def test_early_close(self):
        before=datetime(2026,11,27,18,19,tzinfo=UTC)
        self.assertEqual(expected_completed_session(before),'2026-11-25')
        self.assertEqual(expected_completed_session(before+timedelta(minutes=1)),'2026-11-27')

    def test_incomplete_session_excluded_even_if_null(self):
        p=payload();r=p['chart']['result'][0]
        r['timestamp'].append(int(NOW.replace(hour=13,minute=30).timestamp()))
        for values in r['indicators']['quote'][0].values(): values.append(None)
        h=parse_daily_payload(RULE,p,NOW)
        self.assertEqual(h['as_of'],'2026-09-04')
        self.assertEqual(len(h['bars']),260)

    def test_bad_identity_stale_duplicate_and_gaps_rejected(self):
        for field,value in [('symbol','WRONG'),('currency','EUR'),('exchangeTimezoneName','UTC'),('dataGranularity','1h')]:
            p=payload();p['chart']['result'][0]['meta'][field]=value
            with self.assertRaises(ValueError):parse_daily_payload(RULE,p,NOW)
        p=payload();r=p['chart']['result'][0]
        for index in range(109,99,-1):
            r['timestamp'].pop(index)
            for values in r['indicators']['quote'][0].values():values.pop(index)
        with self.assertRaises(ValueError):parse_daily_payload(RULE,p,NOW)
        p=payload();r=p['chart']['result'][0];r['timestamp'][-1]=r['timestamp'][-2]
        with self.assertRaises(ValueError):parse_daily_payload(RULE,p,NOW)

    def test_isolated_null_sessions_are_skipped_not_interpolated(self):
        p=payload();r=p['chart']['result'][0]
        for values in r['indicators']['quote'][0].values():values[55]=None
        h=parse_daily_payload(RULE,p,NOW)
        self.assertEqual(len(h['bars']),259)
        self.assertEqual(len(h['missing_sessions']),1)
        with tempfile.TemporaryDirectory() as tmp:
            service=DailyHistoryService(tmp,fetcher=lambda s:p)
            self.assertEqual(service(RULE,{},NOW)['status'],'WAIT')
        for values in r['indicators']['quote'][0].values():values[-1]=None
        h=parse_daily_payload(RULE,p,NOW)
        self.assertEqual(h['as_of'],h['bars'][-1]['date'])
        self.assertIn('2026-09-04',h['missing_sessions'])
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(DailyHistoryService(tmp,fetcher=lambda s:p)(RULE,{},NOW)['status'],'UNAVAILABLE')

    def test_missing_latest_session_is_retried_and_recovers(self):
        complete = payload()
        incomplete = copy.deepcopy(complete)
        for values in incomplete['chart']['result'][0]['indicators']['quote'][0].values():
            values[-1] = None
        fetcher = Mock(side_effect=[incomplete, complete])
        with tempfile.TemporaryDirectory() as tmp:
            service = DailyHistoryService(tmp, fetcher=fetcher)
            self.assertEqual(service(RULE, {}, NOW)['status'], 'UNAVAILABLE')
            self.assertEqual(service(RULE, {}, NOW+timedelta(minutes=4))['status'], 'UNAVAILABLE')
            self.assertEqual(fetcher.call_count, 1)
            recovered = service(RULE, {}, NOW+timedelta(minutes=5))
            self.assertEqual(recovered['status'], 'WAIT')
            self.assertEqual(recovered['as_of'], '2026-09-04')
            self.assertEqual(fetcher.call_count, 2)

    def test_excessive_missing_sessions_rejected(self):
        p=payload();r=p['chart']['result'][0]
        for index in range(100,110):
            for values in r['indicators']['quote'][0].values():values[index]=None
        with self.assertRaises(ValueError):parse_daily_payload(RULE,p,NOW)

    def test_vendor_inconsistent_and_partial_rows_skipped_within_tolerance(self):
        p=payload();r=p['chart']['result'][0];q=r['indicators']['quote'][0]
        q['high'][100]=40.0
        h=parse_daily_payload(RULE,p,NOW)
        self.assertEqual(len(h['bars']),259)
        self.assertEqual(len(h['missing_sessions']),1)
        q['volume'][150]=None
        h=parse_daily_payload(RULE,p,NOW)
        self.assertEqual(len(h['bars']),258)
        self.assertEqual(len(h['missing_sessions']),2)

    def test_cache_once_per_session_and_read_only_no_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Mock(return_value=payload());svc=DailyHistoryService(tmp,fetcher=f)
            self.assertFalse(svc.get_history(RULE,NOW)['cache_hit'])
            self.assertTrue(svc.get_history(RULE,NOW+timedelta(minutes=5))['cache_hit'])
            f.assert_called_once()
            f2=Mock(side_effect=RuntimeError('must not call'))
            self.assertTrue(DailyHistoryService(tmp,fetcher=f2).get_history(RULE,NOW)['cache_hit'])
            self.assertFalse(f2.called)
        with tempfile.TemporaryDirectory() as tmp:
            svc=DailyHistoryService(tmp,fetcher=lambda s:payload(),read_only=True)
            self.assertEqual(svc.get_history(RULE,NOW)['status'],'AVAILABLE')
            self.assertEqual(list(Path(tmp).iterdir()),[])

    def test_failure_backoff_and_stale_cache_cannot_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Mock(side_effect=ValueError('missing data'));svc=DailyHistoryService(tmp,fetcher=f)
            self.assertEqual(svc(RULE,{},NOW)['status'],'UNAVAILABLE')
            svc(RULE,{},NOW+timedelta(minutes=4));f.assert_called_once()
            svc(RULE,{},NOW+timedelta(minutes=5));self.assertEqual(f.call_count,2)
        with tempfile.TemporaryDirectory() as tmp:
            svc=DailyHistoryService(tmp,fetcher=lambda s:payload());svc.get_history(RULE,NOW)
            result=svc(RULE,{},NOW.replace(hour=21))
            self.assertFalse(result['cache_hit'])
            self.assertEqual(result['expected_session'],'2026-09-08')
            self.assertEqual(result['as_of'],'2026-09-04')
            self.assertTrue(any('Skipped 1 session(s)' in reason and '2026-09-08' in reason for reason in result['reasons']))

    def test_split_invalidates_saved_zone(self):
        p=payload();r=p['chart']['result'][0]
        r['events']={'splits':{'s':{'date':int(NOW.replace(hour=13,minute=30).timestamp()),'numerator':2,'denominator':1}}}
        with tempfile.TemporaryDirectory() as tmp:
            result=DailyHistoryService(tmp,fetcher=lambda s:p)(dict(RULE,zone_as_of='2026-09-07'),{},NOW)
            self.assertEqual(result['status'],'UNAVAILABLE')
            self.assertIn('split',result['reasons'][0])

    def test_large_gap_blocks_daily_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            result=DailyHistoryService(tmp,fetcher=lambda s:payload())(RULE,{'price':'100'},NOW)
            self.assertEqual(result['status'],'UNAVAILABLE')
            self.assertIn('factor',result['reasons'][0])

    def test_distribution_warning_cannot_be_a_pass(self):
        p=payload();r=p['chart']['result'][0]
        r['events']={'dividends':{'d':{'date':r['timestamp'][-1],'amount':1.0}}}
        with tempfile.TemporaryDirectory() as tmp, patch('technical_analysis.analyze_daily',return_value={'status':'PASS','reasons':[],'metrics':{}}):
            result=DailyHistoryService(tmp,fetcher=lambda s:p)(RULE,{},NOW)
            self.assertEqual(result['status'],'WAIT')
            self.assertIn('distribution',result['reasons'][0])

    def test_nav_review_needs_no_daily_provider(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Mock(side_effect=RuntimeError())
            r=DailyHistoryService(tmp,fetcher=f)(dict(RULE,technical_policy={'mode':'nav_review'}),{},NOW)
            self.assertEqual(r['status'],'NOT_APPLICABLE');f.assert_not_called()
