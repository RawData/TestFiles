"""Test the test-delivery helper without network, notifications or state writes."""

from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from test_delivery import run_test


CONFIG = {"alerts": {"mac": True, "email": {"enabled": True,
          "to": ["first@example.test", "second@example.test"]}}}


class TestDeliveryHelper(unittest.TestCase):
    def test_default_preview_has_no_delivery_or_filesystem_side_effects(self):
        sender = Mock()
        with tempfile.TemporaryDirectory() as folder:
            home = Path(folder)
            state = home / "state.json"
            state.write_text('{"preserve":"exact bytes"}')
            before = state.read_bytes()
            with patch("monitor.fetch_quote", side_effect=AssertionError("No quote reads")):
                result = run_test(CONFIG, home, sender=sender)
            sender.assert_not_called()
            self.assertFalse(result["sent"])
            self.assertEqual(len(result["results"]), 3)
            self.assertEqual(state.read_bytes(), before)
            self.assertEqual(list(home.iterdir()), [state])

    def test_explicit_send_is_labelled_and_failure_does_not_skip_other_destinations(self):
        def deliver(channel, title, body):
            self.assertTrue(title.startswith("TEST ONLY"))
            self.assertIn("No quote was fetched", body)
            self.assertIn("saved zone NOT EVALUATED", body)
            if channel == "email:first@example.test":
                raise OSError("Private server diagnostics must not be logged")
        sender = Mock(side_effect=deliver)
        result = run_test(CONFIG, Path("/unused"), send=True, sender=sender)
        self.assertEqual(sender.call_count, 3)
        self.assertEqual([row["status"] for row in result["results"]],
                         ["accepted_by_sender", "failed", "accepted_by_sender"])
        self.assertNotIn("Private server", str(result))
        again = run_test(CONFIG, Path("/unused"), send=True, sender=Mock())
        self.assertNotEqual(result["event_id"], again["event_id"])


if __name__ == "__main__":
    unittest.main()
