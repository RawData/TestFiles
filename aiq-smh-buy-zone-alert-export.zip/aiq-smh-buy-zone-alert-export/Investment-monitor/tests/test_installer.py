"""Exercise installation rollback and preview without touching real launchd."""

import contextlib
import io
from pathlib import Path
import plistlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import install_launchd as installer


class InstallerTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.home = Path(temporary.name)
        self.root = self.home / "app"
        self.root.mkdir()
        (self.root / "monitor.py").write_text("# test fixture\n")
        (self.root / "config.json").write_text("{}")
        self.plist = self.home / "Library/LaunchAgents" / f"{installer.LABEL}.plist"
        self.runtime = self.home / "Library/Application Support/AroraPriceMonitor"
        for patcher in (
            patch.object(installer, "ROOT", self.root),
            patch.object(Path, "home", return_value=self.home),
            patch.object(installer.sys, "platform", "darwin"),
        ):
            patcher.start()
            self.addCleanup(patcher.stop)
        self.arguments = ["--python", sys.executable, "--runtime-home", str(self.runtime)]

    def invoke(self, arguments):
        with contextlib.redirect_stdout(io.StringIO()):
            return installer.main(arguments)

    def test_dry_run_writes_preview_only(self):
        preview = self.root / "preview.plist"
        with patch.object(installer, "launchctl") as launch, patch.object(installer, "preflight") as preflight:
            self.assertEqual(self.invoke(["install", "--dry-run", "--output", str(preview), *self.arguments]), 0)
        launch.assert_not_called()
        preflight.assert_not_called()
        self.assertFalse(self.plist.exists())
        self.assertFalse(self.runtime.exists())
        content = plistlib.loads(preview.read_bytes())
        self.assertTrue(content["RunAtLoad"])
        self.assertEqual(content["StartInterval"], 300)
        self.assertEqual(content["ProgramArguments"][0], sys.executable)
        self.assertEqual(content["ProgramArguments"][3], str(self.root / "config.json"))

    def test_existing_different_job_is_preserved(self):
        installer.atomic_write(self.plist, b"previous configuration")
        with patch.object(installer, "launchctl") as launch, patch.object(installer, "preflight"):
            with self.assertRaisesRegex(RuntimeError, "different plist"):
                self.invoke(["install", *self.arguments])
        launch.assert_not_called()
        self.assertEqual(self.plist.read_bytes(), b"previous configuration")

    def test_failed_replacement_restores_previous_job(self):
        previous = plistlib.dumps({"Label": installer.LABEL, "ProgramArguments": ["/previous/python"]})
        installer.atomic_write(self.plist, previous)
        calls = []

        def launch(*arguments, **kwargs):
            calls.append(arguments)
            if arguments[0] == "bootstrap" and sum(c[0] == "bootstrap" for c in calls) == 1:
                raise RuntimeError("simulated bootstrap failure")
            return subprocess.CompletedProcess(arguments, 0, "", "")

        with patch.object(installer, "launchctl", side_effect=launch), patch.object(installer, "preflight"):
            with self.assertRaisesRegex(RuntimeError, "simulated bootstrap"):
                self.invoke(["install", "--replace", *self.arguments])
        self.assertEqual(self.plist.read_bytes(), previous)
        self.assertEqual(sum(c[0] == "bootstrap" for c in calls), 2)
        self.assertEqual(sum(c[0] == "bootout" for c in calls), 1)

    def test_preflight_failure_leaves_scheduler_untouched(self):
        with patch.object(installer, "launchctl") as launch, patch.object(
            installer, "preflight", side_effect=RuntimeError("missing dependency")
        ):
            with self.assertRaisesRegex(RuntimeError, "missing dependency"):
                self.invoke(["install", *self.arguments])
        launch.assert_not_called()
        self.assertFalse(self.plist.exists())

    def test_uninstall_keeps_alert_history(self):
        installer.atomic_write(self.plist, plistlib.dumps({"Label": installer.LABEL}))
        self.runtime.mkdir(parents=True)
        state = self.runtime / "state.json"
        state.write_text('{"version": 1}')
        with patch.object(installer, "launchctl", return_value=subprocess.CompletedProcess([], 0, "", "")) as launch:
            self.assertEqual(self.invoke(["uninstall", *self.arguments]), 0)
        self.assertFalse(self.plist.exists())
        self.assertTrue(state.exists())
        self.assertEqual(launch.call_args_list[-1].args[0], "bootout")


if __name__ == "__main__":
    unittest.main()
