import copy
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock,patch
import monitor

NOW=datetime(2026,9,8,15,tzinfo=timezone.utc)
RULE={'symbol':'CSV','low':'32','high':'34','alert_kind':'review_zone','source':'Saved research','review_notes':'Require a base and better cash flow.'}
SESSION={'market':'US','slot':'slot1','open':NOW.replace(hour=13,minute=30),'close':NOW.replace(hour=20)}

class TechnicalIntegration(unittest.TestCase):
    def setUp(self):
        self.c={'version':1,'watchlist':[copy.deepcopy(RULE)],'zone_source':'saved','technical_analysis':{'enabled':True},
                'alerts':{'mac':True,'email':{'enabled':False}},'max_quote_age_seconds':1200}
        self.state={'version':1,'symbols':{}}
        self.send=Mock();self.grade='WAIT';self.now=NOW
    def evaluator(self,rule,q,now):
        return {'status':self.grade,'daily_status':self.grade,'as_of':'2026-09-04','expected_session':'2026-09-04','reasons':['test reason'],'metrics':{}}
    def run_check(self,price='33',**kwargs):
        s=dict(SESSION,slot=str(self.now))
        return monitor.run_cycle(self.c,self.state,self.now,s,fetcher=lambda sym:monitor.Quote(sym,Decimal(price),self.now),
            sender=self.send,technical_evaluator=self.evaluator,**kwargs)
    def advance(self):self.now+=timedelta(minutes=5)

    def test_same_inside_grade_silent_then_improvement_and_deterioration_alert(self):
        self.assertEqual(self.run_check(),0);self.assertEqual(self.send.call_count,1)
        self.advance();self.run_check();self.assertEqual(self.send.call_count,1)
        self.grade='PASS';self.advance();self.run_check();self.assertEqual(self.send.call_count,2)
        self.assertIn('CHECKS MET (PASS) - watchlist only',self.send.call_args.args[2])
        self.assertIn('buying advantage not established',self.send.call_args.args[2])
        self.assertIn('Saved price zones and five-minute execution have not been backtested',self.send.call_args.args[2])
        self.grade='FAIL';self.advance();self.run_check();self.assertEqual(self.send.call_count,3)
        self.assertIn('DO NOT ENTER',self.send.call_args.args[2])
        # Return to previously announced grades on the same daily evidence does not spam.
        self.grade='PASS';self.advance();self.run_check();self.assertEqual(self.send.call_count,3)

    def test_outside_status_change_does_not_alert(self):
        self.run_check('35');self.grade='FAIL';self.advance();self.run_check('35')
        self.send.assert_not_called()

    def test_legacy_inside_migration_does_not_resend_baseline(self):
        e=monitor.observe(None,monitor.Quote('CSV',Decimal('33'),NOW),RULE,'old',['mac'],NOW)
        e['pending']=None;self.state['symbols']['CSV']=e
        self.run_check();self.send.assert_not_called()
        self.assertIn('technical',self.state['symbols']['CSV'])

    def test_partial_delivery_then_grade_change_creates_new_event(self):
        self.c['alerts']['email']={'enabled':True,'to':['one@example.test']}
        def delivery(channel,*args):
            if channel!='mac':raise RuntimeError('mock failure')
        self.send.side_effect=delivery
        self.run_check();old=self.state['symbols']['CSV']['pending']['id']
        self.assertEqual(self.state['symbols']['CSV']['pending']['ack'],['mac'])
        self.grade='FAIL';self.advance();self.run_check()
        new=self.state['symbols']['CSV']['pending']['id']
        self.assertNotEqual(old,new)
        self.assertEqual(sum(c.args[0]=='mac' for c in self.send.call_args_list),2)

    def test_pending_changed_back_to_seen_grade_has_new_id(self):
        self.c['alerts']['email']={'enabled':True,'to':['one@example.test']}
        self.run_check()
        self.grade='FAIL';self.advance()
        self.send.side_effect=lambda channel,*args: (_ for _ in ()).throw(RuntimeError()) if channel!='mac' else None
        self.run_check();old=self.state['symbols']['CSV']['pending']['id']
        self.grade='WAIT';self.advance();self.run_check()
        self.assertNotEqual(old,self.state['symbols']['CSV']['pending']['id'])

    def test_unavailable_is_not_a_previous_pass(self):
        self.grade='PASS';self.run_check()
        self.grade='UNAVAILABLE';self.advance();self.run_check()
        self.assertEqual(self.state['symbols']['CSV']['technical']['status'],'UNAVAILABLE')
        self.assertIn('current technical data unavailable',self.send.call_args.args[2])

    def test_failed_history_does_not_erase_price_event(self):
        self.evaluator=Mock(side_effect=ValueError('no history'))
        self.run_check();self.assertEqual(self.send.call_count,1)
        self.assertIn('UNAVAILABLE',self.send.call_args.args[2])

    def test_history_delay_ages_quote_and_prevents_send(self):
        clock=Mock(side_effect=[NOW,NOW,NOW+timedelta(minutes=21)])
        self.assertEqual(self.run_check(clock=clock),1)
        self.send.assert_not_called()

    def test_stale_quote_still_gets_daily_review_without_email(self):
        evaluator=Mock(return_value={'status':'WAIT','as_of':'2026-09-04','reasons':['no base'],'metrics':{}})
        result=monitor.run_cycle(self.c,self.state,NOW,SESSION,
            fetcher=lambda sym:monitor.Quote(sym,Decimal('33'),NOW-timedelta(minutes=25)),
            technical_evaluator=evaluator,sender=self.send)
        self.assertEqual(result,1);self.send.assert_not_called()
        self.assertEqual(evaluator.call_args.args[1],{})
        self.assertEqual(self.state['technical_reviews']['CSV']['status'],'WAIT')
        self.assertFalse(self.state['technical_reviews']['CSV']['live_quote_valid'])
        self.assertNotIn('CSV',self.state['symbols'])

    def test_dry_run_no_persistence_or_delivery(self):
        old=copy.deepcopy(self.state);persist=Mock()
        self.run_check(dry_run=True,persist=persist)
        self.assertEqual(self.state,old);persist.assert_not_called();self.send.assert_not_called()

    def test_support_watch_cannot_be_upgraded_to_buy(self):
        self.c['watchlist'][0]['alert_kind']='support_watch';self.grade='PASS'
        self.run_check()
        self.assertIn('SUPPORT WATCH - no standing buy recommendation',self.send.call_args.args[2])
        self.assertNotIn('ACTION STATUS: CHECKS MET (PASS)',self.send.call_args.args[2])

    def test_config_rejects_invalid_policy(self):
        for policy in [{'mode':'bogus'},{'mode':'equity','pivot_span':0}]:
            c=copy.deepcopy(self.c);c['watchlist'][0]['technical_policy']=policy
            with tempfile.TemporaryDirectory() as tmp:
                p=Path(tmp)/'config.json';p.write_text(json.dumps(c))
                with self.assertRaises(ValueError):monitor.load_config(p)

    def test_config_accepts_bounded_missing_session_tolerance(self):
        c=copy.deepcopy(self.c)
        c['currency']='USD'
        c['technical_analysis']['max_missing_sessions']=1
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'config.json';p.write_text(json.dumps(c))
            loaded=monitor.load_config(p)
        self.assertEqual(loaded['technical_analysis']['max_missing_sessions'],1)
