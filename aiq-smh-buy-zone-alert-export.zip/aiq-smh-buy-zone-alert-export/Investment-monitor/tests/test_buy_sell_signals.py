from datetime import datetime, timedelta, timezone
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

import monitor

from buy_sell_signals import (
    BuySellSignalService,
    _higher_biases,
    aggregate_hourly,
    evaluate_bars,
    parse_intraday_payload,
    run_alert_cycle,
    signal_market_due,
    session_slots,
    signal_settings,
)


UTC = timezone.utc
START = datetime(2026, 9, 16, 13, 30, tzinfo=UTC)


def bar(offset, open_price, high, low, close, *, minutes=15):
    start = START + timedelta(minutes=offset * minutes)
    return {
        "date": start.isoformat(),
        "end": (start + timedelta(minutes=minutes)).isoformat(),
        "open": open_price,
        "high": high,
        "low": low,
        "close": close,
        "volume": 100,
    }


class SignalEngineTests(unittest.TestCase):
    def test_buy_break_requires_next_candle_midpoint_confirmation(self):
        bars = [
            bar(0, 10, 11, 8, 9),
            bar(1, 9, 12.5, 8.5, 12),
            bar(2, 10, 11.5, 9.5, 11),
        ]
        result = evaluate_bars(bars)
        self.assertEqual(result["status"], "BUY")
        self.assertEqual(result["last_event"]["setup_at"], bars[1]["end"])
        self.assertEqual(result["last_event"]["confirmed_at"], bars[2]["end"])
        self.assertEqual(result["last_event"]["break_mid"], 10.5)
        self.assertEqual(result["last_event"]["tracked_level"], 11.0)

    def test_sell_break_requires_next_candle_midpoint_confirmation(self):
        bars = [
            bar(0, 9, 11, 8, 10),
            bar(1, 10, 10.5, 7, 7.5),
            bar(2, 8.5, 9, 7.5, 8),
        ]
        result = evaluate_bars(bars)
        self.assertEqual(result["status"], "SELL")
        self.assertEqual(result["last_event"]["break_mid"], 8.75)
        self.assertEqual(result["last_event"]["tracked_level"], 8.0)

    def test_failed_confirmation_expires_after_exactly_one_candle(self):
        bars = [
            bar(0, 10, 11, 8, 9),
            bar(1, 9, 12.5, 8.5, 12),
            bar(2, 10, 10.4, 9.5, 10.2),
            bar(3, 12, 12.2, 11, 11.5),
        ]
        result = evaluate_bars(bars)
        self.assertEqual(result["events"], [])
        self.assertEqual(result["status"], "NONE")

    def test_wick_mode_can_break_when_close_mode_cannot(self):
        bars = [
            bar(0, 10, 11, 8, 9),
            bar(1, 9, 11.5, 8.5, 10.5),
            bar(2, 10, 11, 9.5, 10.6),
        ]
        self.assertEqual(evaluate_bars(bars)["events"], [])
        wick = evaluate_bars(bars, options={"break_mode": "Wick"})
        self.assertEqual(wick["status"], "BUY")

    def test_daily_limit_blocks_second_same_direction_signal(self):
        bars = [
            bar(0, 10, 11, 8, 9),
            bar(1, 9, 12.5, 8.5, 12),
            bar(2, 10, 11.5, 9.5, 11),
            bar(3, 11, 11.2, 9.8, 10),
            bar(4, 10, 12.2, 9.9, 12),
            bar(5, 11, 12, 10.5, 11.5),
        ]
        options = {"alternate_signals": False}
        self.assertEqual(len(evaluate_bars(bars, options=options)["events"]), 1)
        options["use_daily_signal_limit"] = False
        self.assertEqual(len(evaluate_bars(bars, options=options)["events"]), 2)
        options["alternate_signals"] = True
        self.assertEqual(len(evaluate_bars(bars, options=options)["events"]), 1)

    def test_ema_and_consolidation_filters_gate_setup_and_confirmation(self):
        bars = [
            bar(0, 8, 9.5, 7.5, 9),
            bar(1, 9, 10.5, 8.5, 10),
            bar(2, 10, 11, 8.5, 9),
            bar(3, 9, 12.5, 8.5, 12),
            bar(4, 11, 12.3, 10.5, 12.2),
        ]
        ema = {"use_ema_cloud_filter": True, "ema_length": 2, "ema_slope_lookback": 1}
        self.assertEqual(evaluate_bars(bars, options=ema)["status"], "BUY")
        self.assertEqual(evaluate_bars(
            bars, options={**ema, "ema_sideways_threshold": 100})["events"], [])
        consolidation = {
            "use_consolidation_filter": True,
            "block_break_setups_during_consolidation": True,
            "consolidation_mode": "Range Only",
            "range_lookback": 2,
            "atr_length": 1,
            "range_atr_mult": 100,
        }
        self.assertEqual(evaluate_bars(bars, options=consolidation)["events"], [])

    def test_htf_bias_switches_after_not_on_shared_close_boundary(self):
        base = [bar(2, 10, 11, 9, 10)]
        base[0]["end"] = "2026-09-16T10:00:00+00:00"
        higher = [
            {**bar(0, 9, 12, 8, 10, minutes=60), "end": "2026-09-16T08:00:00+00:00"},
            {**bar(1, 10, 12, 8, 8, minutes=60), "end": "2026-09-16T09:00:00+00:00"},
            {**bar(2, 8, 12, 8, 12, minutes=60), "end": "2026-09-16T10:00:00+00:00"},
        ]
        self.assertEqual(_higher_biases(base, higher), [-1])
        base[0]["end"] = "2026-09-16T10:00:01+00:00"
        self.assertEqual(_higher_biases(base, higher), [1])

    def test_last_break_candle_is_reported_as_pending(self):
        bars = [bar(0, 10, 11, 8, 9), bar(1, 9, 12.5, 8.5, 12)]
        result = evaluate_bars(bars)
        self.assertEqual(result["status"], "PENDING_BUY")
        self.assertEqual(result["pending"]["break_mid"], 10.5)

    def test_unknown_configuration_fails_closed(self):
        with self.assertRaises(ValueError):
            signal_settings({"buy_sell_signals": {"enabled": True, "surprise": True}})


def intraday_payload(now, *, symbol="TEST", market="US"):
    day = now.astimezone().date().isoformat()
    if market == "US":
        day = "2026-09-16"
    slots = [slot for slot in session_slots(day, market) if slot[0] <= now]
    return {"chart": {"result": [{
        "meta": {
            "symbol": symbol,
            "currency": "USD" if market == "US" else "HKD",
            "exchangeTimezoneName": "America/New_York" if market == "US" else "Asia/Hong_Kong",
            "dataGranularity": "15m",
        },
        "timestamp": [int(start.timestamp()) for start, _ in slots],
        "indicators": {"quote": [{
            "open": [10.0] * len(slots), "high": [11.0] * len(slots),
            "low": [9.0] * len(slots), "close": [10.5] * len(slots),
            "volume": [100] * len(slots),
        }]},
    }], "error": None}}


class CandleDataTests(unittest.TestCase):
    def test_signal_window_includes_post_close_and_hk_lunch_but_not_overnight(self):
        self.assertTrue(signal_market_due(datetime(2026, 9, 16, 20, 22, tzinfo=UTC), "US"))
        self.assertFalse(signal_market_due(datetime(2026, 9, 16, 22, 0, tzinfo=UTC), "US"))
        self.assertTrue(signal_market_due(datetime(2026, 9, 16, 4, 2, tzinfo=UTC), "HK"))

    def test_parser_excludes_forming_candles_and_hourly_uses_complete_groups(self):
        now = datetime(2026, 9, 16, 17, 2, tzinfo=UTC)
        bars = parse_intraday_payload(
            {"symbol": "TEST", "market": "US", "currency": "USD"},
            intraday_payload(now), now)
        self.assertEqual(bars[-1]["end"], "2026-09-16T17:00:00+00:00")
        hourly = aggregate_hourly(bars, "US", now)
        self.assertEqual([row["end"] for row in hourly], [
            "2026-09-16T14:30:00+00:00", "2026-09-16T15:30:00+00:00",
            "2026-09-16T16:30:00+00:00",
        ])

    def test_parser_rejects_wrong_interval_and_does_not_fill_null_candles(self):
        now = datetime(2026, 9, 16, 17, 2, tzinfo=UTC)
        payload = intraday_payload(now)
        payload["chart"]["result"][0]["meta"]["dataGranularity"] = "5m"
        with self.assertRaises(ValueError):
            parse_intraday_payload({"symbol": "TEST", "market": "US", "currency": "USD"}, payload, now)
        payload = intraday_payload(now)
        payload["chart"]["result"][0]["indicators"]["quote"][0]["close"][0] = None
        bars = parse_intraday_payload(
            {"symbol": "TEST", "market": "US", "currency": "USD"}, payload, now)
        self.assertNotEqual(bars[0]["date"], "2026-09-16T13:30:00+00:00")

    def test_provider_failure_observes_five_minute_backoff(self):
        now = datetime(2026, 9, 16, 17, 2, tzinfo=UTC)
        fetcher = Mock(side_effect=ValueError("provider down"))
        with tempfile.TemporaryDirectory() as folder:
            service = BuySellSignalService(
                folder, {"buy_sell_signals": {"enabled": True}},
                intraday_fetcher=fetcher, daily_service=Mock(), clock=lambda: now)
            with self.assertRaises(ValueError):
                service._intraday_bars(
                    {"symbol": "TEST", "market": "US", "currency": "USD"}, now)
            with self.assertRaises(ValueError):
                service._intraday_bars(
                    {"symbol": "TEST", "market": "US", "currency": "USD"},
                    now + timedelta(minutes=1))
        self.assertEqual(fetcher.call_count, 1)

    def test_service_combines_intraday_hourly_and_daily_candles(self):
        now = datetime(2026, 9, 16, 17, 2, tzinfo=UTC)
        payload = intraday_payload(now)
        quote = payload['chart']['result'][0]['indicators']['quote'][0]
        for name, values in {
            'open': [10, 9, 10], 'high': [11, 12.5, 11.5],
            'low': [8, 8.5, 9.5], 'close': [9, 12, 11],
        }.items():
            quote[name][-4:-1] = values
        daily = Mock()
        daily.grace = 20
        daily.get_history.return_value = {
            'status': 'AVAILABLE', 'as_of': '2026-09-15',
            'bars': [
                {'date': '2026-09-11', 'open': 10, 'high': 11, 'low': 8, 'close': 9, 'volume': 100},
                {'date': '2026-09-14', 'open': 9, 'high': 12.5, 'low': 8.5, 'close': 12, 'volume': 100},
                {'date': '2026-09-15', 'open': 10, 'high': 11.5, 'low': 9.5, 'close': 11, 'volume': 100},
            ],
        }
        with tempfile.TemporaryDirectory() as folder:
            service = BuySellSignalService(
                folder, {'buy_sell_signals': {'enabled': True}}, read_only=True,
                intraday_fetcher=Mock(return_value=payload), daily_service=daily,
                clock=lambda: now)
            result = service.evaluate(
                {'symbol': 'TEST', 'market': 'US', 'currency': 'USD'}, now)
        self.assertEqual(result['timeframes']['15m']['status'], 'BUY')
        self.assertEqual(result['timeframes']['1d']['status'], 'BUY')
        self.assertIn(result['timeframes']['1h']['status'], ('NONE', 'PENDING_BUY', 'PENDING_SELL'))


def snapshot(as_of, status="NONE"):
    event = None
    if status in ("BUY", "SELL"):
        event = {
            "direction": status, "confirmed_at": as_of, "confirmation_close": 12.0,
            "setup_at": "2026-09-16T14:00:00+00:00", "break_high": 12.5,
            "break_low": 9.5, "break_mid": 11.0, "tracked_level": 10.5,
        }
    return {"symbol": "TEST", "status": status, "checked_at": as_of,
            "timeframes": {"15m": {"status": status, "as_of": as_of, "last_event": event}}}


class AlertCycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "state.json"
        self.config = {
            "buy_sell_signals": {"enabled": True},
            "alerts": {"email": {"enabled": True, "to": ["a@example.test", "b@example.test"]}},
        }
        self.rule = {"symbol": "TEST"}
        self.sender = Mock()

    def test_first_observation_is_baseline_then_new_signal_sends_once(self):
        service = Mock()
        first = "2026-09-16T14:00:00+00:00"
        second = "2026-09-16T14:15:00+00:00"
        service.evaluate_many.side_effect = [
            {"TEST": snapshot(first, "BUY")},
            {"TEST": snapshot(second, "BUY")},
            {"TEST": snapshot(second, "BUY")},
        ]
        now = datetime(2026, 9, 16, 14, 17, tzinfo=UTC)
        self.assertEqual(run_alert_cycle(
            self.config, [self.rule], now, service, self.path, self.sender), 0)
        self.sender.assert_not_called()
        self.assertEqual(run_alert_cycle(
            self.config, [self.rule], now, service, self.path, self.sender), 0)
        self.assertEqual([call.args[0] for call in self.sender.call_args_list],
                         ["email:a@example.test", "email:b@example.test"])
        self.assertIn("TEST | 15m | BUY", self.sender.call_args.args[2])
        self.sender.reset_mock()
        self.assertEqual(run_alert_cycle(
            self.config, [self.rule], now, service, self.path, self.sender), 0)
        self.sender.assert_not_called()

    def test_only_failed_recipient_is_retried(self):
        service = Mock()
        first = "2026-09-16T14:00:00+00:00"
        second = "2026-09-16T14:15:00+00:00"
        service.evaluate_many.side_effect = [
            {"TEST": snapshot(first)}, {"TEST": snapshot(second, "SELL")},
            {"TEST": snapshot(second, "SELL")},
        ]
        now = datetime(2026, 9, 16, 14, 17, tzinfo=UTC)
        run_alert_cycle(self.config, [self.rule], now, service, self.path, self.sender)

        def fail_second(channel, title, body):
            if channel == "email:b@example.test":
                raise OSError("temporary")

        self.sender.side_effect = fail_second
        self.assertEqual(run_alert_cycle(
            self.config, [self.rule], now, service, self.path, self.sender), 1)
        self.sender.reset_mock(side_effect=True)
        self.assertEqual(run_alert_cycle(
            self.config, [self.rule], now, service, self.path, self.sender), 0)
        self.assertEqual([call.args[0] for call in self.sender.call_args_list], ["email:b@example.test"])


class MonitorHookTests(unittest.TestCase):
    def test_post_close_signal_window_runs_without_price_session(self):
        now = datetime(2026, 9, 16, 20, 25, tzinfo=UTC)
        config = monitor.load_config(monitor.DEFAULT_CONFIG)
        config['watchlist'] = [{'symbol': 'TEST', 'low': '9', 'high': '11'}]
        config['alerts']['email']['enabled'] = True
        config['alerts']['email']['to'] = ['recipient@example.test']
        config['extended_hours'] = False
        frozen = Mock()
        frozen.now.return_value = now
        service = Mock()
        with tempfile.TemporaryDirectory() as folder, \
                patch.object(monitor, 'datetime', frozen), \
                patch.object(monitor, 'load_config', return_value=config), \
                patch.object(monitor, 'runtime_home', return_value=Path(folder)), \
                patch.object(monitor, 'setup_logging'), \
                patch('buy_sell_signals.BuySellSignalService', return_value=service), \
                patch('buy_sell_signals.run_alert_cycle', return_value=0) as alert_cycle:
            self.assertEqual(monitor.main([]), 0)
        alert_cycle.assert_called_once()
        self.assertEqual(alert_cycle.call_args.args[1][0]['symbol'], 'TEST')


if __name__ == "__main__":
    unittest.main()