from datetime import timedelta
import json
import socket
import unittest
from unittest.mock import Mock, patch
from article_reader import Reader, ReadFailure, public_address, extract_article, enrich, mark_duplicates, model_evidence
from news_collector import merge_article
import test_news_collector as fixtures
NOW, SOURCE, RSS = fixtures.NOW, fixtures.SOURCE, fixtures.RSS

PARAGRAPHS = [
    'The central bank announced that it would leave interest rates unchanged after reviewing the latest economic data. Officials said that inflation remained above their target and that employment growth was slowing across several important sectors of the economy.',
    'The committee expects to assess further evidence before making another decision. Household spending has continued to increase, while companies have become more cautious about borrowing and investment. Policymakers highlighted the uncertainty surrounding energy prices and international trade developments.',
    'Bond yields moved lower following the announcement, but stock prices showed a mixed reaction. Analysts cautioned that one report cannot establish a trend and said that future inflation and employment releases would help determine whether financial conditions were improving.',
    'In its statement the bank said it remained prepared to respond to changing conditions. The next scheduled policy meeting will take place later this year, with updated forecasts and a press conference expected to provide additional context for investors.'
]
HTML = ('<html><head><title>Policy decision</title><meta property="article:published_time" content="2026-09-11T04:00:00Z"></head><body><nav>Navigation menu</nav><article><h1>Policy decision</h1>'+''.join('<p>'+p+'</p>' for p in PARAGRAPHS)+'</article><footer>Unwanted footer</footer></body></html>').encode()


def row(i='a'):
    return {'id':i,'url':'https://example.org/'+i,'title':'Policy decision', 'publisher':'example.org',
            'collected_via':['marketaux'],'fetched_at':NOW.isoformat(),'first_seen_at':NOW.isoformat(),
            'snippet':'Short feed description','content_scope':'headline_and_snippet','symbols':[], 'published_at':None}


class ArticleTests(unittest.TestCase):
    def test_extract_visible_main_text_and_date(self):
        result=extract_article(HTML,'https://example.org/a',NOW)
        self.assertEqual(result['status'],'EXTRACTED')
        self.assertNotIn('Unwanted footer',result['text'])
        self.assertEqual(result['publisher_date'],'2026-09-11T04:00:00Z')
    def test_paywall_does_not_extract_embedded_article(self):
        gated=HTML.replace(b'</head>',b'<script type="application/ld+json">{"@type":"NewsArticle","isAccessibleForFree":false,"articleBody":"secret body"}</script></head>')
        result=extract_article(gated,'https://example.org/a',NOW)
        self.assertEqual(result['status'],'PAYWALL')
        self.assertNotIn('text',result)
    def test_partial_and_challenge_not_full_articles(self):
        for body,status in [(b'<html><p>Brief preview</p></html>','PARTIAL_OR_UNREADABLE'),(b'<html><p>Verify you are human</p></html>','ACCESS_CHALLENGE')]:
            self.assertEqual(extract_article(body,'https://example.org/a',NOW)['status'],status)
    def test_publisher_restriction(self):
        self.assertEqual(extract_article(HTML,'https://example.org/a',NOW,{'x-robots-tag':'nosnippet'})['status'],'PUBLISHER_RESTRICTION')
    def test_long_preview_ending_mid_story_is_partial(self):
        preview=HTML.replace(PARAGRAPHS[-1].encode(),(PARAGRAPHS[-1]+'...').encode())
        self.assertEqual(extract_article(preview,'https://example.org/a',NOW)['status'],'PARTIAL_OR_UNREADABLE')
    def test_future_metadata_is_not_accepted(self):
        self.assertIsNone(extract_article(HTML.replace(b'2026-09-11',b'2027-09-11'),'https://example.org/a',NOW)['publisher_date'])
    def test_private_dns_and_credentials_rejected(self):
        with patch('article_reader.socket.getaddrinfo',return_value=[(socket.AF_INET,socket.SOCK_STREAM,6,'',('127.0.0.1',443))]):
            with self.assertRaises(ReadFailure): public_address('https://example.org/a')
        for url in ('file:///etc/passwd','http://user:pass@example.org','https://example.org:8080/a'):
            with self.assertRaises(ReadFailure): public_address(url)
    def test_dns_is_pinned_to_validated_ip(self):
        with patch('article_reader.public_address') as resolve, patch('article_reader.socket.create_connection') as connect, patch('article_reader.http.client.HTTPConnection') as conn:
            from urllib.parse import urlsplit
            from article_reader import request
            resolve.return_value=(urlsplit('http://example.org/a'),'93.184.216.34')
            response=conn.return_value.getresponse.return_value
            response.status=200;response.getheaders.return_value=[('Content-Type','text/html')];response.read.return_value=HTML
            request('http://example.org/a')
            connect.assert_called_once_with(('93.184.216.34',80),timeout=12)
            self.assertIs(conn.return_value.sock,connect.return_value)
    def test_robots_disallow_never_fetches_article(self):
        transport=Mock(return_value=(200,{},b'User-agent: *\nDisallow: /'))
        with self.assertRaisesRegex(ReadFailure,'ROBOTS_DISALLOWED'):Reader(transport,lambda _:None).read('https://example.org/a')
        self.assertEqual(transport.call_count,1)
    def test_redirect_checks_destination_robots(self):
        transport=Mock(side_effect=[(404,{},b''),(302,{'location':'https://other.org/a'},b''),(200,{},b'User-agent: *\nDisallow: /')])
        with self.assertRaisesRegex(ReadFailure,'ROBOTS_DISALLOWED'):Reader(transport,lambda _:None).read('https://example.org/a')
        self.assertEqual(transport.call_args.args[0],'https://other.org/robots.txt')
    def test_robots_redirect_is_followed(self):
        transport=Mock(side_effect=[(301,{'location':'/en/robots.txt'},b''),(200,{},b'User-agent: *\nAllow: /'),(200,{'content-type':'text/html'},HTML)])
        raw,url,_=Reader(transport,lambda _:None).read('https://example.org/a')
        self.assertEqual(raw,HTML)
        self.assertEqual(transport.call_count,3)
    def test_non_html_and_large_response(self):
        transport=Mock(side_effect=[(404,{},b''),(200,{'content-type':'application/pdf'},b'%PDF')])
        with self.assertRaisesRegex(ReadFailure,'NON_HTML'):Reader(transport,lambda _:None).read('https://example.org/a')
    def test_cache_and_budget(self):
        rows=[row(str(i)) for i in range(4)]
        reader=Mock();reader.read.return_value=(HTML,'https://example.org/a',{})
        settings={'max_per_run':3,'max_per_host':2}
        self.assertEqual(len(enrich(rows,NOW,settings,reader)),2)
        self.assertEqual(len(enrich(rows[:2],NOW+timedelta(hours=1),settings,reader)),0)
        self.assertEqual(reader.read.call_count,2)
    def test_interrupted_attempt_waits_fifteen_minutes(self):
        rows=[row()];rows[0]['article']={'status':'INTERRUPTED','attempted_at':NOW.isoformat()}
        reader=Mock();reader.read.return_value=(HTML,'https://example.org/a',{})
        self.assertEqual(enrich(rows,NOW+timedelta(minutes=14),{},reader),[])
        self.assertEqual(len(enrich(rows,NOW+timedelta(minutes=15),{},reader)),1)
    def test_error_text_never_leaks_and_is_cached(self):
        rows=[row()];reader=Mock();reader.read.side_effect=RuntimeError('sensitive provider text')
        enrich(rows,NOW,{},reader)
        self.assertNotIn('sensitive',json.dumps(rows))
        enrich(rows,NOW+timedelta(minutes=5),{},reader)
        self.assertEqual(reader.read.call_count,1)
    def test_duplicate_text_not_independent_model_evidence(self):
        rows=[row('a'),row('b'),row('c')]
        for r in rows[:2]: r['article']=extract_article(HTML,r['url'],NOW)
        mark_duplicates(rows)
        self.assertEqual(rows[1]['article']['duplicate_of'],'a')
        package=model_evidence(rows)
        self.assertEqual(len(package['evidence']),2)
        self.assertEqual(package['evidence'][1]['text'],'Short feed description')
        self.assertEqual(package['model_status'],'DISABLED_AWAITING_ENDPOINT')
    def test_feed_refresh_preserves_extracted_body(self):
        old=row();old['article']={'status':'EXTRACTED','text':'saved'}
        store={'a':old};merge_article(store,row())
        self.assertEqual(store['a']['article']['text'],'saved')


class ArticleIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.NewsTests()
        self.fixture.setUp()
        self.folder, self.secret = self.fixture.folder, self.fixture.secret
    def tearDown(self):
        self.fixture.tearDown()
    def test_articles_only_does_not_use_feed_quota(self):
        from news_collector import collect
        self.fixture.run_collect([SOURCE],Mock(return_value=RSS))
        network=Mock(side_effect=AssertionError('Feed request forbidden'))
        reader=Mock();reader.read.return_value=(HTML,'https://example.org/update',{})
        r=collect({'sources':[SOURCE],'article_fetch':{'enabled':True}}, self.folder/'evidence',self.secret,NOW,network,articles_only=True,article_reader=reader)
        network.assert_not_called()
        self.assertEqual(r['articles'][0]['article']['status'],'EXTRACTED')
        self.assertTrue((self.folder/'evidence'/'model-evidence.json').exists())
