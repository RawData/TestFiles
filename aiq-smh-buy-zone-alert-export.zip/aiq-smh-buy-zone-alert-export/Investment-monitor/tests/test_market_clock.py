"""Calendar boundaries that otherwise create weekend or stale-price alerts."""

from datetime import datetime, timezone
import unittest
from zoneinfo import ZoneInfo

from market_clock import market_session


def utc(value: str) -> datetime:
    return datetime.fromisoformat(value).replace(tzinfo=timezone.utc)


class MarketClockTests(unittest.TestCase):
    def test_weekend_and_labor_day_are_closed(self):
        self.assertIsNone(market_session(utc("2026-09-05T16:00:00")))
        self.assertIsNone(market_session(utc("2026-09-07T16:00:00")))

    def test_open_grace_and_five_minute_slots(self):
        self.assertIsNone(market_session(utc("2026-09-04T13:34:59")))
        first = market_session(utc("2026-09-04T13:35:00"))
        self.assertEqual(first["open"], utc("2026-09-04T13:30:00"))
        self.assertEqual(first["slot"], "2026-09-04:09:35")
        self.assertEqual(
            market_session(utc("2026-09-04T13:39:59"))["slot"], first["slot"]
        )
        self.assertEqual(market_session(utc("2026-09-04T13:40:00"))["slot"], "2026-09-04:09:40")
        self.assertEqual(market_session(utc("2026-09-04T14:29:59"))["slot"], "2026-09-04:10:25")
        self.assertEqual(
            market_session(utc("2026-09-04T14:30:00"))["slot"],
            "2026-09-04:10:30",
        )

    def test_daylight_saving_start(self):
        before = market_session(utc("2026-03-06T14:35:00"))
        after = market_session(utc("2026-03-09T13:35:00"))
        self.assertEqual(before["open"].hour, 14)
        self.assertEqual(after["open"].hour, 13)
        self.assertTrue(before["slot"].endswith(":09:35"))
        self.assertTrue(after["slot"].endswith(":09:35"))

    def test_daylight_saving_end(self):
        before = market_session(utc("2026-10-30T13:35:00"))
        after = market_session(utc("2026-11-02T14:35:00"))
        self.assertEqual(before["open"].hour, 13)
        self.assertEqual(after["open"].hour, 14)

    def test_early_close_uses_actual_close(self):
        regular = market_session(utc("2026-11-27T17:59:59"))
        self.assertEqual(regular["close"], utc("2026-11-27T18:00:00"))
        self.assertEqual(regular["slot"], "2026-11-27:12:55")
        closing = market_session(utc("2026-11-27T18:00:00"))
        self.assertEqual(closing["slot"], "2026-11-27:13:00:close")
        self.assertEqual(market_session(utc("2026-11-27T18:04:59"))["slot"], closing["slot"])
        self.assertEqual(market_session(utc("2026-11-27T18:05:00"))["slot"], "2026-11-27:13:05:close")
        self.assertEqual(market_session(utc("2026-11-27T18:20:00"))["slot"], "2026-11-27:13:20:close")
        self.assertIsNone(market_session(utc("2026-11-27T18:20:01")))
        self.assertIsNone(market_session(utc("2026-11-27T20:00:00")))

    def test_normal_close_has_five_minute_slots(self):
        self.assertEqual(
            market_session(utc("2026-09-04T19:59:59"))["slot"],
            "2026-09-04:15:55",
        )
        closing = market_session(utc("2026-09-04T20:00:00"))
        self.assertEqual(closing["slot"], "2026-09-04:16:00:close")
        self.assertEqual(market_session(utc("2026-09-04T20:04:59"))["slot"], closing["slot"])
        self.assertEqual(
            market_session(utc("2026-09-04T20:05:00"))["slot"],
            "2026-09-04:16:05:close",
        )
        self.assertEqual(market_session(utc("2026-09-04T20:20:00"))["slot"], "2026-09-04:16:20:close")
        self.assertIsNone(market_session(utc("2026-09-04T20:20:01")))

    def test_local_timezone_is_irrelevant(self):
        moment = utc("2026-09-04T14:35:00")
        self.assertEqual(
            market_session(moment),
            market_session(moment.astimezone(ZoneInfo("Asia/Hong_Kong"))),
        )

    def test_naive_datetime_rejected(self):
        with self.assertRaises(ValueError):
            market_session(datetime(2026, 9, 4, 14, 35))


if __name__ == "__main__":
    unittest.main()
