import copy
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import tempfile
import unittest

from market_context import load_context, render_context
from portfolio_report import bounce_evidence, reference_change, reference_table, refresh_context, render_report

NOW = datetime(2026, 9, 11, 2, tzinfo=timezone.utc)
CONTEXT = {"version": 1, "reviewed_at": (NOW-timedelta(hours=1)).isoformat(),
           "expires_at": (NOW+timedelta(hours=1)).isoformat(),
           "facts": [{"title": "Fact", "text": "<script>bad</script>", "as_of": "2026-09-10",
                      "publisher": "Source", "source": "https://example.org/fact"}],
           "events": [{"title": "Release", "at": (NOW+timedelta(minutes=30)).isoformat(),
                       "display_time": "Dated event", "source": "https://example.org/calendar"}]}

class ContextTests(unittest.TestCase):
    def load(self, data, now=NOW):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder)/"context.json"
            p.write_text(json.dumps(data))
            return load_context(p, now)

    def test_context_expiry_and_elapsed_event(self):
        data = self.load(CONTEXT)
        self.assertEqual(data["status"], "CURRENT")
        self.assertIn("Upcoming at report build", render_context(data, NOW))
        later = NOW+timedelta(hours=2)
        self.assertEqual(self.load(CONTEXT, later)["status"], "EXPIRED")
        rendered = render_context(data, later)
        self.assertIn("EXPIRED", rendered)
        self.assertIn("outcome not verified", rendered)

    def test_future_review_and_unsafe_source_rejected(self):
        data = copy.deepcopy(CONTEXT)
        data["reviewed_at"] = (NOW+timedelta(minutes=5)).isoformat()
        self.assertEqual(self.load(data)["status"], "UNAVAILABLE")
        data = copy.deepcopy(CONTEXT)
        data["facts"][0]["source"] = "javascript:alert(1)"
        self.assertEqual(self.load(data)["status"], "UNAVAILABLE")

    def test_missing_file_and_absent_context_are_explicit(self):
        self.assertEqual(load_context(None, NOW)["status"], "UNAVAILABLE")
        self.assertEqual(load_context("/nonexistent/context.json", NOW)["status"], "UNAVAILABLE")

    def test_context_text_is_escaped(self):
        text = render_context(self.load(CONTEXT), NOW)
        self.assertNotIn("<script>bad", text)
        self.assertIn("&lt;script&gt;", text)

class ReportTests(unittest.TestCase):
    def test_context_refresh_preserves_snapshot_and_advances_render_time(self):
        base = {'built_at': '2026-09-10T00:00:00+00:00', 'financial_snapshot_at': '2026-09-10T00:00:00+00:00',
                'rows': [{'symbol': 'X'}], 'histories': {'X': {'status': 'AVAILABLE'}},
                'portfolio_summary': {'metrics': {'total_value_usd': 4}}, 'context': {}, 'news_context': {}}
        context = copy.deepcopy(CONTEXT)
        with tempfile.TemporaryDirectory() as folder:
            c = Path(folder) / 'context.json'; c.write_text(json.dumps(context))
            refreshed = refresh_context(base, c, None, NOW)
        self.assertEqual(refreshed['financial_snapshot_at'], base['financial_snapshot_at'])
        self.assertEqual(refreshed['rows'], base['rows'])
        self.assertEqual(refreshed['histories'], base['histories'])
        self.assertEqual(refreshed['portfolio_summary'], base['portfolio_summary'])
        self.assertEqual(refreshed['built_at'], NOW.isoformat())
        self.assertEqual(refreshed['context']['status'], 'CURRENT')
        self.assertEqual(refreshed['news_context']['status'], 'UNAVAILABLE')

    def test_missing_latest_day_cannot_supply_rebound_levels(self):
        h = {"status": "AVAILABLE", "as_of": "2026-09-09", "expected_session": "2026-09-10",
             "bars": [{"low": 10, "close": 11, "high": 12, "date": "2026-09-09"}]}
        self.assertIn("unavailable", bounce_evidence(h))
        h["as_of"] = h["expected_session"]
        h["bars"][0]["date"] = h["as_of"]
        rendered = bounce_evidence(h)
        self.assertIn("10.00", rendered)
        self.assertIn("not a tested entry strategy", rendered)

    def test_valuation_quote_timestamp_is_visible(self):
        s = {"metrics": {"positions": [{"symbol": "SGOV", "currency": "USD",
             "quote": {"price": 100.5, "timestamp": "2026-09-10T20:00:24+00:00",
                       "closing_print_grace_used": True}}]}}
        text = reference_table(s)
        self.assertIn("20:00:24", text)
        self.assertIn("Delayed closing print", text)

    def test_live_reference_change_is_display_only_and_uses_completed_close(self):
        self.assertEqual(reference_change({'price': 10.62}, 10.37), '+2.41% vs completed close')
        self.assertEqual(reference_change({}, 10.37), 'Change unavailable')

    def test_dynamic_universe_partial_value_and_data_link(self):
        data = {"built_at": NOW.isoformat(), "financial_snapshot_at": NOW.isoformat(),
                "rows": [], "histories": {}, "configured_rule_count": 0,
                "portfolio_summary": {"complete": False, "reasons": ["Missing mark"],
                     "metrics": {"cash_by_currency": {}, "known_position_value_usd": 123.45,
                                 "known_cash_value_usd": 50, "valued_position_count": 0}}}
        page = render_report(data, "Europe/Lisbon", "custom-data.json")
        self.assertIn("0 securities: 0 confirmed holdings", page)
        self.assertIn("173.45", page)
        self.assertIn("Partial only", page)
        self.assertIn('href="custom-data.json"', page)
        self.assertIn('id="scenarios"', page)
        self.assertNotIn(" / 17</strong>", page)

    def test_news_is_rendered_at_the_report_timestamp(self):
        data = {"built_at": NOW.isoformat(), "financial_snapshot_at": NOW.isoformat(),
                "rows": [], "histories": {}, "configured_rule_count": 0,
                "portfolio_summary": {"complete": False, "reasons": [],
                    "metrics": {"cash_by_currency": {}, "known_position_value_usd": 0,
                                "known_cash_value_usd": 0, "valued_position_count": 0}},
                "news_context": {"version": 1, "status": "CURRENT", "model": "local",
                    "generated_at": (NOW-timedelta(minutes=1)).isoformat(),
                    "expires_at": (NOW+timedelta(minutes=1)).isoformat(), "analysis": {
                        "market_bias": "unclear", "summary": "Saved analysis", "drivers": [],
                        "scenarios": [], "watch_items": [], "limitations": []}, "sources": []}}
        self.assertIn('Saved analysis',render_report(data))

if __name__ == "__main__":
    unittest.main()
