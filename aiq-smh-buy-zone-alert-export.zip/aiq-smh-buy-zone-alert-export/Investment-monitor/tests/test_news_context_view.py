import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from news_context_view import load_news_analysis, news_analysis_text, render_news_analysis

NOW = datetime(2026, 9, 11, tzinfo=timezone.utc)


def sample(expires=None):
    return {"version": 1, "status": "CURRENT", "model": "local", "generated_at": (NOW-timedelta(hours=1)).isoformat(),
            "expires_at": (expires or NOW+timedelta(hours=1)).isoformat(), "analysis": {
                "market_bias": "risk_on", "summary": "<b>summary</b>",
                "drivers": [{"headline": "<script>x</script>", "reported_fact": "fact", "interpretation": "view", "source_ids": ["s1"]}],
                "scenarios": [], "watch_items": [], "limitations": []},
            "sources": [{"id": "s1", "url": "https://example.org/news", "title": "Example", "publisher": "Example", "scope": "market"}]}


class NewsViewTests(unittest.TestCase):
    def test_expiration_is_historical_and_hides_bias(self):
        data = load_news_analysis(self._write(sample(NOW-timedelta(minutes=1))), NOW)
        self.assertEqual(data["status"], "UNAVAILABLE")
        self.assertIn("HISTORICAL", render_news_analysis(data, NOW))
        self.assertNotIn("risk_on", news_analysis_text(data, NOW))

    def test_markup_and_unsafe_urls_are_safe(self):
        data = sample()
        data["sources"][0]["url"] = "javascript:alert(1)"
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "a.json"
            path.write_text(json.dumps(data))
            loaded = load_news_analysis(path, NOW)
        self.assertEqual(loaded["status"], "UNAVAILABLE")
        rendered = render_news_analysis(sample(), NOW)
        self.assertIn("&lt;script&gt;", rendered)
        self.assertNotIn("<script>", rendered)

    def test_missing_file(self):
        self.assertEqual(load_news_analysis("/nonexistent/news.json", NOW)["status"], "UNAVAILABLE")

    def test_duplicate_ids_and_invalid_arrays_rejected(self):
        data=sample();data['sources'].append(dict(data['sources'][0]))
        self.assertIn('unavailable',news_analysis_text(data,NOW).lower())
        data=sample();data['analysis']['drivers']=3
        self.assertIn('unavailable',news_analysis_text(data,NOW).lower())

    def test_direct_render_rejects_future_dates_and_skips_bad_links(self):
        data = sample()
        data["generated_at"] = (NOW + timedelta(minutes=1)).isoformat()
        self.assertIn("unavailable", news_analysis_text(data, NOW).lower())
        data = sample()
        data["sources"][0]["url"] = "javascript:alert(1)"
        rendered = render_news_analysis(data, NOW)
        self.assertNotIn("href='None'", rendered)
        self.assertNotIn("javascript:", rendered)

    def test_degraded_source_coverage_is_visible(self):
        data=sample();data['coverage']={'source_coverage':'DEGRADED','unavailable_sources':['bls-cpi']}
        rendered=render_news_analysis(data,NOW)
        self.assertIn('Source coverage: DEGRADED',rendered)
        self.assertIn('bls-cpi',rendered)

    def test_legacy_feed_statuses_also_show_degraded_coverage(self):
        data=sample();data['coverage']={'feed_statuses':{'fed':'AVAILABLE','bls-cpi':'UNAVAILABLE'}}
        self.assertIn('Source coverage: DEGRADED',render_news_analysis(data,NOW))

    def test_neutral_relevance_digest_is_explained(self):
        data=sample();data['analysis'].update(market_bias='unclear',drivers=[],scenarios=[],watch_items=[],
            summary='No relevant evidence met the threshold.')
        data['reason']='No analysis-quality portfolio or macro evidence; no model call made.'
        data['coverage']={'excluded_irrelevant':3,'excluded_low_quality':1,'topics':{}}
        rendered=render_news_analysis(data,NOW)
        self.assertIn('Deterministic relevance curation: 4 excluded',rendered)
        self.assertIn('Limited neutral digest',rendered)

    def test_rejected_model_response_uses_limited_digest_notice(self):
        data=sample();data['analysis'].update(market_bias='unclear',drivers=[],scenarios=[],watch_items=[])
        data['reason']='Local model response rejected by grounding checks; no model commentary was retained.'
        self.assertIn('Limited neutral digest',render_news_analysis(data,NOW))

    def _write(self, data):
        self.folder = tempfile.TemporaryDirectory()
        path = Path(self.folder.name) / "a.json"
        path.write_text(json.dumps(data))
        return path


if __name__ == "__main__":
    unittest.main()
