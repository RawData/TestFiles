"""Synthetic independently understandable market histories; no network/AI."""
import math
import unittest
from datetime import date, timedelta
from technical_analysis import analyze_daily, sma, ema, wilder_rsi, wilder_atr, confirmed_pivots, macd_series


def bars(closes, volume=100000):
    return [dict(date=(date(2025,1,1)+timedelta(days=i)).isoformat(),open=c,high=c+1,low=c-1,close=c,volume=volume)
            for i,c in enumerate(closes)]


def breakout_bars():
    # Gradually rising market, followed by two distinct higher lows and a breakout.
    c=[50+i*.1+math.sin(i*.6) for i in range(215)]
    c += [72,74,76,74,73,74,75,77,75,74,75,76,78.5]
    result=bars(c)
    for b in result: b["low"] -= 1  # Wider normal daily ranges, without an extended breakout.
    return result


class Indicators(unittest.TestCase):
    def test_sma_and_ema_known_sequence(self):
        self.assertEqual(sma([1,2,3,4,5],3),[None,None,2,3,4])
        self.assertEqual(ema([1,2,3,4,5],3),[None,None,2,3,4])

    def test_wilder_rsi_seed_and_smoothing(self):
        # gains 1,0,2 and losses 0,1,0 => RSI75; next loss2 => RSI42.857...
        got=wilder_rsi([10,11,10,12,10],3)
        self.assertAlmostEqual(got[3],75)
        self.assertAlmostEqual(got[4],42.857142857)
        self.assertEqual(wilder_rsi([10]*20)[-1],50)
        self.assertEqual(wilder_rsi(list(range(1,21)))[-1],100)
        self.assertEqual(wilder_rsi(list(range(21,1,-1)))[-1],0)

    def test_atr_includes_overnight_gap(self):
        b=bars([10,11,20,19])
        # true ranges: 2,2,10,2. seed3 =14/3 then Wilder =>34/9.
        self.assertAlmostEqual(wilder_atr(b,3)[2],14/3)
        self.assertAlmostEqual(wilder_atr(b,3)[3],34/9)

    def test_flat_macd(self):
        m,s,h=macd_series([50]*100)
        self.assertEqual((m[-1],s[-1],h[-1]),(0,0,0))

    def test_pivots_cannot_appear_before_confirmation(self):
        b=bars([10,11,15,12,11,10,9])
        self.assertEqual(confirmed_pivots(b[:4])['highs'],[])
        p=confirmed_pivots(b[:5])['highs'][0]
        self.assertEqual(p['index'],2)
        self.assertEqual(p['confirmed_on'],b[4]['date'])
        self.assertEqual(confirmed_pivots(b)['highs'][0],p)


class Decisions(unittest.TestCase):
    def test_lower_lows_downtrend_rejected_even_if_oversold(self):
        b=bars([150-i*.25+math.sin(i*.5)*2 for i in range(250)])
        r=analyze_daily(b)
        self.assertEqual(r['status'],'FAIL')
        self.assertTrue(r['metrics']['lower_low'])
        self.assertTrue(r['metrics']['lower_high'])
        self.assertLess(r['metrics']['sma50_slope'],0)
        self.assertEqual(analyze_daily(b,live_price=200)['status'],'FAIL')

    def test_uptrend_needs_confirmed_structure(self):
        r=analyze_daily(bars([50+i*.1 for i in range(250)]))
        self.assertEqual(r['status'],'WAIT')
        self.assertIsNone(r['metrics']['higher_low'])

    def test_bullish_breakout_then_live_loss(self):
        b=breakout_bars()
        r=analyze_daily(b)
        self.assertEqual(r['status'],'PASS',r['reasons'])
        self.assertEqual(analyze_daily(b,live_price=50)['status'],'FAIL')
        self.assertEqual(analyze_daily(b,live_price=r['metrics']['breakout_level'])['status'],'WAIT')
        self.assertEqual(r['daily_status'],'PASS')

    def test_live_extension_cannot_keep_a_pass(self):
        self.assertEqual(analyze_daily(breakout_bars(),live_price=90)['status'],'WAIT')

    def test_low_volume_blocks_passing_structure(self):
        b=breakout_bars();b[-1]['volume']=1
        self.assertEqual(analyze_daily(b)['status'],'WAIT')
        self.assertEqual(analyze_daily(bars([30]*250,0))['status'],'UNAVAILABLE')

    def test_insufficient_invalid_and_duplicate_history_fail_closed(self):
        self.assertEqual(analyze_daily(bars([30]*50))['status'],'UNAVAILABLE')
        for change in ({'close':float('nan')},{'low':100},{'volume':-1},{'date':'not-a-date'}):
            b=bars([30]*250);b[-1].update(change)
            self.assertEqual(analyze_daily(b)['status'],'UNAVAILABLE')
        b=bars([30]*250);b[-1]['date']=b[-2]['date']
        self.assertEqual(analyze_daily(b)['status'],'UNAVAILABLE')

    def test_nav_cannot_get_equity_pass(self):
        self.assertEqual(analyze_daily(breakout_bars(),policy={'mode':'nav_review'})['status'],'NOT_APPLICABLE')
        self.assertEqual(analyze_daily(breakout_bars(),policy={'mode':'typo'})['status'],'UNAVAILABLE')

    def test_invalid_live_quote_cannot_retain_pass(self):
        for price in [0,-1,float('nan'),float('inf')]:
            self.assertEqual(analyze_daily(breakout_bars(),live_price=price)['status'],'UNAVAILABLE')
