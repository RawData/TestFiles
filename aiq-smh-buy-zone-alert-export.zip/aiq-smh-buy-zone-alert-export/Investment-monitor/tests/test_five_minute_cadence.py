"""Each five-minute slot fetches again without repeating unchanged entry alerts."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import unittest
from unittest.mock import Mock

from market_clock import extended_market_session, market_session
from monitor import DEFAULT_CONFIG, Quote, load_config, observe, run_cycle


def utc(value):
    return datetime.fromisoformat(value).replace(tzinfo=timezone.utc)


class FiveMinuteCycleTests(unittest.TestCase):
    def test_refetch_every_five_minutes_in_each_stream_without_duplicate_alerts(self):
        scenarios = [
            ('US regular', 'US', 'regular', '2026-09-08T14:35:00', '2026-09-08T14:20:00'),
            ('HK afternoon', 'HK', 'regular', '2026-09-08T06:05:00', '2026-09-08T05:50:00'),
            ('US pre-market', 'US', 'pre', '2026-09-08T12:05:00', '2026-09-08T11:50:00'),
            ('US after-hours', 'US', 'post', '2026-09-08T21:05:00', '2026-09-08T20:50:00'),
            ('US closing', 'US', 'regular', '2026-09-08T20:05:00', '2026-09-08T19:59:00'),
            ('HK closing', 'HK', 'regular', '2026-09-08T08:10:00', '2026-09-08T08:09:00'),
            ('US after-hours closing', 'US', 'post', '2026-09-09T00:05:00', '2026-09-08T23:59:00'),
        ]
        for name, market, phase, first, stamp in scenarios:
            with self.subTest(name=name):
                now=utc(first); timestamp=utc(stamp)
                c=load_config(DEFAULT_CONFIG)
                rule={'symbol':'3419.HK','market':'HK','currency':'HKD','low':'9.15','high':'9.40'} if market=='HK' else {'symbol':'AIQ','low':'48.13','high':'55.68'}
                c['watchlist']=[rule]; c['alerts']['mac']=True; c['alerts']['email']['enabled']=False
                q=Quote(rule['symbol'],Decimal('9.30' if market=='HK' else '52'),timestamp,
                        rule.get('currency','USD'),phase=phase)
                fetch=Mock(return_value=q);send=Mock();state={'version':1,'symbols':{}}
                key='symbols' if phase=='regular' else phase+'_symbols'
                def session(t):
                    return market_session(t,market) if phase=='regular' else extended_market_session(t,market)
                def check(t):
                    return run_cycle(c,state,t,{market:session(t)},fetcher=fetch,sender=send,state_key=key)
                self.assertEqual(check(now),0)
                self.assertEqual(check(now+timedelta(minutes=2)),0)
                self.assertEqual(fetch.call_count,1)
                self.assertEqual(check(now+timedelta(minutes=5)),0)
                self.assertEqual(fetch.call_count,2)
                self.assertEqual(send.call_count,1)
                self.assertIsNone(state[key][rule['symbol']]['pending'])
                self.assertEqual(state[key][rule['symbol']]['status'],'inside')

    def test_existing_hourly_observation_does_not_realert_when_cadence_changes(self):
        now=utc('2026-09-08T14:35:00')
        c=load_config(DEFAULT_CONFIG);rule={'symbol':'AIQ','low':'48.13','high':'55.68'}
        c['watchlist']=[rule];c['alerts']['mac']=True;c['alerts']['email']['enabled']=False
        q=Quote('AIQ',Decimal('52'),now-timedelta(minutes=1))
        prior=observe(None,q,rule,'2026-09-08:10:30',[],now-timedelta(minutes=5))
        self.assertIsNone(prior['pending'])
        state={'version':1,'symbols':{'AIQ':deepcopy(prior)}}
        fetch=Mock(return_value=q);send=Mock()
        self.assertEqual(run_cycle(c,state,now,{'US':market_session(now)},fetcher=fetch,sender=send),0)
        fetch.assert_called_once_with('AIQ');send.assert_not_called()
        self.assertEqual(state['symbols']['AIQ']['last_slot'],'2026-09-08:10:35')
        self.assertEqual(state['symbols']['AIQ']['zone_key'],prior['zone_key'])


if __name__=='__main__':unittest.main()
