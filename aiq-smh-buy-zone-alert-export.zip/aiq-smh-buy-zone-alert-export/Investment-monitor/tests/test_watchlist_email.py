"""Rendering checks: truthful timestamps, full coverage and safe email markup."""

from copy import deepcopy
from html.parser import HTMLParser
import unittest

from watchlist_email import render_report


class Tags(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []
        self.attributes = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        self.attributes.extend(attrs)


class WatchlistEmailTests(unittest.TestCase):
    def report(self):
        return {
            "session_date": "2026-09-09", "generated_at": "2026-09-09T13:02:03+00:00",
            "scheduled_at": "2026-09-09T13:00:00+00:00", "market_open": "2026-09-09T13:30:00+00:00",
            "research_as_of": "2026-09-08", "previous_session_date": "2026-09-08",
            "rows": [{"symbol": "FISV", "currency": "USD", "holding": False,
                      "price": "51.42", "quote_time": "2026-09-09T13:01:00+00:00",
                      "quote_label": "pre-market chart bar", "zone_low": "49.50", "zone_high": "51.50",
                      "zone_status": "inside", "entry": "49.50–51.50", "tp": "58–60",
                      "stop": "Review weekly close below 47", "assessment": "Conditional candidate",
                      "comments": "Wait for support", "gate": "Verify no guidance cut",
                      "research_date": "2026-09-07",
                      "technical": {"status": "FAIL", "as_of": "2026-09-08",
                                    "reasons": ["Close below support", "Lower lows"],
                                    "metrics": {"sma50": 52.19, "higher_low": False}, "live_quote_valid": True},
                      "change": "WAIT → FAIL; above → inside"}],
        }

    def test_dates_and_current_quote_separate_from_saved_research(self):
        subject, plain, html = render_report(self.report())
        self.assertIn("2026-09-09 NY", subject)
        for output in (plain, html):
            self.assertIn("2026-09-09 09:02:03 EDT", output)
            self.assertIn("2026-09-09 09:00:00 EDT", output)
            self.assertIn("2026-09-09 09:30:00 EDT", output)
            self.assertIn("2026-09-09 09:01:00 EDT", output)
            self.assertIn("Completed daily session: 2026-09-08", output)
            self.assertIn("2026-09-07", output)
            self.assertIn("USD 51.42", output)
            self.assertIn("pre-market chart bar", output)

    def test_winter_times_follow_new_york_dst(self):
        report = self.report()
        report["generated_at"] = "2026-12-09T14:00:00Z"
        self.assertIn("2026-12-09 09:00:00 EST", render_report(report)[1])

    def test_missing_quote_never_uses_research_close_or_claims_inside(self):
        report = self.report()
        row = report["rows"][0]
        row.update(price=None, quote_time=None, quote_error="No fresh pre-market trade", close=987654)
        row["technical"]["live_quote_valid"] = False
        for output in render_report(report)[1:]:
            self.assertIn("1 prices unavailable", output)
            self.assertIn("0 inside saved zones", output)
            self.assertIn("price unavailable", output)
            self.assertNotIn("987654", output)
            self.assertIn("No fresh pre-market trade", output)
            self.assertIn("Daily-only", output)

    def test_all_64_rows_present_and_account_metadata_excluded(self):
        report = self.report()
        base = report["rows"][0]
        report["rows"] = [dict(deepcopy(base), symbol=f"TEST{i:02}", holding=(i == 0),
                               shares="PRIVATE_SHARES", cost="PRIVATE_COST", account="PRIVATE_ACCOUNT")
                          for i in range(64)]
        _, plain, html = render_report(report)
        self.assertIn("64 tickers", plain)
        self.assertIn("64 FAIL", html)
        for output in (plain, html):
            for i in range(64):
                self.assertIn(f"TEST{i:02}", output)
            for secret in ("PRIVATE_SHARES", "PRIVATE_COST", "PRIVATE_ACCOUNT"):
                self.assertNotIn(secret, output)
            self.assertIn("TEST00 · Held", output)

    def test_escapes_all_dynamic_text_and_subject_newlines(self):
        report = self.report()
        payload = '<script>alert("bad")</script><img src=x onerror="bad">&'
        report["session_date"] = payload + "\r\nBcc: attacker"
        for key in ("symbol", "currency", "price", "entry", "tp", "stop", "assessment", "comments", "gate", "quote_label", "quote_error", "quote_time", "change", "research_date", "zone_low", "zone_high"):
            report["rows"][0][key] = payload
        report["rows"][0]["technical"]["reasons"] = [payload]
        subject, plain, html = render_report(report)
        parsed = Tags()
        parsed.feed(html)
        self.assertNotIn("script", parsed.tags)
        self.assertNotIn("img", parsed.tags)
        self.assertFalse(any(name.startswith("on") for name, _ in parsed.attributes))
        self.assertNotIn("\r", subject)
        self.assertNotIn("\n", subject)
        self.assertIn("&lt;script&gt;", html)
        self.assertIn(payload, plain)

    def test_pass_does_not_become_buy_recommendation(self):
        report = self.report()
        report["rows"][0]["technical"]["status"] = "PASS"
        for output in render_report(report)[1:]:
            self.assertIn("checks met; watchlist only", output)
            self.assertIn("did not establish a consistent buying advantage", output)
            self.assertIn("not freshly revalidated fundamentals", output)

    def test_unknown_missing_and_nav_technical_are_visible(self):
        report = self.report()
        report["rows"] = [{"symbol": "MISSING"}, {"symbol": "UNKNOWN", "technical": {"status": "BOGUS"}},
                          {"symbol": "SGOV", "technical": {"status": "NOT_APPLICABLE"}}]
        _, plain, html = render_report(report)
        for output in (plain, html):
            self.assertIn("2 UNAVAILABLE", output)
            self.assertIn("1 NOT_APPLICABLE", output)
            self.assertIn("manual NAV/risk review", output)
            self.assertIn("Indicator values unavailable", output)

    def test_changes_are_highlighted_and_first_report_is_not_change(self):
        report = self.report()
        _, plain, html = render_report(report)
        self.assertIn("FISV: WAIT → FAIL; above → inside", plain)
        self.assertIn("background:#fff9e9", html)
        report["previous_session_date"] = None
        report["rows"][0]["change"] = "First report; no comparison"
        _, plain, html = render_report(report)
        self.assertIn("No previous delivered report to compare", plain)
        self.assertNotIn("background:#fff9e9", html)
        report["previous_session_date"] = "2026-09-08"
        report["rows"][0]["change"] = "No change"
        self.assertIn("No reported technical grade", render_report(report)[1])
        report["rows"][0]["change"] = "No technical grade or saved-zone/plan change"
        self.assertNotIn("background:#fff9e9", render_report(report)[2])

    def test_at_or_below_is_not_rendered_as_zero_width_range(self):
        report = self.report()
        row = report["rows"][0]
        row.update(trigger="at_or_below", zone_low="47", zone_high="47")
        for output in render_report(report)[1:]:
            self.assertIn("USD ≤47", output)
            self.assertNotIn("47–47", output)

    def test_missing_research_warning_is_prominent_and_escaped(self):
        report = self.report()
        report["research_warning"] = "Saved research unavailable <check file>"
        _, plain, html = render_report(report)
        self.assertIn("RESEARCH DATA WARNING", plain.splitlines()[1])
        self.assertIn("Research data warning:", html)
        self.assertIn("&lt;check file&gt;", html)

    def test_plain_and_html_both_include_all_conditions_and_indicators(self):
        for output in render_report(self.report())[1:]:
            for value in ("Close below support", "Lower lows", "SMA50: 52.19", "Higher low: no",
                          "Conditional candidate", "Wait for support", "Verify no guidance cut",
                          "Review weekly close below 47", "58–60"):
                self.assertIn(value, output)

    def test_empty_and_bad_rows(self):
        self.assertIn("0 tickers", render_report({"rows": []})[1])
        with self.assertRaises(TypeError):
            render_report({"rows": ["bad"]})

    def test_renderer_does_not_mutate_report(self):
        report = self.report()
        before = deepcopy(report)
        render_report(report)
        self.assertEqual(before, report)

    def test_compact_body_retains_all_quotes_dates_levels_but_links_to_attachment(self):
        report = self.report()
        report["rows"] = [dict(deepcopy(report["rows"][0]), symbol=f"SYMBOL{i:02}") for i in range(64)]
        subject, plain, html = render_report(report, include_details=False)
        for output in (plain, html):
            self.assertIn("Full technical evidence and saved review conditions are in the attached HTML report.", output)
            self.assertIn("2026-09-09 09:01:00 EDT", output)
            self.assertIn("pre-market chart bar", output)
            self.assertIn("2026-09-08", output)
            self.assertIn("58–60", output)
            self.assertIn("Review weekly close below 47", output)
            for i in range(64):
                self.assertIn(f"SYMBOL{i:02}", output)
            self.assertNotIn("Close below support", output)
        self.assertEqual(subject, render_report(report)[0])
        self.assertLess(len(html.encode()), 100_000)

    def test_candle_signals_are_visible_in_compact_and_detailed_email(self):
        report = self.report()
        report['rows'][0]['buy_sell_signals'] = {
            'status': 'BUY', 'scope': 'Completed regular-session candles; not an order.',
            'timeframes': {
                '15m': {'status': 'BUY', 'as_of': '2026-09-09T15:00:00+00:00',
                        'last_event': {'direction': 'BUY', 'confirmed_at': '2026-09-09T15:00:00+00:00'}},
                '1h': {'status': 'PENDING_BUY', 'as_of': '2026-09-09T15:30:00+00:00',
                       'pending': {'setup_at': '2026-09-09T15:30:00+00:00', 'break_mid': 51.25}},
                  '1d': {'status': 'NONE', 'as_of': '2026-09-08T20:00:00+00:00',
                      'last_event': {'direction': 'SELL', 'confirmed_at': '2026-09-05T20:00:00+00:00'}},
            },
        }
        subject, compact, compact_html = render_report(report, include_details=False)
        self.assertIn('1 BUY, 0 SELL candle signals', subject)
        for output in (compact, compact_html):
            self.assertIn('Candle signals', output)
            self.assertIn('15m: BUY', output)
            self.assertIn('1h: PENDING_BUY', output)
            self.assertIn('1d: NONE', output)
            self.assertIn('last SELL', output)
            self.assertIn('mechanical', output)
        _, detailed, detailed_html = render_report(report)
        for output in (detailed, detailed_html):
            self.assertIn('15m candle signal', output)
            self.assertIn('last BUY confirmed', output)
            self.assertIn('awaiting next candle', output)
            self.assertIn('51.25', output)

    def investment_report(self):
        report = self.report()
        report["portfolio_summary"] = {
            "status": "REVIEW", "complete": False, "as_of": "2026-09-09",
            "checked_at": "2026-09-10T13:00:00Z", "confirmed_at": "2026-09-10T06:00:00Z",
            "reasons": ["One holding price is unavailable"],
            "metrics": {"total_value_usd": None, "cash_by_currency": {"USD": 88.35, "HKD": 3236.03},
                        "converted_cash_usd": 503.23, "position_count": 17,
                        "largest_positions": [{"symbol": "CSV", "position_weight_pct": 4.25}]}}
        report["rows"][0]["investment"] = {
            "overall": "REVIEW",
            "nav": {"status": "REVIEW", "as_of": "2026-09-09", "fetched_at": "2026-09-10T12:55:00Z",
                    "reasons": ["Price and NAV timestamps do not match"],
                    "metrics": {"nav": 50.8, "currency": "USD", "price_vs_dated_nav_pct": 1.22,
                                "official_close": 51.01, "official_close_date": "2026-09-09"},
                    "sources": [{"label": "Official issuer", "url": "https://issuer.example/nav"}]},
            "fundamentals": {"status": "REVIEW", "as_of": "2025-12-31", "filed_at": "2026-02-25",
                             "fetched_at": "2026-09-10T12:54:00Z", "reasons": ["Newer quarterly filing exists"],
                             "metrics": {"revenue": 1200000, "net_income": -13000, "revenue_growth_pct": -3.2},
                             "facts": {"revenue": {"value": 1200000, "unit": "USD", "end": "2025-12-31", "tag": "Revenue"}},
                             "unverified": ["Customer retention not parsed"],
                             "sources": ["https://data.sec.gov/submissions/CIK0000000001.json"]},
            "portfolio": {"status": "REVIEW", "as_of": "2026-09-09", "reasons": ["Limits unset"],
                          "metrics": {"position_weight_pct": 4.25, "position_value_usd": 1234.5,
                                      "position_quantity": 25, "proposed_addition": None}},
            "arora": {"status": "UNAVAILABLE", "as_of": "2026-09-06", "fetched_at": None,
                      "reasons": ["Arora not refreshed"], "unverified": ["Current Arora model and capsule"]}}
        return report

    def test_investment_compact_status_weight_and_portfolio_totals_have_limits(self):
        _, plain, html = render_report(self.investment_report(), include_details=False)
        for output in (plain, html):
            for text in ("Investment: REVIEW", "NAV: REVIEW", "Financials: REVIEW",
                         "Exposure: REVIEW", "Arora: UNAVAILABLE", "Weight: 4.25%", "Partial / incomplete",
                         "Cash balances by original currency", "USD: 88.35", "HKD: 3,236.03", "503.23",
                         "One holding price is unavailable", "risk limits are unset", "suitability endorsement",
                         "Full technical and investment evidence"):
                self.assertIn(text, output)
            self.assertNotIn("Annual filing facts and units", output)
            self.assertNotIn("not freshly revalidated fundamentals", output)

    def test_full_investment_distinguishes_annual_period_from_fetch_and_nav_basis(self):
        for output in render_report(self.investment_report())[1:]:
            for text in ("Evidence as of: 2025-12-31", "filed: 2026-02-25", "2026-09-10 08:54:00 EDT",
                         "Dated NAV: 50.8", "Indicative price vs dated NAV (%): 1.22",
                         "Annual revenue (USD): 1,200,000", "Annual net income (USD): -13,000",
                         "Comparable annual revenue growth (%): -3.2", "Annual filing facts and units",
                         "Customer retention not parsed", "Newer quarterly filing exists",
                         "Partial SEC annual and supported latest 10-Q fiscal YTD checks", "guidance", "valuation are not verified",
                         "https://issuer.example/nav", "https://data.sec.gov/submissions/CIK0000000001.json",
                         "Arora recommendations have not been refreshed", "Position quantity: 25",
                         "Position value (USD): 1,234.5", "Proposed addition: None specified; exposure only"):
                self.assertIn(text, output)
            self.assertNotIn("Verified same-close premium/discount", output)

    def test_current_period_keeps_ytd_and_annual_separate(self):
        report = self.investment_report()
        report["rows"][0]["investment"]["fundamentals"]["current_period"] = {
            "status": "REVIEW", "period_start": "2026-01-01", "as_of": "2026-06-30", "filed_at": "2026-08-01",
            "scope": "Fiscal YTD; not a standalone quarter", "metrics": {"revenue": 700000},
            "reasons": ["Current YTD cash flow is negative"], "facts": {},
            "free_cash_flow_basis": "PP&E payments only; software is not deducted"}
        for output in render_report(report)[1:]:
            for text in ("Annual revenue (USD): 1,200,000", "Latest fiscal YTD values", "700,000",
                         "2026-01-01 to 2026-06-30", "filed 2026-08-01", "software is not deducted"):
                self.assertIn(text, output)

    def test_missing_investment_data_and_missing_weight_are_not_zero_or_pass(self):
        report = self.investment_report()
        report["rows"][0]["investment"] = {"portfolio": {"metrics": {"position_weight_pct": None}}}
        report["rows"].append({"symbol": "MISSING"})
        report["portfolio_summary"] = None
        for output in render_report(report)[1:]:
            self.assertIn("Weight: unavailable", output)
            self.assertIn("Investment checks: unavailable", output)
            self.assertIn("NAV: UNAVAILABLE", output)
            self.assertIn("portfolio totals and weights are not assumed", output)
            self.assertNotIn("Weight: 0%", output)
        report["rows"][0]["investment"]["portfolio"]["metrics"]["position_weight_pct"] = 0
        self.assertIn("Weight: 0%", render_report(report)[1])

    def test_individual_nav_pass_does_not_promote_overall_review_or_technical_na(self):
        report = self.investment_report()
        row = report["rows"][0]
        row["technical"]["status"] = "NOT_APPLICABLE"
        row["investment"]["nav"]["status"] = "PASS"
        row["investment"]["nav"]["metrics"]["premium_discount_pct"] = -1.2
        for output in render_report(report)[1:]:
            self.assertIn("NAV: PASS", output)
            self.assertIn("Investment: REVIEW", output)
            self.assertIn("equity chart filter does not apply", output)
            self.assertIn("Verified same-close premium/discount (%): -1.2", output)
            self.assertNotIn("manual NAV/risk review", output)

    def test_investment_sources_metrics_and_summary_are_escaped(self):
        report = self.investment_report()
        attack = '<img src=x onerror="run()"><script>run()</script>'
        report["portfolio_summary"]["reasons"] = [attack]
        report["portfolio_summary"]["metrics"]["largest_positions"] = [{"symbol": attack}]
        report["rows"][0]["investment"]["nav"].update(status=attack, sources=[{"label": attack, "url": attack}])
        report["rows"][0]["investment"]["fundamentals"]["facts"] = {attack: {"unit": attack}}
        _, plain, html = render_report(report)
        parsed = Tags(); parsed.feed(html)
        self.assertNotIn("script", parsed.tags)
        self.assertNotIn("img", parsed.tags)
        self.assertIn("&lt;img", html)
        self.assertIn(attack, plain)

    def test_64_enriched_compact_rows_stay_complete_and_bounded(self):
        report = self.investment_report()
        base = report["rows"][0]
        report["rows"] = [dict(deepcopy(base), symbol=f"INV{i:02}") for i in range(64)]
        _, plain, html = render_report(report, include_details=False)
        for i in range(64):
            self.assertIn(f"INV{i:02}", plain)
            self.assertIn(f"INV{i:02}", html)
        self.assertLess(len(html.encode()), 100_000)


if __name__ == "__main__":
    unittest.main()
