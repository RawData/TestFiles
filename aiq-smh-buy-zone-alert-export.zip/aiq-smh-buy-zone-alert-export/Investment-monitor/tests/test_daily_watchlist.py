import copy
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import smtplib
import tempfile
import unittest
from unittest.mock import Mock, patch

import daily_watchlist as d
import install_daily_watchlist as installer

NOW = datetime(2026, 9, 9, 13, 0, tzinfo=timezone.utc)
CONFIG = {"alerts": {"email": {"enabled": True, "to": ["a@example.test", "b@example.test"],
                                "from": "from@example.test", "username": "from@example.test"}},
          "watchlist": [{"symbol": "CSV", "low": "32", "high": "34"}], "max_quote_age_seconds": 1200}


def report(now=NOW):
    return {"session_date": "2026-09-09", "generated_at": now.isoformat(),
            "scheduled_at": NOW.isoformat(), "market_open": (NOW+timedelta(minutes=30)).isoformat(),
            "research_as_of": "2026-09-08", "rows": [{"symbol": "CSV", "currency": "USD",
            "price": "33", "quote_time": now.isoformat(), "zone_low": "32", "zone_high": "34",
            "zone_status": "inside", "entry": "32–34", "tp": "38", "stop": "Review <31",
            "technical": {"status": "FAIL", "as_of": "2026-09-08", "reasons": ["Lower lows"]}}]}


class ScheduleTests(unittest.TestCase):
    def test_due_window_boundaries(self):
        self.assertFalse(d.schedule(NOW-timedelta(seconds=1))["due"])
        self.assertTrue(d.schedule(NOW)["due"])
        self.assertTrue(d.schedule(NOW+timedelta(minutes=24, seconds=59))["due"])
        self.assertFalse(d.schedule(NOW+timedelta(minutes=25))["due"])
        self.assertFalse(d.schedule(NOW+timedelta(minutes=30))["due"])

    def test_weekend_and_exchange_holiday_skip(self):
        for day in (5,6,7):
            self.assertEqual(d.schedule(NOW.replace(day=day))["phase"], "closed")

    def test_dst_and_early_close_days(self):
        winter = datetime(2026,11,27,14,0,tzinfo=timezone.utc)
        summer = datetime(2026,7,2,13,0,tzinfo=timezone.utc)
        self.assertTrue(d.schedule(winter)["due"])
        self.assertTrue(d.schedule(summer)["due"])
        self.assertFalse(d.schedule(winter-timedelta(hours=1))["due"])
        self.assertTrue(d.schedule(datetime(2026,3,6,14,tzinfo=timezone.utc))["due"])
        self.assertTrue(d.schedule(datetime(2026,3,9,13,tzinfo=timezone.utc))["due"])

    def test_naive_rejected_and_next_session_after_holiday(self):
        with self.assertRaises(ValueError):d.schedule(datetime(2026,9,9,9))
        self.assertEqual(d.next_scheduled(datetime(2026,9,4,15,tzinfo=timezone.utc)), "2026-09-08T13:00:00+00:00")


class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.home=Path(self.temp.name);self.config=copy.deepcopy(CONFIG)
        self.collector=Mock(return_value=report());self.sender=Mock()

    def run_digest(self, clock=lambda: NOW):
        return d.run_due(self.config,Path('unused'),self.home,clock=clock,collector=self.collector,sender=self.sender)

    def state(self):return json.loads((self.home/'daily-watchlist/state.json').read_text())

    def test_sends_once_per_recipient_and_reuses_completed_day(self):
        self.assertEqual(self.run_digest(),0);self.assertEqual(self.sender.call_count,2)
        self.assertEqual(self.run_digest(),0);self.assertEqual(self.sender.call_count,2)
        self.assertEqual(self.collector.call_count,1)
        self.assertEqual(self.state()['last_complete_session'],'2026-09-09')

    def test_only_failed_recipient_retried_using_same_snapshot(self):
        self.sender.side_effect=[None,RuntimeError('failure')]
        self.assertEqual(self.run_digest(),1)
        self.sender.side_effect=None
        self.assertEqual(self.run_digest(),0)
        self.assertEqual([c.args[0] for c in self.sender.call_args_list],['a@example.test','b@example.test','b@example.test'])
        self.assertEqual(self.collector.call_count,1)

    def test_uncertain_send_is_not_duplicated(self):
        self.sender.side_effect=[d.DeliveryUncertain('lost ack'),None]
        self.assertEqual(self.run_digest(),1)
        self.sender.side_effect=None
        self.assertEqual(self.run_digest(),1)
        self.assertEqual(self.sender.call_count,2)
        self.assertEqual(self.state()['days']['2026-09-09']['recipients']['a@example.test']['status'],'uncertain')

    def test_interrupted_inflight_send_stays_uncertain(self):
        self.run_digest()
        state=self.state();state['days']['2026-09-09']['recipients']['a@example.test']['status']='sending'
        d.atomic_json(self.home/'daily-watchlist/state.json',state)
        self.assertEqual(self.run_digest(),1);self.assertEqual(self.sender.call_count,2)

    def test_no_send_outside_window_and_no_state_creation(self):
        self.assertEqual(self.run_digest(clock=lambda:NOW+timedelta(hours=1)),0)
        self.sender.assert_not_called();self.collector.assert_not_called()
        self.assertFalse((self.home/'daily-watchlist/state.json').exists())

    def test_slow_collection_cannot_send_after_cutoff(self):
        current=[NOW]
        def slow(*args,**kwargs):current[0]+=timedelta(minutes=26);return report(current[0])
        self.collector.side_effect=slow
        self.assertEqual(self.run_digest(clock=lambda:current[0]),1)
        self.sender.assert_not_called()

    def test_recipient_removed_during_retry_not_contacted(self):
        self.sender.side_effect=[None,RuntimeError('failure')];self.run_digest()
        self.config['alerts']['email']['to']=['a@example.test'];self.sender.side_effect=None
        self.assertEqual(self.run_digest(),0);self.assertEqual(self.sender.call_count,2)

    def test_email_disabled_does_not_collect_or_send(self):
        self.config['alerts']['email']['enabled']=False
        self.assertEqual(self.run_digest(),1);self.sender.assert_not_called();self.collector.assert_not_called()

    def test_corrupt_state_fails_closed(self):
        p=self.home/'daily-watchlist/state.json';p.parent.mkdir();p.write_text('{broken')
        with self.assertRaises(ValueError):self.run_digest()
        self.sender.assert_not_called()


class CollectionTests(unittest.TestCase):
    def test_fresh_pre_market_price_is_used_for_zone_and_technical_check(self):
        stamp=int((NOW-timedelta(minutes=1)).timestamp())
        payload={'chart':{'result':[{'meta':{'symbol':'CSV','currency':'USD','exchangeTimezoneName':'America/New_York','dataGranularity':'1m'},
                  'timestamp':[stamp],'indicators':{'quote':[{'close':[33.25]}]}}]}}
        evaluator=Mock(return_value={'status':'WAIT','metrics':{},'as_of':'2026-09-08','reasons':[]})
        r=d.collect_report(CONFIG,Path('missing'),Path('.'),NOW,fetcher=Mock(return_value=payload),evaluator=evaluator,clock=lambda:NOW)
        row=r['rows'][0]
        self.assertEqual(row['price'],'33.25');self.assertEqual(row['zone_status'],'inside')
        self.assertTrue(row['technical']['live_quote_valid']);self.assertEqual(evaluator.call_args.args[1]['price'],'33.25')

    def test_recent_hk_close_is_labelled_historical_and_not_passed_as_live(self):
        config=copy.deepcopy(CONFIG);config['watchlist']=[{'symbol':'3419.HK','market':'HK','currency':'HKD','low':'9','high':'10'}]
        close=NOW.replace(hour=8,minute=8)
        payload={'chart':{'result':[{'meta':{'symbol':'3419.HK','currency':'HKD','exchangeTimezoneName':'Asia/Hong_Kong',
                    'regularMarketTime':int(close.timestamp()),'regularMarketPrice':9.5}}]}}
        evaluator=Mock(return_value={'status':'WAIT','metrics':{},'as_of':'2026-09-09','reasons':[]})
        r=d.collect_report(config,Path('missing'),Path('.'),NOW,fetcher=Mock(return_value=payload),evaluator=evaluator,clock=lambda:NOW)
        row=r['rows'][0];self.assertEqual(row['price'],'9.5');self.assertIn('completed-session',row['quote_label'])
        self.assertFalse(row['technical']['live_quote_valid']);self.assertEqual(evaluator.call_args.args[1],{})
        payload['chart']['result'][0]['meta']['regularMarketTime']-=86400
        r=d.collect_report(config,Path('missing'),Path('.'),NOW,fetcher=Mock(return_value=payload),evaluator=evaluator,clock=lambda:NOW)
        self.assertIsNone(r['rows'][0]['price'])

    def test_quote_expiring_during_collection_cannot_remain_current_pass(self):
        stamp=int((NOW-timedelta(minutes=10)).timestamp())
        payload={'chart':{'result':[{'meta':{'symbol':'CSV','currency':'USD','exchangeTimezoneName':'America/New_York','dataGranularity':'1m'},
                  'timestamp':[stamp],'indicators':{'quote':[{'close':[33.25]}]}}]}}
        evaluator=Mock(return_value={'status':'PASS','metrics':{},'as_of':'2026-09-08','reasons':[]})
        clock=Mock(side_effect=[NOW,NOW,NOW+timedelta(minutes=15)])
        r=d.collect_report(CONFIG,Path('missing'),Path('.'),NOW,fetcher=Mock(return_value=payload),evaluator=evaluator,clock=clock)
        row=r['rows'][0];self.assertIsNone(row['price']);self.assertEqual(row['technical']['status'],'UNAVAILABLE')

    def test_unavailable_quote_does_not_become_old_research_price(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'research.json';p.write_text(json.dumps({'asOf':'2026-09-08','rows':[{'ticker':'CSV','close':999,'entry':'32–34','tp':'38','stop':'Review31'}]}))
            evaluator=Mock(return_value={'status':'FAIL','as_of':'2026-09-08','metrics':{},'reasons':['lower lows']})
            r=d.collect_report(CONFIG,p,Path(temp),NOW,fetcher=Mock(side_effect=ValueError('stale')),evaluator=evaluator,clock=lambda:NOW)
            row=r['rows'][0];self.assertIsNone(row['price']);self.assertEqual(row['zone_status'],'unavailable')
            self.assertEqual(row['technical']['status'],'FAIL');self.assertFalse(row['technical']['live_quote_valid'])
            self.assertEqual(evaluator.call_args.args[1],{});self.assertEqual(row['entry'],'32–34')

    def test_changes_compare_previous_report_not_five_minute_observation(self):
        prior=report()['rows'][0];new=copy.deepcopy(prior);new['technical']['status']='WAIT';new['zone_status']='above'
        self.assertIn('FAIL -> WAIT',d.changes(new,prior));self.assertIn('inside -> above',d.changes(new,prior))

    def test_investment_data_added_without_current_quote_or_sending(self):
        config=copy.deepcopy(CONFIG);config['investment_analysis']={'enabled':True}
        service=Mock();service.batch.return_value=({'CSV':{'nav':{'status':'NOT_APPLICABLE'},
            'fundamentals':{'status':'REVIEW'},'portfolio':{'status':'UNAVAILABLE'}}},{'status':'UNAVAILABLE'})
        r=d.collect_report(config,Path('missing'),Path('.'),NOW,fetcher=Mock(side_effect=ValueError('no quote')),
            evaluator=Mock(return_value={'status':'FAIL','reasons':[]}),investment_evaluator=service,clock=lambda:NOW)
        self.assertIsNone(r['rows'][0]['price'])
        self.assertEqual(r['rows'][0]['investment']['fundamentals']['status'],'REVIEW')
        self.assertEqual(r['portfolio_summary']['status'],'UNAVAILABLE')
        self.assertEqual(service.batch.call_args.args[1],{})

    def test_disabled_investment_does_not_claim_coverage(self):
        r=d.collect_report(CONFIG,Path('missing'),Path('.'),NOW,fetcher=Mock(side_effect=ValueError()),
            evaluator=Mock(return_value={'status':'FAIL','reasons':[]}),clock=lambda:NOW)
        self.assertNotIn('portfolio_summary',r)
        self.assertNotIn('investment',r['rows'][0])

    def test_investment_status_and_filing_change_in_daily_comparison(self):
        prior=report()['rows'][0];prior['investment']={'fundamentals':{'status':'UNAVAILABLE','latest_financial_filing':{'accessionNumber':'old'}}}
        new=copy.deepcopy(prior);new['investment']['fundamentals']={'status':'REVIEW','latest_financial_filing':{'accessionNumber':'new'}}
        self.assertIn('Fundamentals UNAVAILABLE -> REVIEW',d.changes(new,prior))
        self.assertIn('Financial filing evidence changed',d.changes(new,prior))

    def test_missing_research_keeps_all_tickers_and_never_invents_tp(self):
        evaluator=Mock(return_value={'status':'WAIT','metrics':{},'reasons':[]})
        r=d.collect_report(CONFIG,Path('missing.json'),Path('.'),NOW,fetcher=Mock(side_effect=ValueError()),evaluator=evaluator,clock=lambda:NOW)
        self.assertEqual(len(r['rows']),1);self.assertEqual(r['rows'][0]['tp'],'Not supplied');self.assertTrue(r['research_warning'])

    def test_signal_snapshot_is_attached_without_changing_technical_grade(self):
        signals = Mock(return_value={
            'symbol': 'CSV', 'status': 'BUY', 'checked_at': NOW.isoformat(),
            'scope': 'Completed regular-session candles',
            'timeframes': {'15m': {'status': 'BUY', 'as_of': NOW.isoformat()}},
        })
        evaluator = Mock(return_value={'status': 'WAIT', 'metrics': {}, 'reasons': []})
        result = d.collect_report(
            CONFIG, Path('missing.json'), Path('.'), NOW,
            fetcher=Mock(side_effect=ValueError()), evaluator=evaluator,
            signal_evaluator=signals, clock=lambda: NOW)
        self.assertEqual(result['rows'][0]['technical']['status'], 'WAIT')
        self.assertEqual(result['rows'][0]['buy_sell_signals']['timeframes']['15m']['status'], 'BUY')
        signals.assert_called_once()


class SMTPTests(unittest.TestCase):
    def test_mime_headers_and_successful_quit_failure_does_not_retry(self):
        connection=Mock();connection.send_message.return_value={};connection.quit.side_effect=OSError('quit failed');connection.close.side_effect=OSError('close failed')
        with patch.object(d,'smtp_password',return_value='private'),patch.object(d,'connect_smtp',return_value=connection):
            d.send_digest('a@example.test',report(),CONFIG,Path('.'),clock=lambda:NOW)
        msg=connection.send_message.call_args.args[0]
        self.assertEqual(msg['To'],'a@example.test');self.assertTrue(msg.is_multipart())
        self.assertIn('daily-watchlist.',msg['Message-ID']);self.assertNotIn('private',msg.as_string())
        self.assertEqual([a.get_filename() for a in msg.iter_attachments()],['investment-watchlist-2026-09-09.html'])

    def test_smtp_data_disconnect_is_uncertain(self):
        connection=Mock();connection.send_message.side_effect=smtplib.SMTPServerDisconnected('lost acknowledgement')
        with patch.object(d,'smtp_password',return_value='private'),patch.object(d,'connect_smtp',return_value=connection):
            with self.assertRaises(d.DeliveryUncertain):d.send_digest('a@example.test',report(),CONFIG,Path('.'),clock=lambda:NOW)

    def test_login_stall_past_cutoff_does_not_submit_email(self):
        connection=Mock();current=[NOW]
        def connect(*args):current[0]=NOW+timedelta(minutes=31);return connection
        with patch.object(d,'smtp_password',return_value='private'),patch.object(d,'connect_smtp',side_effect=connect):
            with self.assertRaises(d.DeliveryWindowExpired):
                d.send_digest('a@example.test',report(),CONFIG,Path('.'),clock=lambda:current[0])
        connection.send_message.assert_not_called();connection.quit.assert_called_once()


class InstallerTests(unittest.TestCase):
    def test_separate_label_one_minute_cadence_and_exact_venv(self):
        p=installer.make_plist(Path('/tmp/env/bin/python'),Path('/tmp/config'),Path('/tmp/research'),Path('/tmp/runtime'))
        self.assertEqual(p['StartInterval'],60);self.assertNotEqual(p['Label'],'com.local.arora-price-monitor')
        self.assertEqual(p['ProgramArguments'][0],'/tmp/env/bin/python')
        self.assertEqual(p['EnvironmentVariables']['ARORA_MONITOR_HOME'],'/tmp/runtime')


if __name__=='__main__':unittest.main()
