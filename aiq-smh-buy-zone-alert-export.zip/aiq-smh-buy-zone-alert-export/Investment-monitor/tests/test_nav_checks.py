from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nav_checks import NavService, parse_nav_page

# Minimal unchanged data-bearing excerpts from official pages fetched Sep10,
# 2026. Full raw snapshots: work/nav-checks-2026-09-10/{hk,rmt}.html.
# BlackRock text is the observed official page summary (web retrieval; runtime
# HTTP returned403). It tests extraction, not a claim of live HTTP availability.
HK = '''<div data-ticker-hkd="3419">ISIN HK0000978962</div>
<small data-zrcheck='daily-nav-asofdate'>As of 8 Sep 2026</small>
<tr><td>Official NAV per Unit in HKD (Unlisted Class R2)</td><td data-zrcheck="official-nav">$12.29</td></tr>
<tr><td class="label">Official NAV per Unit in HKD (Listed Class)</td><td class="tar" data-zrcheck='official-nav'>$9.44</td></tr>'''
RMT = '''<title>Royce Micro-Cap Trust (RMT)</title><p>CUSIP 780915104</p>
<span id="LabelRateDateCurrent" style="display:none">9/8/2026</span>
<span id="ctl02_LabelClosedEndFundNav">15.71</span>
<span id="ctl02_LabelClosedEndFundMkt">$13.98</span>
<span id="ctl02_LabelDiagnosticsDate">06/30/26</span>
<span id="ctl02_LabelNetAssetValue">$16.75</span>'''
BMEZ = '''BMEZ Health Sciences Term Trust
NAV as of Sep 04, 2026 $18.66
Market Price as of Sep 04, 2026 $16.97
CUSIP 09260E105'''
SHY = '''SHY iShares 1-3 Year Treasury Bond ETF
NAV as of Sep 02, 2026 $$81.63 52 WK: 81.59 - 83.16
Closing Price $81.64 as of Sep 02, 2026
CUSIP 464287457'''
UTC = timezone.utc
NOW = datetime(2026, 9, 8, 22, 5, tzinfo=UTC)
RULE = {"symbol": "RMT", "currency": "USD", "market": "US", "nav_policy": {"kind": "cef", "max_premium_pct": -10}}


class NavParserTests(unittest.TestCase):
    def test_real_globalx_chooses_listed_class_not_first_number(self):
        p = parse_nav_page("3419.HK", HK)
        self.assertEqual((p["nav"], p["as_of"], p["currency"]), (9.44, "2026-09-08", "HKD"))

    def test_globalx_does_not_take_unlisted_if_listed_missing(self):
        with self.assertRaises(ValueError):
            parse_nav_page("3419.HK", HK.replace("HKD (Listed Class)", "USD (Listed Class)"))

    def test_globalx_duplicate_listed_ambiguous(self):
        with self.assertRaises(ValueError):
            parse_nav_page("3419.HK", HK + HK)

    def test_real_royce_daily_not_quarterly(self):
        p = parse_nav_page("RMT", RMT)
        self.assertEqual((p["nav"], p["official_close"], p["as_of"]), (15.71, 13.98, "2026-09-08"))

    def test_blackrock_web_sample(self):
        self.assertEqual(parse_nav_page("BMEZ", BMEZ)["nav"], 18.66)

    def test_ishares_web_sample(self):
        self.assertEqual(parse_nav_page("SHY", SHY)["official_close"], 81.64)

    def test_blackrock_price_date_mismatch_is_not_same_close(self):
        p = parse_nav_page("BMEZ", BMEZ.replace("Market Price as of Sep 04", "Market Price as of Sep 03"))
        self.assertNotIn("official_close", p)

    def test_identity_mismatch(self):
        for symbol, raw, identity in [("RMT", RMT, "780915104"), ("3419.HK", HK, "HK0000978962"), ("BMEZ", BMEZ, "09260E105")]:
            with self.subTest(symbol=symbol), self.assertRaises(ValueError):
                parse_nav_page(symbol, raw.replace(identity, "WRONG"))

    def test_missing_nav_date(self):
        with self.assertRaises(ValueError):
            parse_nav_page("RMT", RMT.replace("9/8/2026", ""))

    def test_missing_nav_not_undated_fallback(self):
        with self.assertRaises(ValueError):
            parse_nav_page("BMEZ", 'BMEZ CUSIP 09260E105 <script>{"navPrice":18.66}</script>')

    def test_nonfinite_or_zero_nav(self):
        for value in ["0", "nan", "-10", "inf"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_nav_page("RMT", RMT.replace(">15.71<", ">" + value + "<"))


class NavServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.calls = 0
        def fetch(url):
            self.calls += 1
            return RMT
        self.service = NavService(self.tmp.name, fetcher=fetch)

    def tearDown(self):
        self.tmp.cleanup()

    def quote(self, stamp="2026-09-08T20:00:00+00:00", price="13.98", currency="USD"):
        return {"symbol": "RMT", "price": price, "timestamp": stamp, "currency": currency}

    def test_dated_nav_without_current_price_is_review(self):
        p = self.service.evaluate(RULE, {}, NOW)
        self.assertEqual(p["status"], "REVIEW")
        self.assertFalse(p["complete"])
        self.assertAlmostEqual(p["metrics"]["official_premium_discount_pct"], (13.98/15.71-1)*100)

    def test_stale_nav_rejected_even_when_just_downloaded(self):
        p = self.service.evaluate(RULE, {}, NOW + timedelta(days=1))
        self.assertEqual(p["status"], "UNAVAILABLE")
        self.assertIn("stale", p["reasons"][0])
        self.assertEqual(p["as_of"], "2026-09-08")

    def test_weekend_not_four_missing_sessions(self):
        p = self.service.evaluate(RULE, {}, datetime(2026, 9, 12, 12, tzinfo=UTC))
        self.assertEqual(p["metrics"]["nav_lag_sessions"], 3)

    def test_intraday_vs_previous_nav_never_passes(self):
        now = datetime(2026, 9, 9, 15, 0, tzinfo=UTC)
        p = self.service.evaluate(RULE, self.quote(stamp=now.isoformat()), now)
        self.assertEqual(p["status"], "REVIEW")
        self.assertIn("indicative", p["reasons"][0])
        self.assertNotIn("premium_discount_pct", p["metrics"])

    def test_configured_same_close_limit_and_date_scope(self):
        rule = {**RULE, "nav_policy": {**RULE["nav_policy"], "max_quote_age_seconds": 9000}}
        p = self.service.evaluate(rule, self.quote(), NOW)
        self.assertEqual(p["status"], "PASS")
        self.assertTrue(p["complete"])
        p = self.service.evaluate(rule, self.quote(price="16"), NOW)
        self.assertEqual(p["status"], "FAIL")

    def test_threshold_absent_stays_review(self):
        rule = {**RULE, "nav_policy": {"kind": "cef", "max_quote_age_seconds": 9000}}
        self.assertEqual(self.service.evaluate(rule, self.quote(), NOW)["status"], "REVIEW")

    def test_mismatched_quote_currency_rejected(self):
        self.assertEqual(self.service.evaluate(RULE, self.quote(currency="EUR"), NOW)["status"], "UNAVAILABLE")

    def test_future_nav_rejected(self):
        service = NavService(self.tmp.name, read_only=True, fetcher=lambda u: RMT.replace("9/8/2026", "9/9/2026"))
        self.assertEqual(service.evaluate(RULE, {}, NOW)["status"], "UNAVAILABLE")

    def test_quote_too_old_and_future_rejected(self):
        for stamp in ["2026-09-08T20:00:00+00:00", "2026-09-08T23:00:00+00:00"]:
            self.assertEqual(self.service.evaluate(RULE, self.quote(stamp=stamp), NOW)["status"], "UNAVAILABLE")

    def test_unsupported_has_no_fetch(self):
        p = self.service.evaluate({"symbol": "JEPI", "nav_policy": {"kind": "etf"}}, {}, NOW)
        self.assertEqual(p["status"], "UNAVAILABLE")
        self.assertEqual(self.calls, 0)

    def test_not_applicable_has_no_fetch(self):
        p = self.service.evaluate({"symbol": "NVDA", "nav_policy": {"kind": "not_applicable"}}, {}, NOW)
        self.assertEqual(p["status"], "NOT_APPLICABLE")
        self.assertEqual(self.calls, 0)

    def test_cache_reuses_fresh_but_date_still_revalidated(self):
        self.service.evaluate(RULE, {}, NOW)
        self.service.evaluate(RULE, {}, NOW+timedelta(minutes=5))
        self.assertEqual(self.calls, 1)
        self.assertEqual(self.service.evaluate(RULE, {}, NOW+timedelta(days=1))["status"], "UNAVAILABLE")
        self.assertEqual(self.calls, 2)

    def test_readonly_never_writes(self):
        service = NavService(self.tmp.name, read_only=True, fetcher=lambda u: RMT)
        service.evaluate(RULE, {}, NOW)
        self.assertEqual(list(Path(self.tmp.name).iterdir()), [])

    def test_failure_backoff_no_fabricated_nav(self):
        calls = []
        def fail(url):
            calls.append(url)
            raise ValueError("HTTP403")
        service = NavService(self.tmp.name, fetcher=fail)
        for offset in [0, 60]:
            p = service.evaluate(RULE, {}, NOW+timedelta(seconds=offset))
            self.assertEqual(p["status"], "UNAVAILABLE")
            self.assertNotIn("nav", p["metrics"])
        self.assertEqual(len(calls), 1)

    def test_invalid_limits_fail_closed(self):
        for field, value in [("max_nav_lag_sessions", True), ("max_nav_lag_sessions", -1), ("max_premium_pct", float("nan"))]:
            rule = {**RULE, "nav_policy": {**RULE["nav_policy"], field: value}}
            self.assertEqual(self.service.evaluate(rule, {}, NOW)["status"], "UNAVAILABLE")


if __name__ == "__main__":
    unittest.main()
