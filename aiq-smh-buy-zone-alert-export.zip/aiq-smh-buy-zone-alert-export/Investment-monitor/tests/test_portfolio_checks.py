from datetime import datetime, timedelta, timezone
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from portfolio_checks import PortfolioService, parse_fx, validate_reference_quote

UTC = timezone.utc
NOW = datetime(2026, 9, 9, 17, tzinfo=UTC)
# Actual public API schema/data verified Sep9 2026, 16:54 UTC; units per USD.
FX = [
    {"date": "2026-09-09", "base": "USD", "quote": "GBP", "rate": 0.7372,
     "providers": [{"key": "ECB", "date": "2026-09-09", "rate": 0.7372}]},
    {"date": "2026-09-09", "base": "USD", "quote": "HKD", "rate": 7.8423,
     "providers": [{"key": "ECB", "date": "2026-09-09", "rate": 7.8423}]}]
RULES = [{"symbol": "SPY", "currency": "USD", "market": "US"},
         {"symbol": "SGOV", "currency": "USD", "market": "US"},
         {"symbol": "3419.HK", "currency": "HKD", "market": "HK"}]
PORT = {"version": 1, "confirmed_at": "2026-01-01T00:00:00+00:00", "maintenance": "user_updates_on_change",
        "base_currency": "USD", "risk_limits": {}, "proposed_additions": {},
        "positions": [{"symbol": "SPY", "currency": "USD", "quantity": 1},
                      {"symbol": "SGOV", "currency": "USD", "quantity": 1},
                      {"symbol": "3419.HK", "currency": "HKD", "quantity": 100}],
        "cash": {"USD": 100, "HKD": 784.23, "GBP": 73.72}}
QUOTES = {"SPY": {"symbol": "SPY", "currency": "USD", "price": "100", "timestamp": "2026-09-09T16:59:00+00:00"},
          "SGOV": {"symbol": "SGOV", "currency": "USD", "price": "100", "timestamp": "2026-09-09T16:59:00+00:00"},
          "3419.HK": {"symbol": "3419.HK", "currency": "HKD", "price": "7.8423", "timestamp": "2026-09-09T08:10:00+00:00"}}


class FxTests(unittest.TestCase):
    def test_verified_schema(self):
        value = parse_fx(FX, ["GBP", "HKD"], NOW)
        self.assertEqual(value["rates_per_usd"], {"USD": 1.0, "GBP": 0.7372, "HKD": 7.8423})

    def test_wrong_base(self):
        raw = copy.deepcopy(FX)
        raw[0]["base"] = "EUR"
        with self.assertRaises(ValueError): parse_fx(raw, ["GBP", "HKD"], NOW)

    def test_no_peg_assumption(self):
        raw = copy.deepcopy(FX)
        raw[1].pop("providers")
        with self.assertRaises(ValueError): parse_fx(raw, ["GBP", "HKD"], NOW)

    def test_future_or_stale_reference(self):
        for now in [NOW-timedelta(days=1), NOW+timedelta(days=8)]:
            with self.assertRaises(ValueError): parse_fx(FX, ["GBP", "HKD"], now)

    def test_mismatched_dates_and_missing_currency(self):
        raw = copy.deepcopy(FX)
        raw[0]["date"] = raw[0]["providers"][0]["date"] = "2026-09-08"
        with self.assertRaises(ValueError): parse_fx(raw, ["GBP", "HKD"], NOW)
        with self.assertRaises(ValueError): parse_fx(FX[:1], ["GBP", "HKD"], NOW)

    def test_bad_rate_and_duplicate(self):
        raw = copy.deepcopy(FX)
        raw[0]["rate"] = float("nan")
        with self.assertRaises(ValueError): parse_fx(raw, ["GBP", "HKD"], NOW)
        with self.assertRaises(ValueError): parse_fx(FX+FX[:1], ["GBP", "HKD"], NOW)

    def test_attribution_disagrees(self):
        raw = copy.deepcopy(FX)
        raw[0]["providers"][0]["rate"] = 0.5
        with self.assertRaises(ValueError): parse_fx(raw, ["GBP", "HKD"], NOW)


class ReferenceTests(unittest.TestCase):
    def test_delayed_closing_print_has_bounded_reference_grace(self):
        now = datetime(2026, 9, 11, 2, tzinfo=UTC)
        q = {**QUOTES["SGOV"], "timestamp": "2026-09-10T20:00:24+00:00"}
        accepted = validate_reference_quote("SGOV", q, RULES[1], now)
        self.assertTrue(accepted["closing_print_grace_used"])
        self.assertEqual(accepted["timestamp"], q["timestamp"])
        q["timestamp"] = "2026-09-10T20:01:01+00:00"
        with self.assertRaises(ValueError):
            validate_reference_quote("SGOV", q, RULES[1], now)

    def test_hk_auction_and_closing_grace_are_bounded(self):
        q = {**QUOTES["3419.HK"], "timestamp": "2026-09-09T08:10:24+00:00"}
        self.assertTrue(validate_reference_quote("3419.HK", q, RULES[2], NOW)["closing_print_grace_used"])
        q["timestamp"] = "2026-09-09T08:11:01+00:00"
        with self.assertRaises(ValueError):
            validate_reference_quote("3419.HK", q, RULES[2], NOW)

    def test_prior_completed_close_valid_during_current_session(self):
        quote = {**QUOTES["SPY"], "timestamp": "2026-09-08T20:00:00+00:00"}
        self.assertEqual(validate_reference_quote("SPY", quote, RULES[0], NOW)["session"], "2026-09-08")

    def test_wrong_identity_currency_or_future(self):
        for field, value in [("symbol", "WRONG"), ("currency", "HKD"), ("timestamp", "2026-09-09T17:01:00+00:00")]:
            with self.subTest(field=field), self.assertRaises(ValueError):
                validate_reference_quote("SPY", {**QUOTES["SPY"], field: value}, RULES[0], NOW)

    def test_older_session_stale(self):
        with self.assertRaises(ValueError):
            validate_reference_quote("SPY", {**QUOTES["SPY"], "timestamp": "2026-09-04T20:00:00+00:00"}, RULES[0], NOW)

    def test_nontrading_or_phase_mismatch(self):
        with self.assertRaises(ValueError):
            validate_reference_quote("SPY", {**QUOTES["SPY"], "timestamp": "2026-09-07T16:00:00+00:00"}, RULES[0], NOW)
        with self.assertRaises(ValueError):
            validate_reference_quote("SPY", {**QUOTES["SPY"], "phase": "pre"}, RULES[0], NOW)


class PortfolioTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)/"portfolio-input.json"
        self.path.write_text(json.dumps(PORT))
        self.fx_calls, self.price_calls = [], []
        def prices(symbol):
            self.price_calls.append(symbol)
            return QUOTES[symbol]
        def fx(currencies):
            self.fx_calls.append(currencies)
            return FX
        self.service = PortfolioService(Path(self.tmp.name)/"cache", self.path, RULES, fetcher=prices, fx_fetcher=fx)

    def tearDown(self):
        self.tmp.cleanup()

    def test_exact_fx_direction_cash_and_weights(self):
        summary = self.service.prepare(QUOTES, NOW)
        self.assertTrue(summary["complete"])
        m = summary["metrics"]
        self.assertAlmostEqual(m["total_value_usd"], 600)
        self.assertAlmostEqual(m["converted_cash_usd"], 300)
        self.assertEqual(m["cash_usd"], 100)
        self.assertAlmostEqual(self.service.evaluate(RULES[2], NOW)["metrics"]["position_weight_pct"], 100/6)
        # The Treasury ETF is not counted as cash.
        self.assertAlmostEqual(m["known_position_value_usd"], 300)

    def test_no_suitability_pass(self):
        self.service.prepare(QUOTES, NOW)
        result = self.service.evaluate(RULES[0], NOW)
        self.assertEqual(result["status"], "REVIEW")
        self.assertFalse(result["complete"])
        self.assertTrue(result["metrics"]["exposure_complete"])
        self.assertIsNone(result["metrics"]["proposed_addition"])

    def test_old_user_confirmation_does_not_expire_arbitrarily(self):
        result = self.service.prepare(QUOTES, NOW)
        self.assertTrue(result["complete"])
        self.assertEqual(result["confirmed_at"], PORT["confirmed_at"])

    def test_unknown_position_zero_only_when_input_valid(self):
        self.service.prepare(QUOTES, NOW)
        result = self.service.evaluate({"symbol": "NVDA"}, NOW)
        self.assertEqual(result["metrics"]["position_quantity"], 0)
        self.path.write_text("invalid json")
        self.service.prepare(QUOTES, NOW)
        result = self.service.evaluate({"symbol": "NVDA"}, NOW)
        self.assertIsNone(result["metrics"]["position_quantity"])

    def test_one_missing_price_withholds_every_weight(self):
        def bad(symbol): raise ValueError("offline")
        self.service.fetcher = bad
        quotes = {k:v for k,v in QUOTES.items() if k != "SPY"}
        s = self.service.prepare(quotes, NOW)
        self.assertFalse(s["complete"])
        self.assertIsNone(s["metrics"]["total_value_usd"])
        self.assertAlmostEqual(s["metrics"]["known_position_value_usd"], 200)
        self.assertTrue(all(p["weight_pct"] is None for p in s["metrics"]["positions"]))

    def test_fx_failure_retains_only_known_usd_values(self):
        def fail(currencies): raise ValueError("offline")
        self.service.fx_fetcher = fail
        s = self.service.prepare(QUOTES, NOW)
        self.assertFalse(s["complete"])
        self.assertIsNone(s["metrics"]["converted_cash_usd"])
        self.assertAlmostEqual(s["metrics"]["known_cash_value_usd"], 100)
        self.assertAlmostEqual(s["metrics"]["known_position_value_usd"], 200)

    def test_fallback_and_cache(self):
        self.service.prepare({}, NOW)
        self.service.prepare({}, NOW+timedelta(minutes=20))
        self.assertCountEqual(self.price_calls, ["SPY", "SGOV", "3419.HK"])
        self.assertEqual(len(self.fx_calls), 1)

    def test_fx_failure_retries_after_five_minutes(self):
        calls = []
        def fail(currencies):
            calls.append(currencies)
            raise ValueError("offline")
        self.service.fx_fetcher = fail
        self.service.prepare(QUOTES, NOW)
        self.service.prepare(QUOTES, NOW+timedelta(minutes=4))
        self.assertEqual(len(calls), 1)
        self.service.prepare(QUOTES, NOW+timedelta(minutes=5))
        self.assertEqual(len(calls), 2)

    def test_explicit_no_fallback_ignores_existing_cached_marks(self):
        self.service.prepare({}, NOW)
        self.service.allow_fallback = False
        result = self.service.prepare({}, NOW)
        self.assertFalse(result["complete"])
        self.assertEqual(result["metrics"]["valued_position_count"], 0)
        self.assertEqual(len(self.price_calls), 3)

    def test_failed_price_recovers_at_next_retry(self):
        calls = []
        def prices(symbol):
            calls.append(symbol)
            if len(calls) == 1:
                raise ValueError("Temporary provider failure")
            return QUOTES[symbol]
        self.service.fetcher = prices
        supplied = {k: v for k, v in QUOTES.items() if k != "SGOV"}
        self.assertFalse(self.service.prepare(supplied, NOW)["complete"])
        self.assertFalse(self.service.prepare(supplied, NOW+timedelta(minutes=4))["complete"])
        self.assertTrue(self.service.prepare(supplied, NOW+timedelta(minutes=5))["complete"])
        self.assertEqual(calls, ["SGOV", "SGOV"])

    def test_readonly_no_cache_written(self):
        self.service.read_only = True
        self.service.prepare({}, NOW)
        self.assertFalse((Path(self.tmp.name)/"cache").exists())

    def test_invalid_quantities_confirmation_duplicates(self):
        for variant in ["negative", "future", "duplicate", "currency"]:
            p = copy.deepcopy(PORT)
            if variant == "negative": p["positions"][0]["quantity"] = -1
            if variant == "future": p["confirmed_at"] = (NOW+timedelta(days=1)).isoformat()
            if variant == "duplicate": p["positions"].append(p["positions"][0])
            if variant == "currency": p["positions"][0]["currency"] = "GBP"
            self.path.write_text(json.dumps(p))
            with self.subTest(variant=variant):
                self.assertEqual(self.service.prepare(QUOTES, NOW)["status"], "UNAVAILABLE")

    def test_supplied_price_avoids_fallback(self):
        self.service.prepare(QUOTES, NOW)
        self.assertEqual(self.price_calls, [])

    def test_usd_only_needs_no_fx(self):
        p = copy.deepcopy(PORT)
        p["positions"] = p["positions"][:2]
        p["cash"] = {"USD": 100}
        self.path.write_text(json.dumps(p))
        result = self.service.prepare(QUOTES, NOW)
        self.assertEqual(result["metrics"]["total_value_usd"], 300)
        self.assertEqual(self.fx_calls, [])

    def test_prepare_required(self):
        self.assertEqual(self.service.evaluate(RULES[0], NOW)["status"], "UNAVAILABLE")


if __name__ == "__main__":
    unittest.main()
