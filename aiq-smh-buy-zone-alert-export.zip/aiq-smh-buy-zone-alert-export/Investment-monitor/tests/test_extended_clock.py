"""Extended-hours slots remain independent from the regular market clock."""

from datetime import datetime, timezone
import unittest
from zoneinfo import ZoneInfo

from market_clock import extended_market_session, market_session


def utc(value: str) -> datetime:
    return datetime.fromisoformat(value).replace(tzinfo=timezone.utc)


class ExtendedMarketClockTests(unittest.TestCase):
    def test_pre_open_grace_and_five_minute_slots(self):
        self.assertIsNone(extended_market_session(utc("2026-09-04T08:04:59")))
        first = extended_market_session(utc("2026-09-04T08:05:00"))
        self.assertEqual(first["open"], utc("2026-09-04T08:00:00"))
        self.assertEqual(first["close"], utc("2026-09-04T13:30:00"))
        self.assertEqual(first["phase"], "pre")
        self.assertEqual(first["slot"], "US:pre:2026-09-04:04:05")
        self.assertEqual(extended_market_session(utc("2026-09-04T08:09:59"))["slot"], first["slot"])
        self.assertEqual(extended_market_session(utc("2026-09-04T08:10:00"))["slot"], "US:pre:2026-09-04:04:10")
        self.assertEqual(extended_market_session(utc("2026-09-04T08:59:59"))["slot"], "US:pre:2026-09-04:04:55")
        self.assertEqual(extended_market_session(utc("2026-09-04T09:00:00"))["slot"], "US:pre:2026-09-04:05:00")

    def test_pre_final_slot_and_hard_regular_open_boundary(self):
        self.assertEqual(extended_market_session(utc("2026-09-04T13:24:59"))["slot"], "US:pre:2026-09-04:09:20")
        self.assertEqual(extended_market_session(utc("2026-09-04T13:25:00"))["slot"], "US:pre:2026-09-04:09:25")
        self.assertEqual(extended_market_session(utc("2026-09-04T13:29:59"))["phase"], "pre")
        for stamp in ("2026-09-04T13:30:00", "2026-09-04T13:35:00", "2026-09-04T19:59:59"):
            self.assertIsNone(extended_market_session(utc(stamp)))

    def test_post_open_grace_and_five_minute_slots(self):
        for stamp in ("2026-09-04T20:00:00", "2026-09-04T20:04:59"):
            self.assertIsNone(extended_market_session(utc(stamp)))
        first = extended_market_session(utc("2026-09-04T20:05:00"))
        self.assertEqual(first["phase"], "post")
        self.assertEqual(first["open"], utc("2026-09-04T20:00:00"))
        self.assertEqual(first["close"], utc("2026-09-05T00:00:00"))
        self.assertEqual(first["slot"], "US:post:2026-09-04:16:05")
        self.assertEqual(extended_market_session(utc("2026-09-04T20:09:59"))["slot"], first["slot"])
        self.assertEqual(extended_market_session(utc("2026-09-04T20:10:00"))["slot"], "US:post:2026-09-04:16:10")
        self.assertEqual(extended_market_session(utc("2026-09-04T21:00:00"))["slot"], "US:post:2026-09-04:17:00")

    def test_post_final_quote_and_retry_boundaries(self):
        self.assertEqual(extended_market_session(utc("2026-09-04T23:59:59"))["slot"], "US:post:2026-09-04:19:55")
        last = extended_market_session(utc("2026-09-05T00:00:00"))
        self.assertEqual(last["slot"], "US:post:2026-09-04:20:00:close")
        self.assertEqual(last["closing_quote_min"], utc("2026-09-04T23:59:00"))
        self.assertEqual(extended_market_session(utc("2026-09-05T00:04:59"))["slot"], last["slot"])
        self.assertEqual(extended_market_session(utc("2026-09-05T00:05:00"))["slot"], "US:post:2026-09-04:20:05:close")
        self.assertEqual(extended_market_session(utc("2026-09-05T00:20:00"))["slot"], "US:post:2026-09-04:20:20:close")
        self.assertIsNone(extended_market_session(utc("2026-09-05T00:20:01")))

    def test_early_close_starts_at_actual_close_and_ends_at_1700(self):
        self.assertIsNone(extended_market_session(utc("2026-11-27T18:04:59")))
        first = extended_market_session(utc("2026-11-27T18:05:00"))
        self.assertEqual(first["open"], utc("2026-11-27T18:00:00"))
        self.assertEqual(first["close"], utc("2026-11-27T22:00:00"))
        self.assertEqual(first["slot"], "US:post:2026-11-27:13:05")
        self.assertEqual(extended_market_session(utc("2026-11-27T21:59:59"))["slot"], "US:post:2026-11-27:16:55")
        last = extended_market_session(utc("2026-11-27T22:00:00"))
        self.assertEqual(last["slot"], "US:post:2026-11-27:17:00:close")
        self.assertEqual(last["closing_quote_min"], utc("2026-11-27T21:59:00"))
        self.assertEqual(extended_market_session(utc("2026-11-27T22:04:59"))["slot"], last["slot"])
        self.assertEqual(extended_market_session(utc("2026-11-27T22:05:00"))["slot"], "US:post:2026-11-27:17:05:close")
        self.assertEqual(extended_market_session(utc("2026-11-27T22:20:00"))["slot"], "US:post:2026-11-27:17:20:close")
        self.assertIsNone(extended_market_session(utc("2026-11-27T22:20:01")))
        self.assertIsNone(extended_market_session(utc("2026-11-28T00:00:00")))

    def test_holidays_and_weekends_have_no_extended_session(self):
        for stamp in ("2026-09-05T08:05:00", "2026-09-06T20:05:00", "2026-09-07T08:05:00", "2026-09-07T20:05:00", "2026-11-26T22:00:00"):
            self.assertIsNone(extended_market_session(utc(stamp)))

    def test_daylight_saving_start(self):
        before = extended_market_session(utc("2026-03-06T09:05:00"))
        after = extended_market_session(utc("2026-03-09T08:05:00"))
        self.assertEqual(before["open"].hour, 9)
        self.assertEqual(after["open"].hour, 8)
        self.assertTrue(before["slot"].endswith(":04:05"))
        self.assertTrue(after["slot"].endswith(":04:05"))
        self.assertEqual(extended_market_session(utc("2026-03-06T21:05:00"))["close"], utc("2026-03-07T01:00:00"))
        self.assertEqual(extended_market_session(utc("2026-03-09T20:05:00"))["close"], utc("2026-03-10T00:00:00"))

    def test_daylight_saving_end(self):
        before = extended_market_session(utc("2026-10-30T08:05:00"))
        after = extended_market_session(utc("2026-11-02T09:05:00"))
        self.assertEqual(before["open"].hour, 8)
        self.assertEqual(after["open"].hour, 9)
        self.assertEqual(extended_market_session(utc("2026-10-30T20:05:00"))["close"], utc("2026-10-31T00:00:00"))
        self.assertEqual(extended_market_session(utc("2026-11-02T21:05:00"))["close"], utc("2026-11-03T01:00:00"))

    def test_metadata_and_local_timezone_are_consistent(self):
        moment = utc("2026-09-04T08:05:00")
        session = extended_market_session(moment)
        self.assertEqual(session, extended_market_session(moment.astimezone(ZoneInfo("Asia/Hong_Kong"))))
        self.assertEqual(session["market"], "US")
        self.assertEqual(session["currency"], "USD")
        self.assertEqual(session["exchange_timezone"], "America/New_York")
        self.assertIsNone(session["break_start"])
        self.assertIsNone(session["break_end"])

    def test_hk_is_not_eligible_and_invalid_input_is_rejected(self):
        self.assertIsNone(extended_market_session(utc("2026-09-04T08:05:00"), "HK"))
        with self.assertRaises(ValueError):
            extended_market_session(datetime(2026, 9, 4, 8, 5))
        with self.assertRaises(ValueError):
            extended_market_session(datetime(2026, 9, 4, 8, 5), "HK")
        with self.assertRaises(ValueError):
            extended_market_session(utc("2026-09-04T08:05:00"), "OTHER")

    def test_regular_and_extended_closing_ids_remain_distinct(self):
        pre = utc("2026-09-04T08:05:00")
        regular = utc("2026-09-04T13:35:00")
        after = utc("2026-09-04T20:05:00")
        self.assertIsNone(market_session(pre))
        self.assertEqual(market_session(regular)["slot"], "2026-09-04:09:35")
        self.assertNotIn("phase", market_session(regular))
        self.assertEqual(market_session(after)["slot"], "2026-09-04:16:05:close")
        self.assertEqual(extended_market_session(after)["slot"], "US:post:2026-09-04:16:05")
        self.assertEqual(market_session(utc("2026-09-07T06:05:00"), "HK")["slot"], "HK:2026-09-07:14:05")


if __name__ == "__main__":
    unittest.main()
