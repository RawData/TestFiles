"""Multi-market holidays, lunch, auction and one-sided anomaly alerts."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from market_clock import market_session
from monitor import (Quote, DEFAULT_CONFIG, alert_text, load_config, observe,
                     parse_quote, run_cycle, send_channel, validate_quote, zone_key)

def utc(value):
    return datetime.fromisoformat(value).replace(tzinfo=timezone.utc)

NOW = utc('2026-09-07T06:05:00')
HK = dict(symbol='3419.HK', market='HK', currency='HKD', low='9.15', high='9.40',
          alert_kind='review_zone', source='Independent review', review_notes='Verify current NAV.')
RISK = dict(symbol='SGOV', low='100.15', high='100.15', trigger='at_or_below',
            alert_kind='support_watch', source='Independent review', review_notes='Anomaly, not a buy.')

class HongKongClockTests(unittest.TestCase):
    def test_us_holiday_does_not_close_hk(self):
        self.assertIsNone(market_session(NOW, 'US'))
        self.assertEqual(market_session(NOW, 'HK')['slot'], 'HK:2026-09-07:14:05')

    def test_hk_holiday_and_weekend(self):
        for stamp in ('2026-10-01T06:00:00','2026-09-06T06:00:00'):
            self.assertIsNone(market_session(utc(stamp), 'HK'))

    def test_lunch_and_afternoon_grace(self):
        for stamp in ('2026-09-07T04:00:00','2026-09-07T04:59:00','2026-09-07T05:04:59'):
            self.assertIsNone(market_session(utc(stamp),'HK'))
        self.assertEqual(market_session(utc('2026-09-07T05:05:00'),'HK')['slot'], 'HK:2026-09-07:13:05')
        self.assertEqual(market_session(utc('2026-09-07T05:09:59'),'HK')['slot'], 'HK:2026-09-07:13:05')
        self.assertEqual(market_session(utc('2026-09-07T05:10:00'),'HK')['slot'], 'HK:2026-09-07:13:10')

    def test_open_grace_and_separate_morning_slot(self):
        self.assertIsNone(market_session(utc('2026-09-07T01:34:59'),'HK'))
        self.assertEqual(market_session(utc('2026-09-07T01:35:00'),'HK')['slot'], 'HK:2026-09-07:09:35')
        self.assertEqual(market_session(utc('2026-09-07T01:39:59'),'HK')['slot'], 'HK:2026-09-07:09:35')
        self.assertEqual(market_session(utc('2026-09-07T01:40:00'),'HK')['slot'], 'HK:2026-09-07:09:40')
        self.assertEqual(market_session(utc('2026-09-07T03:55:00'),'HK')['slot'], 'HK:2026-09-07:11:55')

    def test_auction_waits_and_final_window(self):
        self.assertIsNone(market_session(utc('2026-09-07T08:05:00'),'HK'))
        s = market_session(utc('2026-09-07T08:10:00'),'HK')
        self.assertEqual(s['slot'], 'HK:2026-09-07:16:10:close')
        self.assertEqual(s['closing_quote_min'], utc('2026-09-07T07:59:00'))
        self.assertEqual(market_session(utc('2026-09-07T08:14:59'),'HK')['slot'], s['slot'])
        self.assertEqual(market_session(utc('2026-09-07T08:15:00'),'HK')['slot'], 'HK:2026-09-07:16:15:close')
        self.assertEqual(market_session(utc('2026-09-07T08:30:00'),'HK')['slot'], 'HK:2026-09-07:16:30:close')
        self.assertIsNone(market_session(utc('2026-09-07T08:30:01'),'HK'))

    def test_half_day_auction(self):
        s=market_session(utc('2026-12-24T04:10:00'),'HK')
        self.assertIsNotNone(s)
        self.assertEqual(s['close'],utc('2026-12-24T04:10:00'))
        self.assertEqual(s['slot'],'HK:2026-12-24:12:10:close')
        self.assertEqual(market_session(utc('2026-12-24T04:15:00'),'HK')['slot'],'HK:2026-12-24:12:15:close')
        self.assertIsNone(market_session(utc('2026-12-24T05:10:00'),'HK'))

class HKQuoteAndCycleTests(unittest.TestCase):
    def q(self, stamp=NOW, currency='HKD', price='9.3'):
        return Quote('3419.HK',Decimal(price),stamp,currency)

    def config(self):
        c=load_config(DEFAULT_CONFIG)
        c['watchlist']=[dict(symbol='AIQ',low='48.13',high='55.68'),deepcopy(HK)]
        c['alerts']['email']['enabled']=False
        c['alerts']['mac']=True
        return c

    def test_parse_correct_exchange_and_reject_other_timezone_currency(self):
        meta=dict(symbol='3419.HK',regularMarketPrice=9.3,regularMarketTime=NOW.timestamp(),
                  exchangeTimezoneName='Asia/Hong_Kong',currency='HKD')
        def payload(m): return {'chart':{'result':[{'meta':m}],'error':None}}
        self.assertEqual(parse_quote('3419.HK',payload(meta)).currency,'HKD')
        for change in (dict(currency='USD'),dict(exchangeTimezoneName='America/New_York')):
            with self.assertRaises(ValueError): parse_quote('3419.HK',payload(dict(meta,**change)))

    def test_stale_and_wrong_currency_rejected(self):
        for q in (self.q(NOW-timedelta(minutes=21)),self.q(currency='USD')):
            with self.assertRaises(ValueError): validate_quote(q,NOW,market_session(NOW,'HK'))

    def test_afternoon_requires_afternoon_and_not_lunch_quote(self):
        now=utc('2026-09-07T05:05:00');s=market_session(now,'HK')
        for stamp in ('2026-09-07T03:59:00','2026-09-07T04:59:00'):
            with self.assertRaises(ValueError): validate_quote(self.q(utc(stamp)),now,s,7200)
        validate_quote(self.q(utc('2026-09-07T05:00:00')),now,s)

    def test_final_quote_accepts_continuous_close_or_auction(self):
        now=utc('2026-09-07T08:15:00');s=market_session(now,'HK')
        for stamp in ('2026-09-07T07:59:30','2026-09-07T08:09:00'):
            validate_quote(self.q(utc(stamp)),now,s)
        with self.assertRaises(ValueError): validate_quote(self.q(utc('2026-09-07T07:58:59')),now,s)
        with self.assertRaises(ValueError): validate_quote(self.q(utc('2026-09-07T08:11:00')),now,s)

    def test_only_hk_fetched_on_us_holiday_and_no_duplicate(self):
        c=self.config(); old={'status':'above','zone_key':'AIQ:48.13:55.68','last_slot':'2026-09-04:close','pending':None}
        state={'version':1,'symbols':{'AIQ':deepcopy(old)}}
        fetch=Mock(return_value=self.q());send=Mock();sessions={'US':None,'HK':market_session(NOW,'HK')}
        self.assertEqual(run_cycle(c,state,NOW,sessions,fetcher=fetch,sender=send),0)
        fetch.assert_called_once_with('3419.HK');self.assertEqual(state['symbols']['AIQ'],old)
        self.assertEqual(send.call_count,1);self.assertIn('HK$9.30',send.call_args.args[2])
        self.assertEqual(run_cycle(c,state,NOW,sessions,fetcher=fetch,sender=send),0)
        self.assertEqual(fetch.call_count,1);self.assertEqual(send.call_count,1)

    def test_dry_run_leaves_state_and_channels_untouched(self):
        c=self.config();state={'version':1,'symbols':{}};before=deepcopy(state);send=Mock()
        run_cycle(c,state,NOW,{'HK':market_session(NOW,'HK'),'US':None},fetcher=lambda _:self.q(),sender=send,dry_run=True)
        self.assertEqual(state,before);send.assert_not_called()

    def test_hk_banner_preserves_half_cent_ticks(self):
        q=self.q(price='9.305');entry=observe(None,q,HK,'slot',['mac'],NOW)
        title,body=alert_text([(HK,entry)],self.config())
        self.assertIn('HK$9.305',body)
        with patch('monitor.subprocess.run') as run:send_channel('mac',title,body,self.config(),Path('/unused'))
        self.assertIn('HK$9.305',run.call_args.args[0][-1])

    def test_closed_diagnostic_fetches_but_cannot_alert(self):
        c=self.config();c['watchlist']=[HK];send=Mock();fetch=Mock(return_value=self.q());state={'version':1,'symbols':{}}
        self.assertEqual(run_cycle(c,state,NOW,{'HK':None},fetcher=fetch,sender=send,dry_run=True,check_closed=True),1)
        fetch.assert_called_once();send.assert_not_called();self.assertEqual(state['symbols'],{})

    def test_hk_market_and_currency_validated(self):
        for rule in (dict(HK,market='US'),dict(HK,currency='USD'),dict(HK,symbol='AIQ')):
            c=self.config();c['watchlist']=[rule]
            with tempfile.TemporaryDirectory() as d:
                p=Path(d)/'config.json';p.write_text(json.dumps(c))
                with self.assertRaises(ValueError):load_config(p)

class RiskThresholdTests(unittest.TestCase):
    def observe(self,price,previous=None):
        return observe(previous,Quote('SGOV',Decimal(price),NOW),RISK,'slot',['mac'],NOW)

    def test_crossing_inclusive_threshold_and_no_repeat(self):
        old=self.observe('100.3');self.assertEqual(old['status'],'above')
        entry=self.observe('100.15',old);self.assertIsNotNone(entry['pending'])
        entry['pending']=None
        lower=self.observe('99',entry);self.assertEqual(lower['status'],'inside');self.assertIsNone(lower['pending'])
        exit_entry=self.observe('100.4',lower)
        self.assertIsNotNone(self.observe('100.1',exit_entry)['pending'])

    def test_risk_text_reaches_mac_without_fictitious_buy_range(self):
        title,body=alert_text([(RISK,self.observe('100.1'))],load_config(DEFAULT_CONFIG))
        self.assertIn('review threshold <= $100.15',body);self.assertNotIn('Midpoint',body)
        self.assertIn('no investment buy signal',body)
        with patch('monitor.subprocess.run') as run:send_channel('mac',title,body,load_config(DEFAULT_CONFIG),Path('/unused'))
        self.assertIn('review threshold <= $100.15',run.call_args.args[0][-1])

    def test_legacy_keys_unchanged(self):
        r=dict(symbol='AIQ',low='48.13',high='55.68')
        self.assertEqual(zone_key(r),'AIQ:48.13:55.68')
        self.assertEqual(zone_key(r),zone_key(dict(r,market='US',currency='USD',trigger='range')))
        self.assertIn('at_or_below',zone_key(RISK))

    def test_invalid_trigger_and_unequal_bounds_rejected(self):
        for r in (dict(RISK,trigger='always'),dict(RISK,low='99'),dict(RISK,alert_kind='review_zone')):
            c=load_config(DEFAULT_CONFIG);c['watchlist']=[r]
            with tempfile.TemporaryDirectory() as d:
                p=Path(d)/'config.json';p.write_text(json.dumps(c))
                with self.assertRaises(ValueError):load_config(p)

if __name__=='__main__':unittest.main()
