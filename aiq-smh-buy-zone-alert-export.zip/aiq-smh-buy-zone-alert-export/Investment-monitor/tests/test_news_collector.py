from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from monitor import atomic_json
from news_collector import collect, parse_feed, parse_json, safe_url, read_key, merge_article, render

NOW = datetime(2026,9,11,6,tzinfo=timezone.utc)
RSS = b'<rss><channel><item><title>Policy update</title><link>https://example.org/update?utm_source=feed</link><pubDate>Fri, 11 Sep 2026 05:30:00 GMT</pubDate><description>Reported change</description></item></channel></rss>'
SOURCE = {"id":"test","kind":"rss","url":"https://example.org/rss","interval_seconds":300}
KEY = "test_key_not_a_real_credential"


class NewsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name)
        self.secret = self.folder/"secret.json"
        atomic_json(self.secret, {"marketaux_api_key":KEY})
    def tearDown(self):
        self.tmp.cleanup()
    def run_collect(self, sources, transport, now=NOW):
        return collect({"sources":sources}, self.folder/"evidence", self.secret, now, transport)
    def test_rss_has_real_date_and_scope(self):
        rows,_=parse_feed(RSS,SOURCE,NOW)
        self.assertEqual(rows[0]["published_at"],"2026-09-11T05:30:00+00:00")
        self.assertEqual(rows[0]["url"],"https://example.org/update")
        self.assertEqual(rows[0]["content_scope"],"headline_and_snippet")
    def test_gdelt_seen_is_not_publication(self):
        raw=json.dumps({"articles":[{"title":"A report","url":"https://example.org/news","seendate":"20260911T054500Z"}]}).encode()
        row=parse_json(raw,{"id":"gdelt","kind":"gdelt"},NOW)[0][0]
        self.assertIsNone(row["published_at"])
        self.assertEqual(row["provider_seen_at"],"2026-09-11T05:45:00+00:00")
    def test_atom_updated_not_fabricated_publication(self):
        raw=b'<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Test</title><link href="https://example.org/test"/><updated>2026-09-11T05:00:00Z</updated></entry></feed>'
        row=parse_feed(raw,SOURCE,NOW)[0][0]
        self.assertIsNone(row["published_at"])
    def test_unsafe_links_and_xml_rejected(self):
        self.assertIsNone(safe_url("javascript:alert(1)"))
        self.assertIsNone(safe_url("https://user:password@example.org"))
        self.assertEqual(safe_url("https://example.org/?api_token=secret&a=1"),"https://example.org/?a=1")
        for raw in (b'<!DOCTYPE rss><rss/>',b'<html>error</html>'):
            with self.assertRaises(ValueError):parse_feed(raw,SOURCE,NOW)
    def test_cache_and_retries_are_persistent(self):
        transport=Mock(return_value=RSS)
        self.run_collect([SOURCE],transport)
        r=self.run_collect([SOURCE],transport,NOW+timedelta(seconds=299))
        self.assertEqual(r["sources"][0]["status"],"CACHED")
        self.assertEqual(transport.call_count,1)
        self.run_collect([SOURCE],transport,NOW+timedelta(seconds=300))
        self.assertEqual(transport.call_count,2)
    def test_quota_counts_failed_requests_and_daily_reset(self):
        s={"id":"marketaux","kind":"marketaux","interval_seconds":960,"daily_cap":1,"limit":3}
        transport=Mock(side_effect=ValueError("Request error with "+KEY))
        r=self.run_collect([s],transport)
        self.assertNotIn(KEY,json.dumps(r))
        r=self.run_collect([s],transport,NOW+timedelta(hours=1))
        self.assertEqual(r["sources"][0]["status"],"QUOTA_DEFERRED")
        self.assertEqual(transport.call_count,1)
        self.run_collect([s],transport,NOW+timedelta(days=1))
        self.assertEqual(transport.call_count,2)
    def test_provider_echo_is_redacted(self):
        s={"id":"marketaux","kind":"marketaux","interval_seconds":960,"daily_cap":90,"limit":3}
        raw=json.dumps({"data":[{"title":KEY,"snippet":KEY,"url":"https://example.org/news"}]}).encode()
        self.run_collect([s],Mock(return_value=raw))
        for path in (self.folder/"evidence").iterdir():
            if path.is_file():self.assertNotIn(KEY,path.read_text())
    def test_one_failed_source_does_not_erase_other_sources(self):
        second={**SOURCE,"id":"second"}
        r=self.run_collect([SOURCE,second],Mock(side_effect=[ValueError("HTTP 403"),RSS]))
        self.assertEqual(r["sources"][0]["status"],"UNAVAILABLE")
        self.assertEqual(len(r["articles"]),1)
        self.assertEqual(r["model_status"],"DISABLED_AWAITING_ENDPOINT")
    def test_cached_failure_stays_visible_in_html(self):
        transport=Mock(side_effect=ValueError("HTTP 429"))
        self.run_collect([SOURCE],transport)
        r=self.run_collect([SOURCE],transport,NOW+timedelta(seconds=300))
        self.assertEqual(transport.call_count,1)
        self.assertIn("previous result: UNAVAILABLE (HTTP 429)",render(r))
    def test_url_dedup_retains_provenance(self):
        row=parse_feed(RSS,SOURCE,NOW)[0][0];store={}
        merge_article(store,row)
        other={**row,"collected_via":["other"]}
        merge_article(store,other)
        self.assertEqual(len(store),1)
        self.assertEqual(store[row["id"]]["collected_via"],["other","test"])
    def test_future_publication_rejected(self):
        self.assertEqual(parse_feed(RSS.replace(b"05:30:00",b"08:30:00"),SOURCE,NOW)[0],[])
    def test_secret_requires_owner_only(self):
        self.assertEqual(read_key(self.secret),KEY)
        self.secret.chmod(0o644)
        with self.assertRaises(ValueError):read_key(self.secret)
    def test_invalid_json_schema_does_not_mean_empty_success(self):
        with self.assertRaises(ValueError):
            parse_json(b'{"error":"denied"}',{"kind":"marketaux"},NOW)


if __name__=="__main__":
    unittest.main()
