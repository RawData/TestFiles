import copy
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fundamental_checks import analyze_fundamentals, FundamentalsService, TICKERS_URL

NOW = datetime(2026, 9, 10, 12, tzinfo=timezone.utc)
RULE = {"symbol": "TEST", "fundamental_policy": {"mode": "company", "cik": 123}}
ACCESSION = "0000000123-26-000001"


def fixture():
    submissions = {"cik": "0000000123", "name": "Fixture Company", "tickers": ["TEST"], "sic": "7372",
                   "filings": {"recent": {
                       "form": ["10-Q", "10-K"], "filingDate": ["2026-08-01", "2026-02-10"],
                       "reportDate": ["2026-06-30", "2025-12-31"],
                       "accessionNumber": ["0000000123-26-000002", ACCESSION],
                       "primaryDocument": ["q.htm", "k.htm"]}}}
    gaap = {}
    def add(tag, value, start="2025-01-01", end="2025-12-31", accession=ACCESSION):
        fact = {"end": end, "val": value, "accn": accession, "form": "10-K", "filed": "2026-02-10"}
        if start:
            fact["start"] = start
        gaap.setdefault(tag, {"units": {"USD": []}})["units"]["USD"].append(fact)
    add("Revenues", 110)
    add("Revenues", 100, "2024-01-01", "2024-12-31")
    add("NetIncomeLoss", 20)
    add("NetCashProvidedByUsedInOperatingActivities", 30)
    add("PaymentsToAcquirePropertyPlantAndEquipment", 10)
    add("CashAndCashEquivalentsAtCarryingValue", 50, None)
    add("StockholdersEquity", 70, None)
    add("Assets", 150, None)
    return submissions, {"cik": 123, "entityName": "Fixture Company", "facts": {"us-gaap": gaap}}


class FundamentalTests(unittest.TestCase):
    def setUp(self):
        self.sub, self.facts = fixture()

    def run_check(self, rule=None, now=NOW):
        return analyze_fundamentals(rule or RULE, self.sub, self.facts, now)

    def test_aligned_annual_growth_cash_flow_and_partial_scope(self):
        result = self.run_check()
        self.assertEqual(result["status"], "REVIEW")
        self.assertFalse(result["complete"])
        self.assertEqual(result["as_of"], "2025-12-31")
        self.assertEqual(result["metrics"]["ppe_free_cash_flow_proxy"], 20)
        self.assertAlmostEqual(result["metrics"]["revenue_growth_pct"], 10)
        self.assertTrue(result["newer_financial_filing"])
        self.assertEqual(result["facts"]["revenue"]["accession"], ACCESSION)

    def test_ytd_and_quarterly_facts_cannot_replace_annual(self):
        gaap = self.facts["facts"]["us-gaap"]
        gaap["NetCashProvidedByUsedInOperatingActivities"]["units"]["USD"][0]["start"] = "2025-07-01"
        self.assertNotIn("ppe_free_cash_flow_proxy", self.run_check()["metrics"])

    def test_us_gaap_20f_uses_same_matching_rules_with_interim_limit(self):
        self.sub["filings"]["recent"]["form"][1] = "20-F"
        for node in self.facts["facts"]["us-gaap"].values():
            for fact in node["units"]["USD"]:
                fact["form"] = "20-F"
        result = self.run_check()
        self.assertEqual(result["metrics"]["revenue"], 110)
        self.assertEqual(result["status"], "REVIEW")
        self.assertTrue(any("6-K" in item for item in result["unverified"]))

    def test_failure_retries_after_backoff(self):
        with tempfile.TemporaryDirectory() as tmp:
            calls = []
            def fetch(url):
                calls.append(url)
                raise ValueError("Temporary source failure")
            service = FundamentalsService(tmp, fetcher=fetch)
            service.evaluate(RULE, {}, NOW)
            service.evaluate(RULE, {}, NOW + timedelta(minutes=5))
            self.assertEqual(len(calls), 1)
            service.evaluate(RULE, {}, NOW + timedelta(minutes=16))
            self.assertEqual(len(calls), 2)

    def test_reject_mismatched_annual_period_start(self):
        self.facts["facts"]["us-gaap"]["PaymentsToAcquirePropertyPlantAndEquipment"]["units"]["USD"][0]["start"] = "2025-01-02"
        self.assertNotIn("ppe_free_cash_flow_proxy", self.run_check()["metrics"])

    def test_never_mix_currency_units(self):
        node = self.facts["facts"]["us-gaap"]["NetIncomeLoss"]
        node["units"]["EUR"] = node["units"].pop("USD")
        self.assertNotIn("net_income", self.run_check()["metrics"])

    def test_conflicting_duplicate_context_is_missing(self):
        items = self.facts["facts"]["us-gaap"]["Revenues"]["units"]["USD"]
        items.append({**items[0], "val": 120})
        self.assertNotIn("revenue", self.run_check()["metrics"])

    def test_same_duplicate_context_is_safe(self):
        items = self.facts["facts"]["us-gaap"]["Revenues"]["units"]["USD"]
        items.append(dict(items[0]))
        self.assertEqual(self.run_check()["metrics"]["revenue"], 110)

    def test_not_use_future_filings_or_facts(self):
        self.sub["filings"]["recent"]["filingDate"][0] = "2026-09-11"
        self.assertFalse(self.run_check()["newer_financial_filing"])
        self.facts["facts"]["us-gaap"]["NetIncomeLoss"]["units"]["USD"][0]["filed"] = "2026-09-11"
        self.assertNotIn("net_income", self.run_check()["metrics"])

    def test_wrong_issuer_or_ticker_rejected(self):
        self.facts["cik"] = 456
        with self.assertRaisesRegex(ValueError, "different issuers"):
            self.run_check()
        self.facts["cik"] = 123
        self.sub["tickers"] = ["OTHER"]
        with self.assertRaisesRegex(ValueError, "configured ticker"):
            self.run_check()

    def test_financial_sic_has_no_industrial_metrics(self):
        self.sub["sic"] = "6199"
        result = self.run_check()
        self.assertEqual(result["status"], "REVIEW")
        self.assertEqual(result["metrics"], {})
        self.assertIn("Financial company", result["reasons"][0])

    def test_explicit_financial_mode_has_no_industrial_metrics(self):
        self.assertEqual(self.run_check({**RULE, "fundamental_policy": {"mode": "financial"}})["metrics"], {})

    def test_fact_form_must_match_annual_filing_form(self):
        self.sub["filings"]["recent"]["form"][1] = "20-F"
        self.assertEqual(self.run_check()["status"], "UNAVAILABLE")

    def test_absent_capex_never_assumed_zero(self):
        del self.facts["facts"]["us-gaap"]["PaymentsToAcquirePropertyPlantAndEquipment"]
        self.assertNotIn("ppe_free_cash_flow_proxy", self.run_check()["metrics"])

    def test_negative_capex_not_silently_sign_flipped(self):
        self.facts["facts"]["us-gaap"]["PaymentsToAcquirePropertyPlantAndEquipment"]["units"]["USD"][0]["val"] = -10
        self.assertNotIn("ppe_free_cash_flow_proxy", self.run_check()["metrics"])

    def test_no_prior_period_or_nonpositive_base_no_growth(self):
        self.facts["facts"]["us-gaap"]["Revenues"]["units"]["USD"][1]["val"] = 0
        self.assertNotIn("revenue_growth_pct", self.run_check()["metrics"])

    def test_growth_requires_same_tag_and_comparable_length(self):
        gaap = self.facts["facts"]["us-gaap"]
        previous = gaap["Revenues"]["units"]["USD"].pop()
        gaap["SalesRevenueNet"] = {"units": {"USD": [previous]}}
        self.assertNotIn("revenue_growth_pct", self.run_check()["metrics"])

    def test_negative_evidence_review_without_opt_in_and_fail_with_it(self):
        self.facts["facts"]["us-gaap"]["NetIncomeLoss"]["units"]["USD"][0]["val"] = -20
        self.assertEqual(self.run_check()["status"], "REVIEW")
        rule = {**RULE, "fundamental_policy": {"mode": "company", "fail_negative_net_income": True}}
        self.assertEqual(self.run_check(rule)["status"], "FAIL")

    def test_configured_growth_threshold_uses_percent_units(self):
        rule = {**RULE, "fundamental_policy": {"min_revenue_growth_pct": 15}}
        self.assertEqual(self.run_check(rule)["status"], "FAIL")

    def test_stale_evidence_never_fails_as_current_fact(self):
        rule = {**RULE, "fundamental_policy": {"fail_negative_net_income": True}}
        self.facts["facts"]["us-gaap"]["NetIncomeLoss"]["units"]["USD"][0]["val"] = -20
        self.assertEqual(self.run_check(rule, NOW + timedelta(days=500))["status"], "UNAVAILABLE")

    def test_nonfinite_and_boolean_values_missing(self):
        for value in (True, float("nan"), float("inf")):
            self.facts["facts"]["us-gaap"]["NetIncomeLoss"]["units"]["USD"][0]["val"] = value
            self.assertNotIn("net_income", self.run_check()["metrics"])

    def test_bad_policy_rejected(self):
        for policy in ({"fail_negative_cfo": "yes"}, {"mode": "etf"}, {"max_annual_age_days": True}, {"typo": 2}, {"min_revenue_growth_pct": float("inf")}):
            with self.assertRaises(ValueError):
                self.run_check({**RULE, "fundamental_policy": policy})

    def test_bad_filing_arrays_rejected(self):
        self.sub["filings"]["recent"]["reportDate"].pop()
        with self.assertRaisesRegex(ValueError, "arrays"):
            self.run_check()


class FundamentalServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.sub, self.facts = fixture()
        self.calls = []

    def fetcher(self, url):
        self.calls.append(url)
        if url == TICKERS_URL:
            return {"0": {"ticker": "TEST", "cik_str": 123}}
        return self.sub if "/submissions/" in url else self.facts

    def test_daily_cache_persists_and_refreshes_next_date(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        self.assertEqual(svc.evaluate(RULE, {}, NOW)["status"], "REVIEW")
        self.assertEqual(len(self.calls), 2)
        svc.evaluate(RULE, {}, NOW + timedelta(minutes=5))
        self.assertEqual(len(self.calls), 2)
        new = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        new.evaluate(RULE, {}, NOW + timedelta(hours=2))
        self.assertEqual(len(self.calls), 2)
        new.evaluate(RULE, {}, NOW + timedelta(days=1))
        self.assertEqual(len(self.calls), 4)

    def test_read_only_does_not_write_but_reuses_memory(self):
        svc = FundamentalsService(self.temp.name, read_only=True, fetcher=self.fetcher)
        svc.evaluate(RULE, {}, NOW)
        svc.evaluate(RULE, {}, NOW)
        self.assertEqual(list(Path(self.temp.name).iterdir()), [])
        self.assertEqual(len(self.calls), 2)

    def test_failure_cached_through_new_process(self):
        def fail(url):
            self.calls.append(url)
            raise ValueError("HTTP 403")
        svc = FundamentalsService(self.temp.name, fetcher=fail)
        self.assertEqual(svc.evaluate(RULE, {}, NOW)["status"], "UNAVAILABLE")
        svc = FundamentalsService(self.temp.name, fetcher=fail)
        svc.evaluate(RULE, {}, NOW + timedelta(minutes=5))
        self.assertEqual(len(self.calls), 1)

    def test_fund_and_hk_do_not_fetch(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        self.assertEqual(svc.evaluate({"symbol": "ETF", "fundamental_policy": {"mode": "fund"}}, {}, NOW)["status"], "NOT_APPLICABLE")
        self.assertEqual(svc.evaluate({"symbol": "3419.HK"}, {}, NOW)["status"], "UNAVAILABLE")
        self.assertEqual(self.calls, [])

    def test_map_is_unique_and_verified_by_submissions(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        self.assertEqual(svc.evaluate({"symbol": "TEST"}, {}, NOW)["status"], "REVIEW")
        self.assertEqual(len(self.calls), 3)
        self.assertEqual(svc.evaluate({"symbol": "OTHER"}, {}, NOW)["status"], "UNAVAILABLE")

    def test_corrupt_and_future_cache_refetch(self):
        path = Path(self.temp.name) / "submissions-0000000123.json"
        path.write_text("not json")
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        svc.evaluate(RULE, {}, NOW)
        entry = json.loads(path.read_text())
        entry["fetched_at"] = (NOW + timedelta(days=1)).isoformat()
        path.write_text(json.dumps(entry))
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        svc.evaluate(RULE, {}, NOW)
        self.assertEqual(len(self.calls), 3)

    def test_path_traversal_rejected_without_fetch(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        self.assertEqual(svc.evaluate({"symbol": "../SECRET"}, {}, NOW)["status"], "UNAVAILABLE")
        self.assertEqual(self.calls, [])

    def test_financial_company_only_requests_filing_inventory(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        self.sub["sic"] = "6199"
        result = svc.evaluate(RULE, {}, NOW)
        self.assertEqual(result["status"], "REVIEW")
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(len(result["sources"]), 1)
        self.assertNotIn("companyfacts", result["source_fetch_times"])

    def test_requested_cik_mismatch_rejected_before_facts(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        self.sub["cik"] = 456
        result = svc.evaluate(RULE, {}, NOW)
        self.assertEqual(result["status"], "UNAVAILABLE")
        self.assertEqual(len(self.calls), 1)

    def test_parallel_same_issuer_fetches_once(self):
        svc = FundamentalsService(self.temp.name, fetcher=self.fetcher)
        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(lambda _: svc.evaluate(RULE, {}, NOW), range(4)))
        self.assertEqual(len(self.calls), 2)
        self.assertTrue(all(r["status"] == "REVIEW" for r in results))


class CurrentPeriodTests(unittest.TestCase):
    def setUp(self):
        self.sub, self.facts = fixture()
        self.gaap = self.facts["facts"]["us-gaap"]
        self.add("Revenues", 70)
        self.add("Revenues", 50, "2025-01-01", "2025-06-30")
        self.add("NetIncomeLoss", -2)
        self.add("NetCashProvidedByUsedInOperatingActivities", 8)
        self.add("PaymentsToAcquirePropertyPlantAndEquipment", 3)

    def add(self, tag, value, start="2026-01-01", end="2026-06-30"):
        fact = {"start": start, "end": end, "val": value, "accn": "0000000123-26-000002",
                "form": "10-Q", "filed": "2026-08-01"}
        self.gaap.setdefault(tag, {"units": {"USD": []}})["units"]["USD"].append(fact)

    def result(self, now=NOW):
        return analyze_fundamentals(RULE, self.sub, self.facts, now)

    def test_separate_matched_ytd_and_annual_periods(self):
        result = self.result()
        current = result["current_period"]
        self.assertEqual(result["metrics"]["revenue"], 110)
        self.assertEqual(current["metrics"]["revenue"], 70)
        self.assertAlmostEqual(current["metrics"]["revenue_growth_pct"], 40)
        self.assertEqual(current["metrics"]["ppe_free_cash_flow_proxy"], 5)
        self.assertEqual(current["period_days"], 181)
        self.assertIn("not standalone quarter", current["scope"])
        self.assertIn("not deducted", current["free_cash_flow_basis"])
        self.assertTrue(any("negative" in s for s in current["reasons"]))
        self.assertEqual(result["status"], "REVIEW")

    def test_three_month_cash_flow_cannot_mix_with_six_month_ytd(self):
        self.gaap["NetCashProvidedByUsedInOperatingActivities"]["units"]["USD"][-1]["start"] = "2026-04-01"
        self.assertNotIn("ppe_free_cash_flow_proxy", self.result()["current_period"]["metrics"])

    def test_prior_quarter_cannot_be_yoy_comparator(self):
        self.gaap["Revenues"]["units"]["USD"][-1]["start"] = "2025-04-01"
        self.assertNotIn("revenue_growth_pct", self.result()["current_period"]["metrics"])

    def test_conflicting_current_context_not_chosen(self):
        self.add("Revenues", 99)
        self.assertNotIn("revenue", self.result()["current_period"]["metrics"])

    def test_amended_filing_requires_new_review(self):
        self.sub["filings"]["recent"]["form"][0] = "10-Q/A"
        self.assertEqual(self.result()["current_period"]["status"], "UNAVAILABLE")

    def test_stale_current_period_is_explicitly_unavailable(self):
        now = datetime(2027, 4, 10, tzinfo=timezone.utc)
        self.assertEqual(self.result(now)["current_period"]["status"], "UNAVAILABLE")

    def test_future_current_fact_omitted(self):
        self.gaap["NetIncomeLoss"]["units"]["USD"][-1]["filed"] = "2026-09-11"
        self.assertNotIn("net_income", self.result()["current_period"]["metrics"])


if __name__ == "__main__":
    unittest.main()
