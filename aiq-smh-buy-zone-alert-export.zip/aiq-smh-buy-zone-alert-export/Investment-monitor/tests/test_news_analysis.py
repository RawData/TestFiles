from copy import deepcopy
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from news_analysis import analyze_news,select_evidence,validate_settings,validate_analysis,SYSTEM

NOW=datetime(2026,9,11,12,tzinfo=timezone.utc)
SETTINGS={"enabled":True,"model":"qwen3.5:9b","min_interval_seconds":60}


def report():
    text='The central bank left interest rates unchanged. Officials said inflation remains above target and policy will depend on incoming data.'
    return {'generated_at':NOW.isoformat(),'sources':[{'id':'fed','status':'AVAILABLE'}],
            'articles':[{'id':'e1','title':'Central bank leaves rates unchanged','snippet':text,
                         'url':'https://example.org/news','publisher':'example.org','collected_via':['fed'],
                         'fetched_at':NOW.isoformat(),'published_at':(NOW-timedelta(hours=1)).isoformat(),
                         'content_scope':'headline_and_snippet'}]}


def answer():
    return {'market_bias':'risk_on','summary':'Rate policy remains dependent on incoming data.',
            'drivers':[{'headline':'Rates unchanged','reported_fact':'The source reports unchanged interest rates.',
                        'interpretation':'A future inflation decline could ease rate pressure.',
                        'source_ids':['e1'],'evidence_quote':'The central bank left interest rates unchanged.',
                        'market_channels':['interest rates'],'confidence':'high'}],
            'scenarios':[],'watch_items':[{'condition':'Inflation declines','why_it_matters':'Could reduce rate pressure.', 'source_ids':['e1']}],
            'limitations':['Only one source is available.']}


def transport(data=None):
    return Mock(side_effect=[{'models':[{'name':'qwen3.5:9b','digest':'model-hash'}]},
          {'done':True,'done_reason':'stop','message':{'content':json.dumps(answer() if data is None else data)}}])


class NewsAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'analysis.json'
    def tearDown(self): self.tmp.cleanup()
    def test_local_request_payload_and_grounded_success(self):
        call=transport();result=analyze_news(report(),SETTINGS,self.path,NOW,call)
        self.assertEqual(result['status'],'CURRENT')
        self.assertEqual(result['analysis']['market_bias'],'unclear')
        self.assertEqual(result['analysis']['drivers'][0]['confidence'],'low')
        payload=call.call_args.args[2]
        self.assertFalse(payload['think']);self.assertFalse(payload['stream'])
        self.assertNotIn('tools',payload)
        self.assertIn('untrusted',payload['messages'][0]['content'])
        self.assertEqual(result['model_digest'],'model-hash')
    def test_unchanged_input_reuses_cached_analysis(self):
        call=transport();analyze_news(report(),SETTINGS,self.path,NOW,call)
        result=analyze_news(report(),SETTINGS,self.path,NOW+timedelta(minutes=2),call)
        self.assertTrue(result['cache_reused']);self.assertEqual(call.call_count,2)
    def test_new_input_deferred_without_resetting_retry_clock(self):
        call=transport();analyze_news(report(),SETTINGS,self.path,NOW,call)
        changed=report();changed['articles'][0]['snippet']+=' Updated.'
        r=analyze_news(changed,SETTINGS,self.path,NOW+timedelta(seconds=20),call)
        self.assertEqual(r['status'],'UNAVAILABLE')
        self.assertEqual(r['last_attempt_at'],NOW.isoformat())
        analyze_news(changed,SETTINGS,self.path,NOW+timedelta(seconds=40),call)
        self.assertEqual(call.call_count,2)
        r=analyze_news(changed,SETTINGS,self.path,NOW+timedelta(seconds=61),transport())
        self.assertEqual(r['status'],'CURRENT')
    def test_unknown_source_or_fabricated_quote_rejected(self):
        a=answer();a['drivers'][0]['source_ids']=['invented']
        self.assertEqual(analyze_news(report(),SETTINGS,self.path,NOW,transport(a))['status'],'UNAVAILABLE')
        self.path.unlink()
        a=answer();a['drivers'][0]['evidence_quote']='The market will definitely rally tomorrow'
        result=analyze_news(report(),SETTINGS,self.path,NOW,transport(a))
        self.assertEqual(result['status'],'CURRENT')
        self.assertEqual(result['analysis']['market_bias'],'unclear')
        self.assertEqual(result['analysis']['drivers'],[])
        self.assertEqual(result['reason'],'Local model response rejected by grounding checks; no model commentary was retained.')

    def test_source_reporting_is_replaced_with_the_verified_quote(self):
        a=answer();a['drivers'][0]['reported_fact']='The source reports that every bank has failed.'
        result=analyze_news(report(),SETTINGS,self.path,NOW,transport(a))
        driver=result['analysis']['drivers'][0]
        self.assertEqual(driver['headline'],'Central bank leaves rates unchanged')
        self.assertEqual(driver['reported_fact'],'The central bank left interest rates unchanged.')

    def test_unavailable_source_suppresses_directional_bias(self):
        r=report();r['sources'].append({'id':'bls-cpi','status':'UNAVAILABLE'})
        result=analyze_news(r,SETTINGS,self.path,NOW,transport())
        self.assertEqual(result['status'],'CURRENT')
        self.assertEqual(result['coverage']['source_coverage'],'DEGRADED')
        self.assertEqual(result['coverage']['unavailable_sources'],['bls-cpi'])
        self.assertEqual(result['analysis']['market_bias'],'unclear')

    def test_irrelevant_extracted_article_produces_neutral_digest_without_model(self):
        r=report();r['articles'][0].update(title='Tax-aware long-short strategy grows',snippet='Tax planning for wealthy investors.')
        r['articles'][0]['article']={'status':'EXTRACTED','text':'Tax planning details for high-net-worth clients.', 'attempted_at':NOW.isoformat()}
        call=Mock();result=analyze_news(r,SETTINGS,self.path,NOW,call)
        self.assertEqual(result['status'],'CURRENT')
        self.assertEqual(result['analysis']['market_bias'],'unclear')
        self.assertEqual(result['analysis']['drivers'],[])
        self.assertEqual(result['coverage']['excluded_irrelevant'],1)
        call.assert_not_called()

    def test_relevant_official_extracted_evidence_outranks_irrelevant_extracted_article(self):
        r=report();r['articles'][0]['collected_via']=['fed-policy']
        r['articles'][0]['article']={'status':'EXTRACTED','text':'The Federal Reserve kept interest rates unchanged.', 'attempted_at':NOW.isoformat()}
        irrelevant=deepcopy(r['articles'][0]);irrelevant.update(id='e2',title='Tax-aware strategy grows',snippet='Tax planning details.',publisher='other.example')
        irrelevant['collected_via']=['marketaux'];irrelevant['article']={'status':'EXTRACTED','text':'Tax planning details for wealthy clients.', 'attempted_at':NOW.isoformat()}
        r['articles'].append(irrelevant)
        evidence,coverage=select_evidence(r,NOW,validate_settings(SETTINGS))
        self.assertEqual([item['id'] for item in evidence],['e1'])
        self.assertEqual(evidence[0]['relevance_labels'],['central_banks_and_rates'])
        self.assertEqual(coverage['excluded_irrelevant'],1)
    def test_stale_snapshot_never_calls_model(self):
        call=Mock();r=report();r['generated_at']=(NOW-timedelta(hours=3)).isoformat()
        self.assertEqual(analyze_news(r,SETTINGS,self.path,NOW,call)['status'],'INSUFFICIENT_EVIDENCE')
        call.assert_not_called()
    def test_unknown_dates_not_relabelled_fresh(self):
        r=report();r['articles'][0]['published_at']=None
        call=Mock();result=analyze_news(r,SETTINGS,self.path,NOW,call)
        self.assertEqual(result['coverage']['excluded_unknown_date'],1)
        call.assert_not_called()
    def test_old_or_future_articles_excluded(self):
        for date in (NOW-timedelta(days=3),NOW+timedelta(hours=1)):
            r=report();r['articles'][0]['published_at']=date.isoformat()
            call=Mock();result=analyze_news(r,SETTINGS,self.path,NOW,call)
            self.assertEqual(result['status'],'INSUFFICIENT_EVIDENCE');call.assert_not_called()
    def test_citations_and_response_field_validation(self):
        a=answer();a['execute_order']='buy now'
        result=analyze_news(report(),SETTINGS,self.path,NOW,transport(a))
        self.assertEqual(result['status'],'UNAVAILABLE')
    def test_trade_instruction_rejected_despite_valid_citation(self):
        a=answer();a['drivers'][0]['interpretation']='Buy NVDA immediately.'
        self.assertEqual(analyze_news(report(),SETTINGS,self.path,NOW,transport(a))['status'],'UNAVAILABLE')
    def test_verified_long_quote_is_shortened_without_inventing_text(self):
        r=report();r['articles'][0]['snippet']=' '.join('word'+str(i) for i in range(35))
        a=answer();a['drivers'][0]['evidence_quote']=r['articles'][0]['snippet']
        result=analyze_news(r,SETTINGS,self.path,NOW,transport(a))
        self.assertEqual(result['status'],'CURRENT')
        self.assertEqual(len(result['analysis']['drivers'][0]['evidence_quote'].split()),25)
    def test_terminal_quote_punctuation_normalized_but_words_preserved(self):
        r=report();r['articles'][0]['snippet']='The central bank left interest rates unchanged, according to the statement.'
        result=analyze_news(r,SETTINGS,self.path,NOW,transport())
        self.assertEqual(result['status'],'CURRENT')
        self.assertEqual(result['analysis']['drivers'][0]['evidence_quote'],'The central bank left interest rates unchanged')
    def test_forecast_cannot_be_reported_as_observed_fact(self):
        r=report();r['articles'][0]['snippet']='We forecast that oil production will increase next year.'
        a=answer();a['drivers'][0].update(evidence_quote=r['articles'][0]['snippet'],reported_fact='Oil production increased.')
        self.assertEqual(analyze_news(r,SETTINGS,self.path,NOW,transport(a))['status'],'UNAVAILABLE')
    def test_old_publisher_date_cannot_be_refreshed_by_feed(self):
        r=report();r['articles'][0]['article']={'publisher_date':'2026-09-01','status':'PARTIAL_OR_UNREADABLE'}
        call=Mock();result=analyze_news(r,SETTINGS,self.path,NOW,call)
        self.assertEqual(result['status'],'INSUFFICIENT_EVIDENCE');call.assert_not_called()
    def test_timeout_persists_failure_and_throttles_retry(self):
        call=Mock(side_effect=TimeoutError('private error body'))
        result=analyze_news(report(),SETTINGS,self.path,NOW,call)
        self.assertNotIn('private',json.dumps(result))
        analyze_news(report(),SETTINGS,self.path,NOW+timedelta(seconds=10),call)
        self.assertEqual(call.call_count,1)
    def test_model_must_be_installed_locally(self):
        call=Mock(return_value={'models':[]})
        self.assertEqual(analyze_news(report(),SETTINGS,self.path,NOW,call)['status'],'UNAVAILABLE')
        self.assertEqual(call.call_count,1)
    def test_endpoints_and_cloud_models_rejected(self):
        for endpoint in ('https://example.com','http://127.0.0.1.evil.test','http://user:secret@localhost:11434','http://localhost:11434/x'):
            with self.assertRaises(ValueError):validate_settings({'endpoint':endpoint})
        with self.assertRaises(ValueError):validate_settings({'model':'qwen:cloud'})
    def test_no_call_when_disabled(self):
        call=Mock();self.assertEqual(analyze_news(report(),{},self.path,NOW,call)['status'],'DISABLED');call.assert_not_called()
    def test_input_budget_and_duplicates(self):
        r=report();r['articles'][0]['snippet']='word '*1000
        duplicate=deepcopy(r['articles'][0]);duplicate['id']='e2';duplicate['article']={'duplicate_of':'e1'}
        r['articles'].append(duplicate)
        evidence,coverage=select_evidence(r,NOW,validate_settings({'max_input_chars':2000}))
        self.assertEqual(len(evidence),1);self.assertEqual(coverage['excluded_duplicates'],1)
        self.assertLessEqual(len(evidence[0]['title'])+len(evidence[0]['text']),2000)
    def test_expiry_never_outlives_evidence(self):
        r=report();r['articles'][0]['published_at']=(NOW-timedelta(hours=47,minutes=55)).isoformat()
        result=analyze_news(r,SETTINGS,self.path,NOW,transport())
        self.assertEqual(result['expires_at'],(NOW+timedelta(minutes=5)).isoformat())


if __name__=='__main__':unittest.main()
