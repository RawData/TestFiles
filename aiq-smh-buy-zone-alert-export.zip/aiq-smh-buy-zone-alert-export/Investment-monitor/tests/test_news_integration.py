from copy import deepcopy
from datetime import datetime,timezone
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from news_collector import collect,parse_feed
from watchlist_email import render_report
from test_news_analysis import answer
from test_news_collector import RSS,SOURCE,NOW


class NewsIntegrationTests(unittest.TestCase):
    def test_collector_wires_local_analysis_and_artifacts(self):
        source={**SOURCE,'id':'fed-policy'}
        rss=RSS.replace(b'Policy update',b'Federal Reserve interest rate update').replace(b'Reported change',b'Federal Reserve policy statement')
        identity=parse_feed(rss,source,NOW)[0][0]['id']
        a=answer()
        for item in a['drivers']+a['watch_items']:item['source_ids']=[identity]
        a['drivers'][0]['evidence_quote']='Federal Reserve interest rate update Federal Reserve policy statement'
        call=Mock(side_effect=[{'models':[{'name':'qwen3.5:9b','digest':'test'}]},
                 {'done':True,'done_reason':'stop','message':{'content':json.dumps(a)}}])
        with tempfile.TemporaryDirectory() as folder:
            r=collect({'sources':[source],'model_analysis':{'enabled':True}},folder,Path(folder)/'unused',NOW,
                      Mock(return_value=rss),model_transport=call)
            self.assertEqual(r['model_status'],'CURRENT')
            self.assertEqual(json.loads((Path(folder)/'model-evidence.json').read_text())['model_status'],'CURRENT')
            self.assertTrue((Path(folder)/'news-analysis.json').exists())
            self.assertEqual(call.call_count,2)
    def test_cached_commentary_does_not_change_watchlist_result(self):
        report={'session_date':'2026-09-11','rows':[{'symbol':'FISV','technical':{'status':'FAIL'},'price':50}]}
        baseline=deepcopy(report)
        report['news_context']={'version':1,'status':'UNAVAILABLE','reason':'No fresh evidence'}
        subject,plain,html=render_report(report)
        self.assertEqual(report['rows'],baseline['rows'])
        self.assertIn('1 FAIL',subject)
        self.assertIn('News analysis unavailable',plain)
        self.assertIn('FISV',html)


if __name__=='__main__':unittest.main()
