"""Preserve source attribution and review conditions in mixed watchlists."""

from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from monitor import DEFAULT_CONFIG, Quote, alert_text, load_config, observe, run_cycle, send_channel

NOW = datetime(2026, 9, 8, 15, 0, tzinfo=timezone.utc)
SESSION = {"session_date": "2026-09-08", "open": NOW.replace(hour=13, minute=30),
           "close": NOW.replace(hour=20), "slot": "2026-09-08:10:30"}


class ReviewLabelsTests(unittest.TestCase):
    def setUp(self):
        self.config = load_config(DEFAULT_CONFIG)
        self.config["technical_analysis"] = {"enabled": False}
        self.config["zone_source"] = "Legacy Arora model thresholds"
        self.legacy = {"symbol": "AIQ", "low": "48.13", "high": "55.68"}
        self.research = {"symbol": "NVDA", "low": "210", "high": "220",
                         "alert_kind": "review_zone", "source": "Independent September research",
                         "review_notes": "Check current revenue, margins and portfolio overlap."}

    def item(self, rule, price):
        q = Quote(rule["symbol"], Decimal(price), NOW)
        return rule, observe(None, q, rule, SESSION["slot"], ["mac"], NOW)

    def test_legacy_title_and_source_are_preserved(self):
        title, body = alert_text([self.item(self.legacy, "52")], self.config)
        self.assertEqual(title, "WATCH ONLY - buy conditions unconfirmed | Arora saved-zone alert: AIQ")
        self.assertIn("Threshold source: Legacy Arora model thresholds", body)
        self.assertNotIn("review only", body)

    def test_independent_alert_uses_its_own_source_and_conditions(self):
        title, body = alert_text([self.item(self.research, "215")], self.config)
        self.assertEqual(title, "WATCH ONLY - buy conditions unconfirmed | Saved price review alert: NVDA")
        self.assertIn("(review only)", body)
        self.assertIn("Threshold source: Independent September research", body)
        self.assertIn("Review conditions: Check current revenue", body)
        self.assertNotIn("Legacy Arora model thresholds", body)
        self.assertIn("Only the price condition is checked automatically", body)

    def test_mixed_sources_are_attached_to_the_correct_ticker(self):
        title, body = alert_text([self.item(self.legacy, "52"),
                                 self.item(self.research, "215")], self.config)
        self.assertEqual(title, "WATCH ONLY - buy conditions unconfirmed | Saved price review alert: AIQ, NVDA")
        legacy, research = body.split("NVDA:", 1)
        self.assertIn("Threshold source: Legacy Arora model thresholds", legacy)
        self.assertNotIn("Independent September research", legacy)
        self.assertIn("Threshold source: Independent September research", research)
        self.assertNotIn("Legacy Arora model thresholds", research)

    def test_support_watch_label_reaches_mac_banner(self):
        rule = dict(self.research, symbol="AAOI", low="97", high="102", alert_kind="support_watch",
                    review_notes="Support observation only; no standing investment buy recommendation.")
        title, body = alert_text([self.item(rule, "100")], self.config)
        self.assertIn("(support watch only)", body)
        with patch("monitor.subprocess.run") as run:
            send_channel("mac", title, body, self.config, Path("/unused"))
        argv = run.call_args.args[0]
        self.assertIn("(support watch only)", argv[-1])
        self.assertIn("AAOI: $100.00", argv[-1])

    def test_nav_gate_is_reported_as_manual_not_automatically_verified(self):
        rule = dict(self.research, symbol="BMEZ", low="15.8", high="16.4",
                    review_notes="Manually verify a discount of at least 12% to current NAV.")
        _, body = alert_text([self.item(rule, "16")], self.config)
        self.assertIn("at least 12% to current NAV", body)
        self.assertIn("NAV conditions are not verified by this monitor", body)

    def test_independent_rule_requires_provenance_and_conditions(self):
        for missing in ("source", "review_notes"):
            with self.subTest(missing=missing), tempfile.TemporaryDirectory() as folder:
                c = deepcopy(self.config)
                rule = dict(self.research)
                rule.pop(missing)
                c["watchlist"] = [rule]
                p = Path(folder) / "config.json"
                p.write_text(json.dumps(c))
                with self.assertRaises(ValueError):
                    load_config(p)

    def test_new_rules_do_not_reset_a_completed_legacy_slot(self):
        c = deepcopy(self.config)
        c["watchlist"] = [self.legacy, self.research]
        c["alerts"]["mac"] = True
        c["alerts"]["email"]["enabled"] = False
        legacy_state = self.item(self.legacy, "52")[1]
        legacy_state["pending"] = None
        state = {"version": 1, "symbols": {"AIQ": deepcopy(legacy_state)}}
        fetch = Mock(return_value=Quote("NVDA", Decimal("215"), NOW))
        send = Mock()
        result = run_cycle(c, state, NOW, SESSION, fetcher=fetch, sender=send)
        self.assertEqual(result, 0)
        fetch.assert_called_once_with("NVDA")
        self.assertEqual(state["symbols"]["AIQ"], legacy_state)
        self.assertEqual(send.call_count, 1)
        self.assertIn("WATCH ONLY - buy conditions unconfirmed | Saved price review alert: NVDA", send.call_args.args)


if __name__ == "__main__":
    unittest.main()
