import copy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

import monitor
from investment_checks import InvestmentService, evidence_lines, validate_settings

NOW = datetime(2026, 9, 9, 15, tzinfo=timezone.utc)
RULE = {"symbol": "CSV", "low": "32", "high": "34", "alert_kind": "review_zone",
        "source": "Saved research", "review_notes": "Require a base and cash flow."}


def evidence(status="REVIEW"):
    return {"status": status, "complete": False, "as_of": "2026-06-30",
            "metrics": {"net_income": -5}, "reasons": ["Partial filing evidence"],
            "unverified": ["Guidance not parsed"]}


def investment():
    return {"overall": "REVIEW", "nav": evidence("NOT_APPLICABLE"),
            "fundamentals": evidence(), "portfolio": evidence(), "arora": evidence("UNVERIFIED")}


class Integration(unittest.TestCase):
    def setUp(self):
        self.config = {"version": 1, "watchlist": [copy.deepcopy(RULE)], "zone_source": "saved",
                       "investment_analysis": {"enabled": True},
                       "alerts": {"mac": True, "email": {"enabled": False}}, "max_quote_age_seconds": 1200}
        self.state = {"version": 1, "symbols": {}}
        self.service = Mock()
        self.service.batch.return_value = ({"CSV": investment()}, evidence())
        self.sender = Mock()

    def run_check(self, now=NOW, **kwargs):
        session = {"market": "US", "slot": now.isoformat(), "open": NOW.replace(hour=13, minute=30),
                   "close": NOW.replace(hour=20)}
        return monitor.run_cycle(self.config, self.state, now, session,
            fetcher=lambda symbol: monitor.Quote(symbol, Decimal("33"), now),
            sender=self.sender, investment_evaluator=self.service, **kwargs)

    def test_evidence_added_to_alert_and_persisted(self):
        self.assertEqual(self.run_check(), 0)
        body = self.sender.call_args.args[2]
        self.assertIn("AUTOMATED INVESTMENT EVIDENCE", body)
        self.assertIn("Fundamentals: REVIEW", body)
        self.assertIn("Not verified: Guidance not parsed", body)
        self.assertIn("suitability is not assessed", body)
        self.assertNotIn("Company fundamentals and NAV conditions are not verified by this monitor.", body)
        self.assertIn("CSV", self.state["investment_reviews"])

    def test_regular_recheck_without_duplicate_delivery(self):
        self.run_check()
        self.run_check(NOW + timedelta(minutes=5))
        self.assertEqual(self.service.batch.call_count, 2)
        self.assertEqual(self.sender.call_count, 1)

    def test_migration_preserves_acknowledged_price_event(self):
        entry = monitor.observe(None, monitor.Quote("CSV", Decimal("33"), NOW), RULE, "old", ["mac"], NOW)
        entry["pending"] = None
        self.state["symbols"]["CSV"] = entry
        self.run_check()
        self.sender.assert_not_called()
        self.assertIn("investment", self.state["symbols"]["CSV"])

    def test_source_failure_keeps_price_alert_honest(self):
        self.service.batch.side_effect = RuntimeError("No data")
        self.run_check()
        self.assertEqual(self.sender.call_count, 1)
        self.assertIn("Fundamentals: UNAVAILABLE", self.sender.call_args.args[2])

    def test_dry_run_does_not_mutate_or_send(self):
        prior = copy.deepcopy(self.state)
        persist = Mock()
        self.run_check(dry_run=True, persist=persist)
        self.assertEqual(self.state, prior)
        self.sender.assert_not_called()
        persist.assert_not_called()

    def test_source_delay_cannot_make_stale_quote_actionable(self):
        late = NOW + timedelta(minutes=21)
        clock = Mock(side_effect=[NOW, NOW, late])
        self.assertEqual(self.run_check(clock=clock), 1)
        self.sender.assert_not_called()


class Service(unittest.TestCase):
    def test_shared_portfolio_and_no_aggregate_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "policies.json"
            path.write_text(json.dumps({"instruments": {"CSV": {"fundamental_policy": {"mode": "company"}}}}))
            config = {"investment_analysis": {"policies_file": str(path), "portfolio_file": "unused"}, "watchlist": [RULE]}
            nav, fundamentals, portfolio = Mock(), Mock(), Mock()
            nav.evaluate.return_value = evidence("PASS")
            fundamentals.evaluate.return_value = evidence("PASS")
            portfolio.prepare.return_value = {"metrics": {"total_value_usd": 100}}
            portfolio.evaluate.return_value = evidence("REVIEW")
            service = InvestmentService(config, tmp, nav=nav, fundamentals=fundamentals, portfolio=portfolio)
            result, _ = service.batch([RULE], {}, NOW)
            self.assertEqual(result["CSV"]["overall"], "REVIEW")
            self.assertEqual(result["CSV"]["arora"]["status"], "UNVERIFIED")
            portfolio.prepare.assert_called_once()

    def test_settings_reject_missing_policy_before_runtime(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "policies.json").write_text('{"version":1,"instruments":{}}')
            config = {"watchlist": [RULE], "investment_analysis": {"enabled": True,
                      "policies_file": "policies.json", "portfolio_file": "portfolio.json"}}
            with self.assertRaisesRegex(ValueError, "missing CSV"):
                validate_settings(config, root / "config.json")

    def test_text_includes_dated_scope_and_no_fabricated_metrics(self):
        text = "\n".join(evidence_lines(investment()))
        self.assertIn("2026-06-30", text)
        self.assertIn("net income: -5.00", text)
        self.assertNotIn("net margin", text)
        self.assertIn("no combined buy approval", text)


if __name__ == "__main__":
    unittest.main()
