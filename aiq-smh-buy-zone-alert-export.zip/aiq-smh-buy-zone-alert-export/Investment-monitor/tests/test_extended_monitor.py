"""Offline tests of extended feed integrity, isolated alerts and live-run integration."""
import copy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

import monitor
from market_clock import extended_market_session

UTC = timezone.utc
NOW = datetime(2026, 9, 8, 12, 5, tzinfo=UTC)  # 08:05 NY
PRE = extended_market_session(NOW)
POST_NOW = datetime(2026, 9, 8, 21, 5, tzinfo=UTC)
POST = extended_market_session(POST_NOW)
RULE = {'symbol': 'AIQ', 'low': '48.13', 'high': '55.68'}


def payload(points, **meta):
    identity = {'symbol': 'AIQ', 'currency': 'USD', 'exchangeTimezoneName': 'America/New_York',
                'dataGranularity': '1m', 'regularMarketPrice': 52.01,
                'regularMarketTime': int(NOW.timestamp())}
    identity.update(meta)
    return {'chart': {'error': None, 'result': [{'meta': identity,
        'timestamp': [int(stamp.timestamp()) for stamp, _ in points],
        'indicators': {'quote': [{'close': [price for _, price in points]}]}}]}}


def quote(phase='pre', now=NOW, price='52', age=2):
    return monitor.Quote('AIQ', Decimal(price), now - timedelta(minutes=age), 'USD',
                         monitor.EXTENDED_SOURCE, phase)


def config():
    c = monitor.load_config(monitor.DEFAULT_CONFIG)
    c['watchlist'] = [copy.deepcopy(RULE), {'symbol': '3419.HK', 'market': 'HK',
                      'currency': 'HKD', 'low': '9.15', 'high': '9.4'}]
    c['alerts']['email']['enabled'] = False
    c['alerts']['mac'] = True
    c['extended_hours'] = True
    return c


class ExtendedParsing(unittest.TestCase):
    def test_uses_completed_in_phase_bar_and_ignores_regular_metadata(self):
        data = payload([(NOW-timedelta(minutes=4), 51.5), (NOW-timedelta(minutes=1), 52.5), (NOW, 99)])
        q = monitor.parse_extended_quote('AIQ', data, PRE, NOW)
        self.assertEqual(q.price, Decimal('52.5'))
        self.assertEqual(q.phase, 'pre')
        self.assertIn('chart', q.source)
        monitor.validate_quote(q, NOW, PRE)

    def test_does_not_use_previous_day_regular_or_other_phase_bars(self):
        for points in [[(NOW-timedelta(days=1), 52)], [(NOW.replace(hour=14), 52)],
                       [(NOW.replace(hour=7), 52)], []]:
            with self.subTest(points=points), self.assertRaises(ValueError):
                monitor.parse_extended_quote('AIQ', payload(points), PRE, NOW)

    def test_no_fallback_to_regular_metadata(self):
        with self.assertRaises(ValueError):
            monitor.parse_extended_quote('AIQ', payload([]), PRE, NOW)

    def test_skips_incomplete_and_appended_irregular_timestamp(self):
        data = payload([(NOW-timedelta(minutes=2), 51), (NOW-timedelta(seconds=75), 99), (NOW, 100)])
        self.assertEqual(monitor.parse_extended_quote('AIQ', data, PRE, NOW).price, Decimal('51'))

    def test_identity_granularity_and_invalid_prices_fail(self):
        for changes in [{'symbol':'SMH'}, {'currency':'HKD'}, {'exchangeTimezoneName':'Asia/Hong_Kong'}, {'dataGranularity':'1d'}]:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                monitor.parse_extended_quote('AIQ', payload([(NOW-timedelta(minutes=2),52)], **changes), PRE, NOW)
        for price in [0, -1, float('nan'), True, 'nonsense']:
            with self.subTest(price=price), self.assertRaises(ValueError):
                monitor.parse_extended_quote('AIQ', payload([(NOW-timedelta(minutes=2),price)]), PRE, NOW)

    def test_rejects_stale_and_wrong_session_quotes(self):
        for q in [quote(age=22), quote(phase='regular'), quote(phase='post')]:
            with self.assertRaises(ValueError): monitor.validate_quote(q, NOW, PRE)
        with self.assertRaises(ValueError): monitor.validate_quote(quote(), NOW, dict(PRE, phase='regular'))

    def test_post_bar_and_strict_close_boundary(self):
        q = monitor.parse_extended_quote('AIQ', payload([(POST_NOW-timedelta(minutes=2),53)]), POST, POST_NOW)
        self.assertEqual(q.phase,'post')
        monitor.validate_quote(q,POST_NOW,POST)
        at_end = datetime(2026,9,9,0,5,tzinfo=UTC)
        final = extended_market_session(at_end)
        good = monitor.parse_extended_quote('AIQ',payload([(final['close']-timedelta(minutes=1),53)]),final,at_end)
        monitor.validate_quote(good,at_end,final)
        with self.assertRaises(ValueError):
            monitor.validate_quote(quote('post',final['close'],age=2),at_end,final)
        with self.assertRaises(ValueError):
            monitor.parse_extended_quote('AIQ',payload([(final['close'],53)]),final,at_end)
        monitor.validate_quote(good,final['close']+timedelta(minutes=20),final)
        with self.assertRaises(ValueError):
            monitor.validate_quote(good,final['close']+timedelta(minutes=20,seconds=1),final)

    def test_naive_now_and_hk_rejected(self):
        with self.assertRaises(ValueError): monitor.parse_extended_quote('AIQ', payload([]), PRE, NOW.replace(tzinfo=None))
        with self.assertRaises(ValueError): monitor.parse_extended_quote('3419.HK', payload([]), PRE, NOW)

    def test_timestamp_does_not_claim_confirmed_trade(self):
        d=quote().as_dict()
        self.assertIn('not a verified last-trade',d['timestamp_basis'])


class ExtendedStateAndDelivery(unittest.TestCase):
    def setUp(self):
        self.c=config()
        self.regular={'status':'above','zone_key':monitor.zone_key(RULE),'last_slot':'2026-09-04:close',
                      'quote':monitor.Quote('AIQ',Decimal('60'),NOW-timedelta(days=4)).as_dict(),'pending':None}
        self.state={'version':1,'symbols':{'AIQ':copy.deepcopy(self.regular)}}
        self.sender=Mock();self.persist=Mock()

    def run_pre(self, fetcher=None, **kwargs):
        return monitor.run_cycle(self.c,self.state,NOW,{'US':PRE},fetcher=fetcher or Mock(return_value=quote()),
                                 sender=self.sender,persist=self.persist,state_key='pre_symbols',**kwargs)

    def test_separate_tracking_preserves_regular_and_deduplicates(self):
        fetch=Mock(return_value=quote())
        self.assertEqual(self.run_pre(fetch),0)
        fetch.assert_called_once_with('AIQ')
        self.assertEqual(self.state['symbols']['AIQ'],self.regular)
        self.assertEqual(self.sender.call_count,1)
        self.assertIn('Pre-market indicative price review',self.sender.call_args.args[1])
        self.assertIn('pre-market chart price',self.sender.call_args.args[2])
        self.assertEqual(self.run_pre(fetch),0)
        self.assertEqual(fetch.call_count,1)

    def test_post_does_not_overwrite_pre_or_regular(self):
        self.run_pre();pre=copy.deepcopy(self.state['pre_symbols'])
        result=monitor.run_cycle(self.c,self.state,POST_NOW,{'US':POST},fetcher=lambda _:quote('post',POST_NOW),
                                 sender=self.sender,state_key='post_symbols')
        self.assertEqual(result,0)
        self.assertEqual(self.state['symbols']['AIQ'],self.regular)
        self.assertEqual(self.state['pre_symbols'],pre)
        self.assertEqual(self.state['post_symbols']['AIQ']['quote']['phase'],'post')
        self.assertIn('After-hours indicative price review',self.sender.call_args.args[1])

    def test_no_stale_retry_of_pending_extended_alert(self):
        self.sender.side_effect=RuntimeError('offline')
        self.assertEqual(self.run_pre(),1)
        self.sender.reset_mock()
        self.assertEqual(self.run_pre(Mock(return_value=quote(age=22))),1)
        self.sender.assert_not_called()
        self.assertIsNotNone(self.state['pre_symbols']['AIQ']['pending'])

    def test_extended_exit_cancels_only_its_pending_alert(self):
        self.sender.side_effect=RuntimeError('offline');self.run_pre();self.sender.reset_mock()
        self.assertEqual(self.run_pre(Mock(return_value=quote(price='60'))),0)
        self.sender.assert_not_called()
        self.assertIsNone(self.state['pre_symbols']['AIQ']['pending'])
        self.assertEqual(self.state['symbols']['AIQ'],self.regular)

    def test_dry_run_and_wrong_store_guard(self):
        before=copy.deepcopy(self.state)
        self.assertEqual(self.run_pre(dry_run=True),0)
        self.assertEqual(self.state,before);self.sender.assert_not_called();self.persist.assert_not_called()
        with self.assertRaises(ValueError):
            monitor.run_cycle(self.c,self.state,NOW,{'US':PRE},state_key='symbols')

    def test_state_round_trip_and_malformed_extended_store(self):
        self.run_pre()
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'state.json';p.write_text(json.dumps(self.state))
            self.assertEqual(monitor.load_state(p),self.state)
            bad=copy.deepcopy(self.state);bad['pre_symbols']['AIQ']['quote']['phase']='regular'
            p.write_text(json.dumps(bad))
            with self.assertRaises(ValueError):monitor.load_state(p)
            bad=copy.deepcopy(self.state);bad['post_symbols']=[]
            p.write_text(json.dumps(bad))
            with self.assertRaises(ValueError):monitor.load_state(p)

    def test_main_processes_hk_and_us_premarket_independently(self):
        c=config();c['alerts']['email']['enabled']=False
        frozen=Mock();frozen.now.return_value=NOW
        with patch.object(monitor,'datetime',frozen), patch.object(monitor,'load_config',return_value=c), \
             patch.object(monitor,'load_state',return_value=copy.deepcopy(self.state)), \
             patch.object(monitor,'market_session',side_effect=lambda now,m: {'market':m,'slot':'HK:slot'} if m=='HK' else None), \
             patch.object(monitor,'extended_market_session',return_value=PRE), \
             patch.object(monitor,'run_cycle',return_value=0) as cycle:
            self.assertEqual(monitor.main(['--dry-run']),0)
            self.assertEqual(cycle.call_count,2)
            self.assertEqual(cycle.call_args_list[1].kwargs['state_key'],'pre_symbols')

    def test_config_opt_in_requires_boolean(self):
        with tempfile.TemporaryDirectory() as tmp:
            c=monitor.load_config(monitor.DEFAULT_CONFIG);c['extended_hours']='yes'
            p=Path(tmp)/'config.json';p.write_text(json.dumps(c))
            with self.assertRaises(ValueError):monitor.load_config(p)

    def test_separate_stream_results_preserve_failure(self):
        self.assertEqual(self.run_pre(Mock(side_effect=ValueError('provider failed'))),1)
        result=monitor.run_cycle(self.c,self.state,POST_NOW,{'US':POST},fetcher=lambda _:quote('post',POST_NOW),
                                 sender=self.sender,state_key='post_symbols')
        self.assertEqual(result,0)
        self.assertEqual(self.state['last_runs']['pre']['errors'],1)
        self.assertEqual(self.state['last_runs']['post']['errors'],0)

    def test_main_aggregates_regular_close_failure_and_successful_post(self):
        now=datetime(2026,9,8,20,5,tzinfo=UTC)
        c=config();c['watchlist']=[RULE]
        state={'version':1,'symbols':{}}
        def cycle(config,state,now,session,**options):
            phase='post' if options.get('state_key')=='post_symbols' else 'regular'
            errors=0 if phase=='post' else 1
            state.setdefault('last_runs',{})[phase]={'slot':phase,'requested':1,'fresh':1-errors,
                                                    'errors':errors,'checked_at':now.isoformat()}
            return errors
        frozen=Mock();frozen.now.return_value=now
        with tempfile.TemporaryDirectory() as tmp, patch.object(monitor,'datetime',frozen), \
             patch.object(monitor,'runtime_home',return_value=Path(tmp)), \
             patch.object(monitor,'load_config',return_value=c),patch.object(monitor,'load_state',return_value=state), \
             patch.object(monitor,'run_cycle',side_effect=cycle):
            self.assertEqual(monitor.main([]),1)
            saved=json.loads((Path(tmp)/'state.json').read_text())
            self.assertEqual(saved['last_run']['errors'],1)
            self.assertEqual(saved['last_run']['requested'],2)
            self.assertEqual(saved['last_run']['fresh'],1)
            self.assertEqual(set(saved['last_runs']),{'regular','post'})


if __name__=='__main__':unittest.main()
