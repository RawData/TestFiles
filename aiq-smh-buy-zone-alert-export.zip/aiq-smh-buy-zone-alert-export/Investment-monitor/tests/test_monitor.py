"""Guard against false price alerts and lost or repeated entry notifications.

These tests use a real exchange-session-shaped fixture, but never contact a
quote provider, send mail, display notifications, or access the user's state.
"""

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
import smtplib
import unittest
from unittest.mock import Mock, patch

from monitor import (
    DEFAULT_CONFIG, Quote, alert_text, classify, load_config, observe, parse_quote,
    run_cycle, send_channel, validate_quote,
)


def utc(value: str) -> datetime:
    return datetime.fromisoformat(value).replace(tzinfo=timezone.utc)


NOW = utc("2026-09-08T15:05:00")
SESSION = {
    "session_date": "2026-09-08",
    "open": utc("2026-09-08T13:30:00"),
    "close": utc("2026-09-08T20:00:00"),
    "slot": "2026-09-08:10:30",
}
RULE = {"symbol": "AIQ", "low": "48.13", "high": "55.68"}
CHANNELS = ["mac", "email:first@example.test", "email:second@example.test"]


def quote(price="52.00", timestamp=None, currency="USD"):
    return Quote(
        symbol="AIQ",
        price=Decimal(price),
        timestamp=timestamp or NOW - timedelta(minutes=5),
        currency=currency,
    )


def payload(**changes):
    meta = {
        "symbol": "AIQ",
        "regularMarketPrice": 52.01,
        "regularMarketTime": int((NOW - timedelta(minutes=5)).timestamp()),
        "currency": "USD",
        "exchangeTimezoneName": "America/New_York",
    }
    meta.update(changes)
    return {"chart": {"result": [{"meta": meta}], "error": None}}


class QuoteParsingTests(unittest.TestCase):
    def test_uses_regular_market_price_and_timestamp(self):
        result = parse_quote("AIQ", payload())
        self.assertEqual(result.symbol, "AIQ")
        self.assertEqual(result.price, Decimal("52.01"))
        self.assertEqual(result.timestamp, NOW - timedelta(minutes=5))
        self.assertEqual(result.currency, "USD")

    def test_provider_error_does_not_become_a_zero_price(self):
        for data in (
            {"chart": {"result": None, "error": {"description": "Not Found"}}},
            {"chart": {"result": [], "error": None}},
            {"chart": {"result": [{"meta": {}}], "error": None}},
        ):
            with self.subTest(data=data), self.assertRaises(ValueError):
                parse_quote("AIQ", data)

    def test_mismatched_symbol_rejected(self):
        with self.assertRaises(ValueError):
            parse_quote("AIQ", payload(symbol="SMH"))

    def test_other_exchange_timezone_rejected(self):
        with self.assertRaises(ValueError):
            parse_quote("AIQ", payload(exchangeTimezoneName="Europe/London"))

    def test_missing_quote_time_rejected(self):
        data = payload()
        del data["chart"]["result"][0]["meta"]["regularMarketTime"]
        with self.assertRaises(ValueError):
            parse_quote("AIQ", data)

    def test_bad_prices_are_never_valid_quotes(self):
        for price in (None, 0, -1, "NaN", "Infinity", "not a number"):
            with self.subTest(price=price), self.assertRaises(ValueError):
                parsed = parse_quote("AIQ", payload(regularMarketPrice=price))
                validate_quote(parsed, NOW, SESSION)

    def test_missing_currency_is_not_silently_assumed_to_be_dollars(self):
        data = payload()
        del data["chart"]["result"][0]["meta"]["currency"]
        with self.assertRaises(ValueError):
            parsed = parse_quote("AIQ", data)
            validate_quote(parsed, NOW, SESSION)


class QuoteFreshnessTests(unittest.TestCase):
    def test_recent_and_delayed_prices_are_accepted(self):
        for age in (0, 5 * 60, 19 * 60, 20 * 60):
            with self.subTest(age=age):
                validate_quote(quote(timestamp=NOW - timedelta(seconds=age)), NOW, SESSION)

    def test_stale_price_rejected(self):
        with self.assertRaises(ValueError):
            validate_quote(quote(timestamp=NOW - timedelta(seconds=1201)), NOW, SESSION)

    def test_future_price_beyond_clock_tolerance_rejected(self):
        with self.assertRaises(ValueError):
            validate_quote(quote(timestamp=NOW + timedelta(seconds=61)), NOW, SESSION)

    def test_other_currency_rejected(self):
        with self.assertRaises(ValueError):
            validate_quote(quote(currency="EUR"), NOW, SESSION)

    def test_naive_quote_timestamp_rejected(self):
        with self.assertRaises(ValueError):
            validate_quote(quote(timestamp=datetime(2026, 9, 8, 15, 0)), NOW, SESSION)

    def test_invalid_price_rejected_even_if_quote_was_constructed_directly(self):
        for price in ("0", "-1", "NaN", "Infinity"):
            with self.subTest(price=price), self.assertRaises(ValueError):
                validate_quote(quote(price), NOW, SESSION)

    def test_previous_session_rejected_even_if_age_limit_is_permissive(self):
        with self.assertRaises(ValueError):
            validate_quote(
                quote(timestamp=utc("2026-09-04T20:00:00")),
                NOW,
                SESSION,
                max_age_seconds=7 * 24 * 60 * 60,
            )

    def test_pre_market_and_after_hours_quotes_rejected(self):
        for stamp, now in (
            (SESSION["open"] - timedelta(seconds=1), SESSION["open"] + timedelta(minutes=5)),
            (SESSION["close"] + timedelta(seconds=6), SESSION["close"] + timedelta(minutes=5)),
        ):
            with self.subTest(stamp=stamp), self.assertRaises(ValueError):
                validate_quote(quote(timestamp=stamp), now, SESSION)

    def test_close_quote_accepted_in_closing_window(self):
        validate_quote(
            quote(timestamp=SESSION["close"]),
            SESSION["close"] + timedelta(minutes=5),
            SESSION,
        )

    def test_final_minute_quote_required_for_closing_slot(self):
        closing = dict(SESSION, slot="2026-09-08:close")
        now = SESSION["close"] + timedelta(minutes=5)
        validate_quote(quote(timestamp=SESSION["close"] - timedelta(minutes=1)), now, closing)
        with self.assertRaises(ValueError):
            validate_quote(quote(timestamp=SESSION["close"] - timedelta(seconds=61)), now, closing)

    def test_closing_auction_timestamp_grace_accepts_regular_market_quotes(self):
        closing = dict(SESSION, slot="2026-09-08:close")
        now = SESSION["close"] + timedelta(minutes=5)
        for seconds in (1, 2, 5):
            with self.subTest(seconds=seconds):
                raw = payload(regularMarketTime=int((SESSION["close"] + timedelta(seconds=seconds)).timestamp()))
                # Post-market fields must not be used for these regular-session zones.
                raw["chart"]["result"][0]["meta"].update({"postMarketPrice": 1, "postMarketTime": int(now.timestamp())})
                parsed = parse_quote("AIQ", raw)
                self.assertEqual(parsed.price, Decimal("52.01"))
                validate_quote(parsed, now, closing)


class EntryEventTests(unittest.TestCase):
    def observe(self, previous, price="52.00", *, rule=None, minute=0):
        return observe(
            previous,
            quote(price=price, timestamp=NOW + timedelta(minutes=minute)),
            rule or RULE,
            f"2026-09-08:{10 + minute // 60:02}:30",
            CHANNELS,
            NOW + timedelta(minutes=minute),
        )

    def test_zone_edges_are_inclusive_and_cent_beyond_is_outside(self):
        for price, expected in (
            ("48.12", "below"),
            ("48.13", "inside"),
            ("55.68", "inside"),
            ("55.69", "above"),
        ):
            with self.subTest(price=price):
                self.assertEqual(classify(Decimal(price), Decimal("48.13"), Decimal("55.68")), expected)

    def test_first_observation_inside_creates_event(self):
        state = self.observe(None)
        self.assertEqual(state["status"], "inside")
        self.assertTrue(state["pending"]["id"])
        self.assertTrue(state["pending"]["reason"])
        self.assertEqual(state["pending"]["ack"], [])

    def test_first_observation_outside_never_creates_buy_event(self):
        for price, status in (("56", "above"), ("47", "below")):
            with self.subTest(price=price):
                state = self.observe(None, price)
                self.assertEqual(state["status"], status)
                self.assertIsNone(state.get("pending"))

    def test_failed_delivery_retains_same_event_and_channel_acknowledgements(self):
        state = self.observe(None)
        state["pending"]["ack"] = ["mac", "email:first@example.test"]
        retried = self.observe(state, "53", minute=60)
        self.assertEqual(retried["pending"]["id"], state["pending"]["id"])
        self.assertEqual(retried["pending"]["ack"], ["mac", "email:first@example.test"])

    def test_acknowledged_event_does_not_repeat_while_price_stays_inside(self):
        state = self.observe(None)
        state["pending"] = None  # Delivery layer has completed every channel.
        next_state = self.observe(state, "53", minute=60)
        self.assertEqual(next_state["status"], "inside")
        self.assertIsNone(next_state.get("pending"))

    def test_exit_cancels_unsent_entry_so_stale_buy_alert_is_not_retried(self):
        for price in ("47", "56"):
            with self.subTest(price=price):
                inside = self.observe(None)
                outside = self.observe(inside, price, minute=60)
                self.assertIsNone(outside.get("pending"))

    def test_reentry_after_either_exit_creates_a_new_event(self):
        for price in ("47", "56"):
            with self.subTest(price=price):
                original = self.observe(None)
                original_id = original["pending"]["id"]
                outside = self.observe(original, price, minute=60)
                reentered = self.observe(outside, minute=120)
                self.assertEqual(reentered["status"], "inside")
                self.assertTrue(reentered["pending"]["id"])
                self.assertNotEqual(reentered["pending"]["id"], original_id)

    def test_changed_zone_discards_old_comparison_and_pending_acknowledgements(self):
        original = self.observe(None)
        original["pending"]["ack"] = ["mac"]
        changed = self.observe(original, rule={"symbol": "AIQ", "low": "49.00", "high": "54.00"}, minute=60)
        self.assertNotEqual(changed["zone_key"], original["zone_key"])
        self.assertNotEqual(changed["pending"]["id"], original["pending"]["id"])
        self.assertEqual(changed["pending"]["ack"], [])

    def test_changed_zone_can_make_old_inside_price_outside_without_buy_alert(self):
        original = self.observe(None)
        changed = self.observe(original, rule={"symbol": "AIQ", "low": "40.00", "high": "45.00"}, minute=60)
        self.assertEqual(changed["status"], "above")
        self.assertIsNone(changed.get("pending"))

    def test_state_survives_json_round_trip_without_duplicate_entry(self):
        import json

        original = self.observe(None)
        original["pending"] = None
        restored = json.loads(json.dumps(original))
        next_state = self.observe(restored, minute=60)
        self.assertIsNone(next_state.get("pending"))


class CycleIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.config = load_config(DEFAULT_CONFIG)
        self.config["technical_analysis"] = {"enabled": False}
        self.config["investment_analysis"] = {"enabled": False}
        self.config["watchlist"] = [deepcopy(RULE)]
        self.config["alerts"]["mac"] = True
        self.config["alerts"]["email"]["enabled"] = True
        self.config["alerts"]["email"]["to"] = ["first@example.test", "second@example.test"]
        self.state = {"version": 1, "symbols": {}}
        self.sender = Mock()
        self.snapshots = []
        self.persist = Mock(side_effect=lambda state: self.snapshots.append(deepcopy(state)))

    def pending_state(self):
        self.state["symbols"]["AIQ"] = observe(None, quote(), RULE, SESSION["slot"], CHANNELS, NOW)
        return self.state["symbols"]["AIQ"]

    def run_cycle(self, fetcher, **options):
        return run_cycle(
            self.config, self.state, NOW, SESSION,
            fetcher=fetcher, sender=self.sender, persist=self.persist, **options,
        )

    def test_stale_or_unavailable_quote_never_retries_cached_pending_alert(self):
        original = deepcopy(self.pending_state())
        for fetcher in (
            Mock(return_value=quote(timestamp=NOW - timedelta(minutes=21))),
            Mock(side_effect=ValueError("Provider unavailable")),
        ):
            with self.subTest(fetcher=fetcher):
                result = self.run_cycle(fetcher)
                self.assertEqual(result, 1)
                self.sender.assert_not_called()
                self.assertEqual(self.state["symbols"]["AIQ"], original)

    def test_pending_retry_bypasses_completed_price_slot(self):
        self.pending_state()
        fetcher = Mock(return_value=quote())
        self.assertEqual(self.run_cycle(fetcher), 0)
        fetcher.assert_called_once_with("AIQ")
        self.assertEqual([call.args[0] for call in self.sender.call_args_list], CHANNELS)
        self.assertIsNone(self.state["symbols"]["AIQ"]["pending"])

    def test_completed_slot_does_no_network_or_delivery_work(self):
        self.pending_state()["pending"] = None
        fetcher = Mock()
        self.assertEqual(self.run_cycle(fetcher), 0)
        fetcher.assert_not_called()
        self.sender.assert_not_called()
        self.persist.assert_not_called()

    def test_only_failed_recipient_is_retried(self):
        def partial_delivery(channel, title, body):
            if channel == "email:second@example.test":
                raise OSError("Temporary SMTP failure")

        self.sender.side_effect = partial_delivery
        self.assertEqual(self.run_cycle(Mock(return_value=quote())), 1)
        pending = self.state["symbols"]["AIQ"]["pending"]
        event_id = pending["id"]
        self.assertEqual(pending["ack"], ["mac", "email:first@example.test"])
        self.assertEqual(self.snapshots[0]["symbols"]["AIQ"]["pending"]["ack"], [])
        self.assertEqual(self.snapshots[-1]["symbols"]["AIQ"]["pending"]["id"], event_id)
        self.assertEqual(self.snapshots[-1]["symbols"]["AIQ"]["pending"]["ack"], pending["ack"])

        self.sender.reset_mock(side_effect=True)
        self.assertEqual(self.run_cycle(Mock(return_value=quote())), 0)
        self.assertEqual([call.args[0] for call in self.sender.call_args_list], ["email:second@example.test"])
        self.assertIn(event_id, self.sender.call_args.args[2])
        self.assertIsNone(self.state["symbols"]["AIQ"]["pending"])

    def test_dry_run_calls_neither_sender_nor_persist(self):
        original = deepcopy(self.state)
        self.assertEqual(self.run_cycle(Mock(return_value=quote()), dry_run=True), 0)
        self.sender.assert_not_called()
        self.persist.assert_not_called()
        self.assertEqual(self.state, original)

    def test_dry_run_does_not_change_nested_pending_acknowledgements(self):
        self.pending_state()["pending"]["ack"] = ["mac"]
        original = deepcopy(self.state)
        self.assertEqual(self.run_cycle(Mock(return_value=quote("53")), dry_run=True), 0)
        self.sender.assert_not_called()
        self.persist.assert_not_called()
        self.assertEqual(self.state, original)

    def test_quote_freshness_is_checked_after_fetch_finishes(self):
        clock = Mock(return_value=NOW + timedelta(minutes=2))
        fetcher = Mock(return_value=quote(timestamp=NOW - timedelta(minutes=19)))
        self.assertEqual(self.run_cycle(fetcher, clock=clock), 1)
        clock.assert_called_once_with()
        self.sender.assert_not_called()
        self.assertNotIn("AIQ", self.state["symbols"])

    def test_quote_newer_than_cycle_start_is_compared_with_completion_clock(self):
        finished_at = NOW + timedelta(seconds=80)
        fetcher = Mock(return_value=quote(timestamp=NOW + timedelta(seconds=70)))
        self.assertEqual(self.run_cycle(fetcher, clock=lambda: finished_at), 0)
        self.assertEqual(self.sender.call_count, 3)
        self.assertEqual(self.snapshots[0]["symbols"]["AIQ"]["pending"]["created_at"], finished_at.isoformat())

    def test_disabling_failed_channel_resolves_already_delivered_event(self):
        entry = self.pending_state()
        entry["pending"]["ack"] = ["mac", "email:first@example.test"]
        self.config["alerts"]["email"]["to"] = ["first@example.test"]
        self.assertEqual(self.run_cycle(Mock(return_value=quote())), 0)
        self.sender.assert_not_called()
        self.assertIsNone(self.state["symbols"]["AIQ"]["pending"])

    def test_one_unavailable_ticker_does_not_prevent_other_ticker_alerts(self):
        self.config["watchlist"].append({"symbol": "SMH", "low": "370.13", "high": "406.78"})

        def fetcher(symbol):
            if symbol == "AIQ":
                raise ValueError("AIQ unavailable")
            return Quote("SMH", Decimal("400"), NOW - timedelta(minutes=5))

        self.assertEqual(self.run_cycle(fetcher), 1)
        self.assertNotIn("AIQ", self.state["symbols"])
        self.assertEqual(self.state["symbols"]["SMH"]["status"], "inside")
        self.assertIsNone(self.state["symbols"]["SMH"]["pending"])
        self.assertEqual(self.sender.call_count, 3)
        for call in self.sender.call_args_list:
            self.assertIn("SMH", call.args[1])
            self.assertNotIn("AIQ", call.args[1])

    def test_fresh_exit_cancels_pending_before_any_delivery(self):
        self.pending_state()
        self.assertEqual(self.run_cycle(Mock(return_value=quote("47"))), 0)
        self.sender.assert_not_called()
        self.assertEqual(self.state["symbols"]["AIQ"]["status"], "below")
        self.assertIsNone(self.state["symbols"]["AIQ"]["pending"])

    def test_quote_regression_is_rejected_before_pending_delivery(self):
        self.pending_state()
        self.state["symbols"]["AIQ"]["quote"]["timestamp"] = (NOW - timedelta(minutes=1)).isoformat()
        previous = deepcopy(self.state["symbols"]["AIQ"])
        self.assertEqual(self.run_cycle(Mock(return_value=quote(timestamp=NOW - timedelta(minutes=2)))), 1)
        self.sender.assert_not_called()
        self.assertEqual(self.state["symbols"]["AIQ"], previous)

    def test_failure_to_persist_event_prevents_external_delivery(self):
        self.persist.side_effect = OSError("Disk full")
        with self.assertRaises(OSError):
            self.run_cycle(Mock(return_value=quote()))
        self.sender.assert_not_called()


class EmailDeliveryTests(unittest.TestCase):
    def setUp(self):
        self.config = load_config(DEFAULT_CONFIG)
        self.config["technical_analysis"] = {"enabled": False}
        self.config["alerts"]["email"]["to"] = ["first@example.test", "second@example.test"]
        self.entry = observe(None, quote(), RULE, SESSION["slot"], CHANNELS, NOW)
        self.smtp = Mock()
        self.smtp.send_message.return_value = {}

    def send(self, entry=None, channel="email:first@example.test"):
        title, body = alert_text([(RULE, entry or self.entry)], self.config)
        with patch("monitor.connect_smtp", return_value=self.smtp), patch("monitor.smtp_password", return_value="test-placeholder"):
            send_channel(channel, title, body, self.config, Path("/unused-test-runtime"))
        return self.smtp.send_message.call_args.args[0]

    def test_quit_failure_after_acceptance_does_not_become_delivery_failure(self):
        self.smtp.quit.side_effect = smtplib.SMTPServerDisconnected("Connection closed after DATA accepted")
        message = self.send()
        self.assertEqual(message["To"], "first@example.test")
        self.smtp.send_message.assert_called_once()
        self.smtp.close.assert_called_once()

    def test_same_event_and_recipient_retain_message_id_after_quote_changes(self):
        first_message = self.send()
        updated = deepcopy(self.entry)
        updated["quote"] = quote("53", timestamp=NOW).as_dict()
        second_message = self.send(updated)
        self.assertNotEqual(first_message.get_content(), second_message.get_content())
        self.assertEqual(first_message["Message-ID"], second_message["Message-ID"])
        other_recipient = self.send(updated, "email:second@example.test")
        self.assertNotEqual(first_message["Message-ID"], other_recipient["Message-ID"])

    def test_different_entry_event_gets_different_message_id(self):
        first_message = self.send()
        next_entry = observe(None, quote(), RULE, SESSION["slot"], CHANNELS, NOW)
        second_message = self.send(next_entry)
        self.assertNotEqual(first_message["Message-ID"], second_message["Message-ID"])

    def test_refused_recipient_is_a_failed_delivery(self):
        self.smtp.send_message.return_value = {"first@example.test": (450, b"Temporarily unavailable")}
        with self.assertRaises(ValueError):
            self.send()
        self.smtp.quit.assert_called_once()
        self.smtp.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
