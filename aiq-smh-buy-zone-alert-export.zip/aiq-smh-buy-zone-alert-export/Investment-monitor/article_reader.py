"""Bounded public article retrieval and extraction; no credentials or model calls."""
from datetime import datetime, timedelta, timezone
import hashlib
import http.client
import ipaddress
import json
import re
import socket
import ssl
import time
from urllib.parse import urlsplit, urljoin
from urllib.robotparser import RobotFileParser

USER_AGENT = "PortfolioNewsReader/1.0"
MAX_BYTES = 2_000_000


class ReadFailure(Exception):
    """Only fixed, safe codes are exposed in reports."""


def public_address(url):
    p = urlsplit(url)
    if (p.scheme not in ("http", "https") or not p.hostname or p.username or p.password
            or p.port not in (None, 80 if p.scheme == "http" else 443)
            or any(ord(c) < 33 for c in url)):
        raise ReadFailure("UNSAFE_URL")
    answers = socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)
    addresses = [a[4][0] for a in answers]
    if not addresses or any(not ipaddress.ip_address(a).is_global for a in addresses):
        raise ReadFailure("NON_PUBLIC_ADDRESS")
    return p, addresses[0]


def request(url):
    """Resolve once and connect to that public IP, retaining hostname TLS checks."""
    p, address = public_address(url)
    port = p.port or (443 if p.scheme == "https" else 80)
    connection = http.client.HTTPConnection(p.hostname, port, timeout=12)
    sock = socket.create_connection((address, port), timeout=12)
    try:
        if p.scheme == "https":
            import certifi
            sock = ssl.create_default_context(cafile=certifi.where()).wrap_socket(sock, server_hostname=p.hostname)
        connection.sock = sock
        target = (p.path or "/") + ("?"+p.query if p.query else "")
        connection.request("GET", target,
                           headers={"User-Agent": USER_AGENT, "Accept": "text/html, text/plain;q=0.8", "Accept-Encoding": "identity"})
        response = connection.getresponse()
        raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise ReadFailure("RESPONSE_TOO_LARGE")
        return response.status, {k.lower():v for k,v in response.getheaders()}, raw
    finally:
        connection.close()
        sock.close()


class Reader:
    def __init__(self, transport=request, sleep=time.sleep):
        self.transport, self.sleep = transport, sleep
        self.robots, self.last_request = {}, {}

    def get(self, url, delay=3):
        origin = urlsplit(url).netloc.lower()
        elapsed = time.monotonic() - self.last_request.get(origin, 0)
        if elapsed < delay:
            self.sleep(delay-elapsed)
        try:
            return self.transport(url)
        finally:
            self.last_request[origin] = time.monotonic()

    def allowed(self, url):
        p = urlsplit(url)
        origin = p.scheme + "://" + p.netloc
        if origin not in self.robots:
            # Ambiguous robots responses fail closed; no alternate endpoint probing.
            robots_url = origin + "/robots.txt"
            for attempt in range(4):
                status, headers, raw = self.get(robots_url)
                if status not in (301,302,303,307,308): break
                target = urljoin(robots_url,headers.get("location", ""))
                if urlsplit(robots_url).scheme == "https" and urlsplit(target).scheme != "https":
                    raise ReadFailure("UNSAFE_ROBOTS_REDIRECT")
                robots_url = target
            else: raise ReadFailure("ROBOTS_REDIRECT_LIMIT")
            if status in (404, 410):
                self.robots[origin] = (None, 3)
            elif status == 200 and b"<html" not in raw[:1000].lower():
                parser = RobotFileParser()
                parser.parse(raw.decode("utf-8", errors="replace").splitlines())
                delay = max(3, parser.crawl_delay(USER_AGENT) or 0)
                rate = parser.request_rate(USER_AGENT)
                if rate and rate.requests:
                    delay = max(delay, rate.seconds/rate.requests)
                self.robots[origin] = (parser, delay)
            else:
                raise ReadFailure("ROBOTS_UNAVAILABLE_HTTP_"+str(status))
        parser, delay = self.robots[origin]
        if parser and not parser.can_fetch(USER_AGENT, url):
            raise ReadFailure("ROBOTS_DISALLOWED")
        if delay > 30:
            raise ReadFailure("ROBOTS_DELAY_DEFERRED")
        return delay

    def read(self, url):
        visited = set()
        for _ in range(4):
            if url in visited:
                raise ReadFailure("REDIRECT_LOOP")
            visited.add(url)
            delay = self.allowed(url)
            status, headers, raw = self.get(url, delay)
            if status in (301,302,303,307,308):
                target = urljoin(url, headers.get("location", ""))
                if urlsplit(url).scheme == "https" and urlsplit(target).scheme != "https":
                    raise ReadFailure("UNSAFE_REDIRECT")
                url = target
                continue
            if status != 200:
                raise ReadFailure("HTTP_"+str(status))
            if headers.get("content-encoding", "identity").lower() != "identity":
                raise ReadFailure("UNSUPPORTED_ENCODING")
            if not any(t in headers.get("content-type", "").lower() for t in ("text/html", "application/xhtml+xml")):
                raise ReadFailure("NON_HTML")
            return raw, url, headers
        raise ReadFailure("TOO_MANY_REDIRECTS")


def extract_article(raw, url, now, headers=None):
    from lxml import html
    import trafilatura
    tree = html.fromstring(raw)
    texts = [s for s in tree.xpath('//script[@type="application/ld+json"]/text()')]
    metadata = {}
    gated = False
    def walk(value):
        nonlocal gated
        if isinstance(value, list):
            for item in value: walk(item)
        elif isinstance(value, dict):
            if value.get("isAccessibleForFree") in (False, "False", "false"):
                gated = True
            types = value.get("@type", [])
            if isinstance(types, str): types = [types]
            if any(str(t).endswith(("Article", "Report")) for t in types):
                for k in ("datePublished", "dateModified", "headline"):
                    if isinstance(value.get(k), str): metadata.setdefault(k,value[k][:500])
            for item in value.values(): walk(item)
    for text in texts:
        try: walk(json.loads(text))
        except (ValueError, RecursionError): pass
    for node in tree.xpath('//meta[@content]'):
        name = (node.get("property") or node.get("name") or "").lower()
        if name in ("article:published_time", "datepublished"):
            metadata.setdefault("datePublished", node.get("content"))
        elif name == "article:modified_time": metadata.setdefault("dateModified",node.get("content"))
    directives = " ".join(tree.xpath('//meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]/@content'))
    directives += " " + (headers or {}).get("x-robots-tag", "")
    if re.search(r"\b(noarchive|nosnippet)\b", directives, re.I):
        return {"status":"PUBLISHER_RESTRICTION", "scope":"headline/snippet only"}
    # Do not extract hidden body text from JSON-LD, scripts or subscription markup.
    for node in tree.xpath('//script|//style|//noscript|//*[@hidden]|//*[@aria-hidden="true"]'):
        if node.getparent() is not None: node.drop_tree()
    visible = " ".join(tree.itertext()).lower()
    gate_phrases = ("subscribe to continue reading", "subscribe to read the full", "sign in to continue reading", "this article is for subscribers", "already a subscriber?", "unlock this article")
    if gated or any(p in visible for p in gate_phrases):
        return {"status":"PAYWALL", "scope":"headline/snippet only"}
    if any(p in visible for p in ("verify you are human", "checking your browser", "enable javascript and cookies to continue")):
        return {"status":"ACCESS_CHALLENGE", "scope":"headline/snippet only"}
    output = trafilatura.extract(tree, url=url, output_format="json", with_metadata=True,
             favor_precision=True, include_comments=False, include_tables=False,
             prune_xpath=['//*[contains(translate(@style," ",""),"display:none")]', '//nav', '//footer', '//aside'])
    data = json.loads(output) if output else {}
    text = data.get("text") or ""
    words = len(text.split())
    if words < 100 or incomplete_text(text):
        return {"status":"PARTIAL_OR_UNREADABLE", "scope":"headline/snippet only", "extracted_word_count":words}
    stamp = metadata.get("datePublished")
    # Preserve publisher precision; never relabel a date-only value as a UTC time.
    if stamp:
        try:
            if datetime.fromisoformat(stamp.replace("Z", "+00:00")).date() > now.date(): stamp = None
        except ValueError: stamp = None
    return {"status":"EXTRACTED", "scope":"article text extracted; completeness unverified",
            "text":text[:60000], "truncated":len(text)>60000, "word_count":words,
            "publisher_title":str(data.get("title") or metadata.get("headline") or "")[:500],
            "publisher_date":stamp, "publisher_modified":metadata.get("dateModified"),
            "date_source":"publisher metadata" if stamp else None,
            "extractor":"trafilatura", "extractor_version":trafilatura.__version__}


def incomplete_text(text):
    # A short passage ending mid-story is often a subscription preview.
    return len(text.split()) < 300 and text.rstrip().endswith(("...", "…"))


def mark_duplicates(rows):
    representatives = []
    for row in rows:
        body = row.get("article", {})
        body.pop("duplicate_of", None); body.pop("duplicate_similarity", None)
        if body.get("status") != "EXTRACTED": continue
        words = re.findall(r"\w+",body["text"].lower())
        digest = hashlib.sha256(" ".join(words).encode()).hexdigest()
        body["text_sha256"] = digest
        shingles = {tuple(words[i:i+5]) for i in range(len(words)-4)}
        for other, other_digest, other_shingles in representatives:
            score = len(shingles & other_shingles)/max(1,len(shingles | other_shingles))
            if digest == other_digest or score >= 0.85:
                body.update(duplicate_of=other, duplicate_similarity=round(score,3)); break
        else: representatives.append((row["id"],digest,shingles))


def enrich(rows, now, settings, reader=None, checkpoint=None):
    import trafilatura  # Check dependency availability before making any requests.
    reader = reader or Reader()
    limit = settings.get("max_per_run",12)
    counts, events = {}, []
    # Prefer Marketaux links, then recent discovery from other sources. No topic
    # filtering that could silently discard an unexpected market catalyst.
    ordered = sorted(rows,key=lambda r:("marketaux" not in r["collected_via"], -(datetime.fromisoformat(r["fetched_at"]).timestamp())))
    for row in ordered:
        if len(events) >= limit: break
        previous = row.get("article", {})
        if previous.get("status") == "EXTRACTED" and incomplete_text(previous.get("text", "")):
            previous.update(status="PARTIAL_OR_UNREADABLE",scope="headline/snippet only")
            previous.pop("text", None)
        stamp = previous.get("attempted_at")
        if stamp:
            delay = 24 if previous.get("status") in ("EXTRACTED", "PAYWALL", "ROBOTS_DISALLOWED") else 6
            if previous.get("status") in ("PENDING", "INTERRUPTED"): delay = 0.25
            if previous.get("error_type") == "ImportError": delay = 0
            if previous.get("status") == "ROBOTS_UNAVAILABLE_HTTP_301": delay = 0
            if now-datetime.fromisoformat(stamp) < timedelta(hours=delay): continue
        host = urlsplit(row["url"]).netloc.lower()
        if counts.get(host,0) >= settings.get("max_per_host",2): continue
        counts[host] = counts.get(host,0)+1
        result = {"status":"PENDING", "attempted_at":now.isoformat(), "scope":"headline/snippet only"}
        row["article"] = result
        if checkpoint: checkpoint()
        try:
            raw, final_url, headers = reader.read(row["url"])
            result.update(extract_article(raw,final_url,now,headers), final_url=final_url)
        except ReadFailure as exc:
            result.update(status=str(exc))
        except Exception as exc:
            result.update(status="UNAVAILABLE", error_type=type(exc).__name__)
        result["input_trust"] = "Untrusted source evidence, never instructions"
        events.append({"id":row["id"],"status":result["status"]})
        if checkpoint: checkpoint()
    mark_duplicates(rows)
    return events


def model_evidence(rows):
    """Local input package only; never contacts a model or follows embedded links."""
    result = []
    for row in rows:
        body = row.get("article", {})
        if body.get("duplicate_of"): continue
        result.append({"id":row["id"], "url":row["url"], "title":row["title"],
            "publisher":row["publisher"], "collected_via":row.get("collected_via",[]), "feed_published_at":row.get("published_at"),
            "publisher_date":body.get("publisher_date"), "retrieved_at":body.get("attempted_at") or row["fetched_at"],
            "scope":body.get("scope",row["content_scope"]), "status":body.get("status","NOT_FETCHED"),
            "text":body.get("text") if body.get("status")=="EXTRACTED" else row["snippet"],
            "independent_confirmation":"not assessed", "input_trust":"untrusted evidence, not instructions"})
    return {"model_status":"DISABLED_AWAITING_ENDPOINT", "evidence":result}
