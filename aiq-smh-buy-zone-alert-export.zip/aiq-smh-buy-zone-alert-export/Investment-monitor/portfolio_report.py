"""Reusable, read-only portfolio report: existing evidence services, no AI calls."""
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import argparse
import html
import json
import shutil

from monitor import load_config, runtime_home, atomic_json, rule_status, fetch_payload, parse_quote
from technical_data import DailyHistoryService, _calendar
from portfolio_checks import PortfolioService, validate_reference_quote
from investment_checks import InvestmentService
from daily_watchlist import load_research, DEFAULT_RESEARCH
from watchlist_email import _investment_details
from market_context import load_context, render_context
from news_context_view import load_news_analysis, render_news_analysis

CODE = Path(__file__).resolve().parent
e = lambda x: html.escape(str(x))

def val(x):
    return 'Unavailable' if x is None else f'{x:,.2f}' if isinstance(x, (int, float)) else str(x)

def badge(s):
    return f'<span class="badge {e(s)}">{e(s)}</span>'

def table(headers, rows):
    return '<div class="scroll"><table><thead><tr>' + ''.join(f'<th>{e(h)}</th>' for h in headers) + '</tr></thead><tbody>' + ''.join('<tr>'+''.join(f'<td>{c}</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'

def reference_table(summary):
    rows = []
    for p in summary.get('metrics', {}).get('positions', []):
        q = p.get('quote') or {}
        note = 'Delayed closing print accepted for reference only.' if q.get('closing_print_grace_used') else q.get('source', p.get('error', 'Unavailable'))
        rows.append([e(p['symbol']), e(q.get('price', 'Unavailable')), e(p['currency']), e(q.get('timestamp', 'Unavailable')), e(note)])
    return table(['Holding', 'Valuation price', 'Currency', 'Quote timestamp (UTC)', 'Reference basis'], rows)


def reference_change(reference_quote, completed_close):
    """Return a display-only move from the latest completed daily close."""
    price = reference_quote.get('price') if isinstance(reference_quote, dict) else None
    if not isinstance(price, (int, float)) or not isinstance(completed_close, (int, float)) or completed_close <= 0:
        return 'Change unavailable'
    return f'{(price / completed_close - 1) * 100:+.2f}% vs completed close'

def bounce_evidence(history):
    if history.get('status') != 'AVAILABLE' or history.get('as_of') != history.get('expected_session'):
        return '<p>Fresh rebound levels unavailable: latest completed daily bar missing.</p>'
    last = history['bars'][-1]
    return f"<p><b>Rebound watch · {e(last['date'])}:</b> last session low {val(last['low'])}, close {val(last['close'])}, high {val(last['high'])}. Holding the low and reclaiming the close/high would support a relief-rally scenario; a break below the low weakens it. These are reference levels, not a tested entry strategy or confirmation that a bounce has occurred.</p>"

def collect_data(config, research_path, home, now, candidates=(), context_path=None, news_path=None):
    inputs = json.loads(Path(config['investment_analysis']['portfolio_file']).read_text())
    owned = {p['symbol'] for p in inputs['positions']}
    rules = {r['symbol']: r for r in config['watchlist']}
    universe = owned | set(candidates)
    if universe - rules.keys():
        raise ValueError('Securities missing configured rules: ' + ', '.join(sorted(universe-rules.keys())))
    selected = [rules[s] for s in sorted(universe)]
    research_date, research, warning = load_research(research_path)
    history = DailyHistoryService(Path(home)/'daily-history', config, read_only=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        histories = dict(pool.map(lambda r: (r['symbol'], history.get_history(r, now)), selected))

    def reference(rule):
        symbol = rule['symbol']
        error = None
        try:
            quote = parse_quote(symbol, fetch_payload(symbol)).as_dict()
            return symbol, validate_reference_quote(symbol, quote, rule, now), None
        except Exception as exc:
            error = str(exc)[:200]
        h = histories[symbol]
        if h['status'] == 'AVAILABLE' and h['as_of'] == h['expected_session']:
            bar = h['bars'][-1]
            stamp = _calendar(int(bar['date'][:4]), rule.get('market', 'US')).session_close(bar['date']).to_pydatetime()
            q = {'symbol': symbol, 'price': bar['close'], 'timestamp': stamp.isoformat(),
                 'currency': rule.get('currency', 'HKD' if symbol.endswith('.HK') else 'USD'),
                 'phase': 'regular', 'source': 'Validated daily close; timestamp denotes exchange close, not observed trade time'}
            return symbol, validate_reference_quote(symbol, q, rule, now), error
        return symbol, None, error

    with ThreadPoolExecutor(max_workers=4) as pool:
        references = list(pool.map(reference, selected))
    quotes = {s: q for s, q, err in references if q}
    portfolio = PortfolioService(Path(home)/'investment-data/portfolio',
        config['investment_analysis']['portfolio_file'], config['watchlist'], read_only=True, allow_fallback=False)
    service = InvestmentService(config, home, read_only=True, portfolio=portfolio)
    investments, summary = service.batch(selected, quotes, now)
    rows = []
    for rule in selected:
        symbol = rule['symbol']
        saved = research.get(symbol, {})
        h = histories[symbol]
        # Service reuses the history fetched above. No current intraday price is
        # passed to the completed-daily indicator engine.
        technical = history.evaluate(rule, {}, now)
        close = h['bars'][-1]['close'] if h['status'] == 'AVAILABLE' else None
        rows.append({'symbol': symbol, 'holding': symbol in owned,
            'currency': rule.get('currency', 'HKD' if symbol.endswith('.HK') else 'USD'),
            'report_close': close, 'report_close_date': h.get('as_of'),
            'condition_at_report_close': rule_status(str(close), rule) if close is not None else 'unavailable',
            'zone_low': rule['low'], 'zone_high': rule['high'],
            **{k: saved.get(k, 'Not supplied') for k in ('entry', 'tp', 'stop', 'assessment', 'comments')},
            'gate': saved.get('gate', rule.get('review_notes', '')),
            'research_date': research_date, 'technical': technical, 'investment': investments[symbol]})
    return {'built_at': now.isoformat(), 'financial_snapshot_at': now.isoformat(),
        'collection_started_at': now.isoformat(), 'portfolio_summary': summary, 'rows': rows,
        'histories': histories, 'research_warning': warning,
        'quote_fetch_errors': {s: err for s, q, err in references if err},
        'configured_rule_count': len(config['watchlist']), 'context': load_context(context_path, now),
        'news_context': load_news_analysis(news_path or CODE/'news-evidence/news-analysis.json',now)}

def refresh_context(data, context_path=None, news_path=None, now=None):
    """Refresh only dated context while retaining a saved evidence snapshot."""
    if not isinstance(data, dict):
        raise ValueError('Saved snapshot must be a JSON object')
    now = now or datetime.now(timezone.utc)
    refreshed = json.loads(json.dumps(data))
    retained_at = data.get('financial_snapshot_at')
    refreshed['built_at'] = now.isoformat()
    refreshed['context'] = load_context(context_path, now)
    refreshed['news_context'] = load_news_analysis(news_path, now)
    refreshed['_context_refresh'] = {'rendered_at': now.isoformat(),
        'financial_snapshot_at': retained_at}
    return refreshed

def render_report(data, display_timezone='Asia/Hong_Kong', data_filename='portfolio-refresh-data.json'):
    rows, histories, summary = data['rows'], data['histories'], data['portfolio_summary']
    now = datetime.fromisoformat(data['built_at'])
    snapshot = {'generated_at': data['financial_snapshot_at']}
    owned = {r['symbol'] for r in rows if r['holding']}
    metrics = summary['metrics']
    counts = Counter(r['technical']['status'] for r in rows)
    date_label = now.astimezone(ZoneInfo(display_timezone)).strftime('%d %B %Y · %H:%M %Z')
    def plan(r):
        grade = r['technical']['status']
        if grade=='FAIL': return 'Technical entry setup failed. Reassess after support and structure improve; this is not an automatic instruction to sell an existing holding.'
        if grade=='WAIT': return 'Watch for the missing technical confirmations listed below before considering an addition.'
        if grade=='PASS': return 'Chart conditions met; business, valuation and position-size review remains necessary. No proven buying edge.'
        if grade=='NOT_APPLICABLE': return 'Review yield, NAV, duration and liquidity purpose; the equity entry filter does not apply.'
        return 'Current technical conclusion unavailable; do not infer confirmation from the saved range.'

    overview=[]
    for r in sorted(rows,key=lambda r:(not r['holding'],r['symbol'])):
        p=r['investment']['portfolio']['metrics'];t=r['technical']
        reference_quote=r['investment']['portfolio'].get('reference_quote') or {}
        overview.append([f'<a href="#t-{e(r["symbol"])}"><b>{e(r["symbol"])}</b></a><small>{"Holding" if r["holding"] else "Candidate"}</small>',
          f'{e(r["currency"])} {val(r["report_close"])}<small>{e(r["report_close_date"] or "Unavailable")}</small>',
          f'{e(r["currency"])} {val(reference_quote.get("price"))}<small>{e(reference_change(reference_quote,r["report_close"]))} · {e(reference_quote.get("timestamp","Unavailable"))}</small>',
          val(p.get('position_quantity')),val(p.get('position_value_usd')),val(p.get('position_weight_pct')),
          badge(t['status'])+f'<small>Daily evidence: {e(t.get("as_of") or "N/A")}</small>',
          f'{e(r["zone_low"])}–{e(r["zone_high"])}<small>{e(r["condition_at_report_close"])} at dated close</small>',
          e(r['tp']),e(r['stop'])])
    cards=[]
    for r in sorted(rows,key=lambda r:r['symbol']):
        t=r['technical'];h=histories[r['symbol']]
        chart=''
        if h['status']=='AVAILABLE' and len(h['bars'])>1:
            bars=h['bars'][-90:];prices=[b['close'] for b in bars];lo=min(prices);span=max(prices)-lo or 1
            points=' '.join(f'{i/(len(prices)-1)*600:.1f},{110-(p-lo)/span*100:.1f}' for i,p in enumerate(prices))
            chart=f'<svg viewBox="0 0 600 120" role="img" aria-label="{e(r["symbol"])} last 90 completed daily closing prices"><polyline points="{points}" fill="none" stroke="#19716a" stroke-width="2"/></svg><small>{bars[0]["date"]} to {bars[-1]["date"]} · individual chart scale · excludes distributions</small>'
        techitems=[(k.replace('_',' '),val(v)) for k,v in t.get('metrics',{}).items() if k in ('close','sma20','sma50','sma200','sma50_slope','higher_low','lower_low','lower_high','breakout_confirmed','rsi14','macd_histogram','atr14','relative_volume20','support20','resistance20')]
        evidence=''.join(f'<dt>{e(k)}</dt><dd>{e(v)}</dd>' for k,v in _investment_details(r))
        cards.append(f'''<details class="security" id="t-{e(r['symbol'])}"><summary><b>{e(r['symbol'])}</b> {badge(t['status'])} · {'Existing holding' if r['holding'] else 'Candidate'}</summary>
        <div class="body"><p class="lead">{e(plan(r))}</p><div class="grid"><div>{chart}<h3>Completed daily technical evidence</h3>{bounce_evidence(h)}<p>{e('; '.join(t.get('reasons',[])))}</p><dl>{''.join(f'<dt>{e(k)}</dt><dd>{e(v)}</dd>' for k,v in techitems)}</dl><small>History retrieved: {e(h.get('fetched_at','Unavailable'))}. The report has no live entry quote.</small></div>
        <div><h3>Saved plan · {e(r.get('research_date'))}</h3><p><b>Entry:</b> {e(r['entry'])}</p><p><b>TP:</b> {e(r['tp'])}</p><p><b>Stop / review:</b> {e(r['stop'])}</p><p><b>Conditions:</b> {e(r['gate'])}</p><details><summary>Historical assessment and comments</summary><p>{e(r['assessment'])}</p><p>{e(r['comments'])}</p><p>These statements retain their original research date; refreshed filing metrics do not validate guidance or the full thesis.</p></details></div></div><h3>Financial, NAV and exposure evidence</h3><dl class="evidence">{evidence}</dl></div></details>''')

    css='''*{box-sizing:border-box}body{margin:0;background:#f3f5f6;color:#233744;font:15px/1.55 system-ui,sans-serif}header{background:#143c43;color:white;padding:45px max(5vw,20px)}header p{max-width:950px}h1{font-size:36px;margin:8px 0}nav{display:flex;gap:20px;flex-wrap:wrap}nav a{color:#bfeee0}.wrap{max-width:1450px;margin:auto;padding:24px}section,.security{background:white;border:1px solid #dbe4e7;border-radius:10px;margin:20px 0;padding:24px}h2{font-size:25px}a{color:#176e6a}small{display:block;color:#60717a;font-size:12px}.grid,.kpis{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}.kpis{grid-template-columns:repeat(4,1fr)}.kpis div{background:#e8f1ef;padding:18px;border-radius:7px}.kpis strong{display:block;font-size:25px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #dde5e8;min-width:95px}th{background:#edf3f2}td:nth-last-child(-n+2){min-width:150px}.badge{display:inline-block;padding:3px 8px;border-radius:5px;background:#e8ecef;font-size:12px}.FAIL{color:#9d2e32;background:#fdebed}.WAIT,.REVIEW{color:#85601c;background:#fff3d7}.PASS{color:#176243;background:#e0f4e6}.note{background:#fff3d7;border-left:4px solid #c59733;padding:14px}.security summary{cursor:pointer}.body{padding-top:20px}dl{margin:14px 0}dt{font-weight:600;margin-top:12px}dd{margin:3px 0;overflow-wrap:anywhere}.evidence{font-size:13px}.lead{font-size:17px}svg{width:100%;max-height:160px}input{padding:12px;width:100%;max-width:450px;border:1px solid #b6c8cb;border-radius:5px}button{padding:10px;margin:12px 0;cursor:pointer}footer{font-size:12px;color:#60717a;padding:20px}@media(max-width:800px){.grid,.kpis{grid-template-columns:1fr}h1{font-size:28px}.wrap{padding:12px}section{padding:16px}}@media print{details .body{display:block}nav,input,button{display:none}.scroll{overflow:visible}body{background:white}}'''
    cash=' · '.join(f'{c} {v:,.2f}' for c,v in metrics['cash_by_currency'].items())
    page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Portfolio review · {date_label}</title><style>{css}</style></head><body>
    <header><small style="color:#c5dedb">INCOME AND GROWTH · UPDATED {date_label}</small><h1>Portfolio review with dated evidence</h1>{f'<p class="note">Context refreshed {e(data["_context_refresh"]["rendered_at"])}. Financial/price/technical snapshot retained from {e(data["_context_refresh"]["financial_snapshot_at"])}; no new price or technical check in this refresh.</p>' if data.get('_context_refresh') else ''}<p>{len(rows)} securities: {len(owned)} confirmed holdings and {len(rows)-len(owned)} candidates. {counts.get('PASS',0)} technical PASS, {counts.get('FAIL',0)} FAIL, {counts.get('WAIT',0)} WAIT and {counts.get('UNAVAILABLE',0)} unavailable. Review the failed or incomplete entry conditions before adding risk; portfolio limits remain unset.</p><nav><a href="#portfolio">Exposure</a><a href="#candidates">Prices and levels</a><a href="#scenarios">Scenarios</a><a href="#monitor">Monitoring</a><a href="#details">Evidence</a></nav></header>
    <main class="wrap"><div class="kpis"><div><strong>{val(metrics.get('total_value_usd'))}</strong>Portfolio reference value · USD</div><div><strong>{val(metrics.get('converted_cash_usd'))}</strong>Cash at reference FX · USD</div><div><strong>{counts.get('PASS',0)} / {len(rows)}</strong>Technical PASS</div><div><strong>{metrics.get('valued_position_count',0)} / {len(owned)}</strong>Holdings valued</div></div>
    <section id="portfolio"><h2>Exposure and liquidity</h2><p>Valuation uses validated market references with each holding's timestamp shown below; daily closes are used when current metadata is unavailable. US closing and current Hong Kong marks may have different times. Quantities and cash were confirmed {e(summary.get('confirmed_at'))}; update the private input whenever holdings change. Assets outside that input are excluded.</p><p><b>Cash:</b> {e(cash)}. Conversion uses ECB reference FX dated {e(metrics.get('fx',{}).get('as_of','Unavailable'))}.</p><p class="note">Risk limits and proposed purchase amounts are unset. Exposure calculations do not declare an addition suitable. Securities remain investments rather than available cash; converted cash is not broker buying power.</p><p><b>Available subtotal (holdings plus cash): USD {val(metrics.get('known_position_value_usd',0)+metrics.get('known_cash_value_usd',0))}.</b> {'Complete reference total.' if summary.get('complete') else 'Partial only: omitted holdings are not worthless. Total and percentage weights are withheld until all prices and FX validate.'}</p><p>{e('; '.join(summary['reasons']))}</p>{reference_table(summary)}</section>
    <section id="candidates"><h2>Prices, technical checks and saved levels</h2><p>The saved entry, TP and stop/review plans below retain the research dates shown in each security's evidence. They have not been recalculated or reapproved using current guidance. The live reference and percentage change are valuation observations only; technical checks remain based on completed daily sessions. Current chart checks are an independent filter; historical testing did not establish a consistent buying advantage.</p><input id="search" type="search" aria-label="Filter securities" placeholder="Filter by ticker or status">{table(['Security','Daily close','Live reference / change','Shares','Value USD','Weight %','Technical','Saved price condition','Saved TP','Saved stop / review'],overview)}</section>
    <section id="news"><h2>News context · local model</h2>{render_news_analysis(data.get('news_context', {}),now)}</section>
    <section id="scenarios"><h2>Scenarios and valuation discipline</h2>{render_context(data.get('context', {}), now)}<p class="note">SEC evidence does not establish updated fair values or TP dates. Macro relief does not repair a company-specific thesis, and technical FAIL does not mean a rebound is impossible. Saved targets remain conditional research, not forecasts.</p></section>
    <section id="monitor"><h2>What the monitor now checks</h2><p>{data['configured_rule_count']} configured price conditions use five-minute eligible US pre-market, regular-session and after-hours checks. Hong Kong follows its own exchange sessions, holidays and lunch break. The pre-open email targets 09:00 New York time on NYSE trading days.</p><p>Price alerts include completed-daily technical evidence, supported NAV comparisons, SEC annual/latest fiscal YTD facts and portfolio exposure. A saved-zone entry is not a buy recommendation. Source refreshes are cached; guidance, valuation, distribution sustainability and external recommendations remain unverified.</p><p>In this refreshed group: {e(dict(Counter(r['investment']['nav']['status'] for r in rows)))} for NAV. Every unavailable result includes its reason below.</p><p><a href="README.md">Project documentation</a> · <a href="{e(data_filename)}">Refreshed report data</a></p></section>
    <section id="details"><h2>Evidence for each security</h2><button id="expand">Expand all details</button>{''.join(cards)}</section>
    <footer>Built {date_label}. Financial evidence collected {e(snapshot['generated_at'])}; each filing, NAV and price retains its own date. Public SEC and issuer sources are listed in the evidence. Yahoo daily prices may be delayed and exclude reinvested distributions. Report generation sends no orders or emails. The shared valuation and history services also serve the existing monitor.</footer></main>
    <script>document.querySelector('#search').addEventListener('input',function(){{const q=this.value.toLowerCase();document.querySelectorAll('#candidates tbody tr').forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q));}});document.querySelector('#expand').onclick=function(){{const d=[...document.querySelectorAll('.security')],open=!d.every(x=>x.open);d.forEach(x=>x.open=open);this.textContent=open?'Collapse all details':'Expand all details'}};function reveal(){{const el=document.getElementById(location.hash.slice(1));if(el&&el.tagName==='DETAILS')el.open=true}}window.addEventListener('hashchange',reveal);reveal();window.addEventListener('beforeprint',()=>document.querySelectorAll('details').forEach(x=>x.open=true));</script></body></html>'''

    return page

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=CODE/'config.json')
    parser.add_argument('--research', type=Path, default=DEFAULT_RESEARCH)
    parser.add_argument('--home', type=Path, default=runtime_home())
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--candidates', nargs='*', default=[])
    parser.add_argument('--context', type=Path)
    parser.add_argument('--news-context', type=Path, default=CODE/'news-evidence/news-analysis.json')
    parser.add_argument('--from-snapshot', type=Path, help='Render from saved portfolio JSON without collecting new evidence')
    parser.add_argument('--timezone', default='Asia/Hong_Kong')
    args = parser.parse_args()
    now = datetime.now(timezone.utc)
    if args.from_snapshot:
        data = refresh_context(json.loads(args.from_snapshot.read_text()), args.context, args.news_context, now)
    else:
        config = load_config(args.config)
        data = collect_data(config, args.research, args.home, now, args.candidates, args.context, args.news_context)
    data_path = args.output.with_name('portfolio-refresh-data.json')
    page = render_report(data, args.timezone, data_path.name)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        backup = args.output.with_name(args.output.stem + '-before-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.html')
        shutil.copy2(args.output, backup)
    atomic_json(data_path, data)
    temporary = args.output.with_suffix('.html.tmp')
    temporary.write_text(page)
    temporary.replace(args.output)
    m = data['portfolio_summary']['metrics']
    print(json.dumps({'output': str(args.output), 'valued': m.get('valued_position_count'),
        'total_usd': m.get('total_value_usd'), 'technical': dict(Counter(r['technical']['status'] for r in data['rows']))}))

if __name__ == '__main__':
    main()
